import copy
import unittest
from account_completed_banks import compare, all_values

def row(values,selected,retained=None,bank=701):
    retained=list(values) if retained is None else retained
    definitions={'a':('x','reflex'),'b':('x','retry'),'c':('y','reflex')}
    roots={p:[definitions[p][0]] for p in retained}
    plans={p:dict(root=definitions[p][0],proposal=p) for p in values}
    policies={p:dict(kind=definitions[p][1],preferred=definitions[p][0] if definitions[p][1]=='retry' else None) for p in values}
    return dict(action=definitions[selected][0],roots=roots,seeds=[bank],
        decision=dict(context_hash='fixed-context',next_state={'action':definitions[selected][0]}),
        selection_inputs=dict(base_context={'fixed':True}),
        selected_purpose=values[selected],purpose_by_plan={p:values[p] for p in retained},
        deliberation=dict(selected_plan=selected,metadata=dict(plans=plans,
            continuation_portfolio=dict(policies=policies),
            purpose_mean_estimator=dict(kind='conditional public goal control variate',
                roots={p:dict(unprojected=v) for p,v in values.items()}))))

class Accounting(unittest.TestCase):
    def test_exact_gap_decomposition(self):
        a=row(dict(a=.6,b=.3,c=.4),'a')
        b=row(dict(a=.1,b=.3,c=.5),'c',bank=9101)
        out=compare(a,b)
        self.assertAlmostEqual(out['unrestricted_other_root_gap'],.2)
        self.assertAlmostEqual(out['unrestricted_other_tail_gap'],.2)
        self.assertAlmostEqual(out['unrestricted_other_plan_gap'],.4)
    def test_first_action_agreement_can_hide_tail_change(self):
        a=row(dict(a=.6,b=.3,c=.2),'a')
        b=row(dict(a=.1,b=.3,c=.2),'b',bank=9101)
        out=compare(a,b)
        self.assertTrue(out['same_action']);self.assertFalse(out['same_plan'])
        self.assertTrue(out['same_factual_commit_inputs'])
        self.assertEqual(out['unrestricted_other_root_gap'],0.)
    def test_removed_persona_plan_is_retained_as_accounting(self):
        a=row(dict(a=.6,b=.3,c=.4),'a')
        b=row(dict(a=.1,b=.3,c=.5),'c',retained=['b','c'],bank=9101)
        out=compare(a,b)
        self.assertFalse(out['held_plan_in_other_persona_tier'])
        self.assertFalse(out['persona_tier_identical'])
        self.assertEqual(out['other_purpose'],.1)
    def test_semantic_substitution_rejected(self):
        a=row(dict(a=.6,b=.3,c=.4),'a');b=copy.deepcopy(a)
        b['deliberation']['metadata']['plans']['a']['root']='z'
        with self.assertRaises(ValueError):compare(a,b)
    def test_retained_value_disagreement_rejected(self):
        a=row(dict(a=.6,b=.3,c=.4),'a');a['purpose_by_plan']['a']=.7
        with self.assertRaises(AssertionError):all_values(a)
    def test_fixed_persona_sacrifice_separate_from_raw_gap(self):
        a=row(dict(a=.6,b=.3,c=.4),'b',retained=['b'])
        out=compare(a,a)
        self.assertEqual(out['own_purpose_sacrifice'],0.)
        self.assertAlmostEqual(out['unrestricted_other_plan_gap'],.3)

if __name__=='__main__':unittest.main()
