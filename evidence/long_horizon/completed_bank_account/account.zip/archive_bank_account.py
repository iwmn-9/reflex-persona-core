from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

base=Path(__file__).resolve().parent
repo=base.parents[2]/'reflex-persona-core'
output=repo/'evidence/long_horizon/completed_bank_account'
output.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
account=json.loads((base/'consistent_cross_bank_account_v2.json').read_bytes())
assert account['complete'] and account['registered_evaluations']==72
assert account['script_sha256']==sha((base/'account_completed_banks.py').read_bytes())
with zipfile.ZipFile(output/'account.zip','x',zipfile.ZIP_DEFLATED) as packed:
    for name in ('account_completed_banks.py','test_completed_banks.py','consistent_cross_bank_account_v2.json','archive_bank_account.py'):
        packed.writestr(name,(base/name).read_bytes())
proof=dict(complete=True,adoption=False,at=datetime.now(timezone.utc).isoformat(),
    source_ref=account['source_ref'],receipt_sha256=account['receipt_sha256'],
    plan_sha256=account['plan_sha256'],archive_sha256=sha((output/'account.zip').read_bytes()),
    summary=account['summary'],registered_evaluations=72,new_forecasts=0,new_worlds=0,
    math_checks='Six targeted checks passed: exact gap decomposition, same-root different-tail, excluded personality tier, semantic substitution, inconsistent retained value, separate personality sacrifice.',
    interpretation='A change in a selected modeled continuation does not by itself change the actual commitment. All same-action pairs here have the same stored actual context and next-state inputs. Do not add forced plan persistence merely to remove that variability.',
    limits=account['limits'])
(output/'verification.json').write_text(json.dumps(proof,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
handoff=repo/'results/long_horizon_resume_status.json'
saved=json.loads(handoff.read_bytes());saved['updated']=proof['at']
saved['operational']['active_runtime_probe']['worktree_removed']=True
saved['completed']['completed_bank_account']=dict(proof=str(output/'verification.json'),
    result='All72 historical diagnostics cross-evaluated without new forecasts. With3/8 samples, action changes occur at5/2 roots, selected-plan changes at6/4. Same-action pairs retain identical actual commitment inputs. Model-only variability is not a demonstrated long-play defect.',
    reusable_script=str(base/'account_completed_banks.py'))
handoff.write_text(json.dumps(saved,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(complete=True,archive_sha256=proof['archive_sha256'])))
