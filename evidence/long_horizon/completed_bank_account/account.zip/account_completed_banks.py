"""Cross-evaluate stored plan selections across all registered model banks.

Reads a COMPLETE diagnostic receipt, never a live checkpoint or a new forecast.
The estimates concern the same approximate model, not the true future. Do not
use them as an adoption test, confidence interval or a new independent trial.
"""
import argparse
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path

def encoded(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(x):return hashlib.sha256(x).hexdigest()
def mean(xs):return math.fsum(xs)/len(xs)

def signature(row):
    meta=row['deliberation']['metadata']
    return {name:dict(root=[plan['root']],
        policy=meta['continuation_portfolio']['policies'][plan['proposal']])
        for name,plan in meta['plans'].items()}

def all_values(row):
    # The full conditional mean audit precedes the personality tier. Do not
    # invent values for plans excluded by that tier or silently drop a bank.
    audit=row['deliberation']['metadata']['purpose_mean_estimator']
    assert audit['kind']=='conditional public goal control variate'
    values={p:max(-1.,min(1.,r['unprojected'])) for p,r in audit['roots'].items()}
    assert set(values)==set(signature(row))
    assert all(values[p]==v for p,v in row['purpose_by_plan'].items())
    return values

def compare(a,b):
    """Plan regret = first-action gap + remaining-continuation gap, under B."""
    if signature(a)!=signature(b):raise ValueError('same semantic plans required')
    selected=a['deliberation']['selected_plan']
    if selected not in a['purpose_by_plan']:raise ValueError('selected proposal required')
    root=a['roots'][selected]
    if len(root)!=1 or root[0]!=a['action']:raise ValueError('actual root required')
    av,bv=all_values(a),all_values(b)
    own=av[selected]
    held=bv[selected]
    best=max(bv.values())
    root_best=max(v for p,v in bv.items() if signature(b)[p]['root']==root)
    root_gap=best-root_best;tail_gap=root_best-held;total_gap=best-held
    assert root_gap>=-1e-12 and tail_gap>=-1e-12
    assert math.isclose(total_gap,root_gap+tail_gap,abs_tol=1e-12)
    assert math.isclose(own,a['selected_purpose'],abs_tol=1e-12)
    return dict(selection_bank=a['seeds'][0],evaluation_bank=b['seeds'][0],
        selected_plan=selected,selected_action=a['action'],same_action=a['action']==b['action'],
        same_plan=selected==b['deliberation']['selected_plan'],
        same_factual_commit_inputs=(a['action']==b['action'] and
            a['decision']['context_hash']==b['decision']['context_hash'] and
            a['decision']['next_state']==b['decision']['next_state'] and
            a['selection_inputs']['base_context']==b['selection_inputs']['base_context']),
        held_plan_in_other_persona_tier=selected in b['purpose_by_plan'],
        persona_tier_identical=set(a['purpose_by_plan'])==set(b['purpose_by_plan']),
        own_purpose=own,other_purpose=held,
        own_purpose_sacrifice=max(a['purpose_by_plan'].values())-own,
        unrestricted_other_plan_gap=total_gap,unrestricted_other_root_gap=root_gap,unrestricted_other_tail_gap=tail_gap,
        centered_estimate_difference=(own-mean(list(av.values())))
           -(held-mean(list(bv.values()))))

def account(execution,output):
    execution,output=Path(execution).resolve(),Path(output).resolve()
    if output.exists():raise FileExistsError('preserve existing account')
    receipt_raw=(execution/'verification.json').read_bytes()
    receipt=json.loads(receipt_raw);status=json.loads((execution/'status.json').read_bytes())
    plan_raw=(execution/'plan.json').read_bytes();plan=json.loads(plan_raw)
    if not receipt['complete'] or not status['complete'] or status['state']!='complete':
        raise ValueError('completed diagnostics only')
    assert receipt['root_plan_sha256']==sha(plan_raw)
    assert receipt['evaluations']==len(receipt['rows'])==len(plan['jobs'])
    assert [r['job'] for r in receipt['rows']]==plan['jobs']
    groups=defaultdict(list)
    for entry in receipt['rows']:
        raw=(execution/entry['file']).read_bytes()
        assert sha(raw)==entry['sha256']
        row=json.loads(raw);job=entry['job']
        assert (row['id'],row['tick'],row['factual_owner'],row['input_sha256'])==(
            job['id'],job['tick'],job['factual_owner'],job['input_sha256'])
        assert row['seeds']==list(range(job['start'],job['start']+job['samples']))
        assert row['personal_ranking']['exact_selection_reproduced']
        groups[(row['id'],row['tick'])].append(row)
    results=[]
    for (case,tick),rows in sorted(groups.items()):
        assert len({r['factual_owner'] for r in rows})==1
        assert len({r['input_sha256'] for r in rows})==1
        assert len({sha(encoded(r['persona'])) for r in rows})==1
        counts={}
        for count in (3,8):
            subset=sorted((r for r in rows if len(r['seeds'])==count),key=lambda r:r['seeds'][0])
            assert [r['seeds'][0] for r in subset]==[701,9101,9201]
            assert len(set(sum((r['seeds'] for r in subset),[])))==count*3
            pairs=[compare(a,b) for a in subset for b in subset if a is not b]
            counts[str(count)]=dict(pairs=pairs,
                unique_actions=len({r['action'] for r in subset}),
                unique_plans=len({r['deliberation']['selected_plan'] for r in subset}),
                persona_tier_varies=any(not p['persona_tier_identical'] for p in pairs),
                same_action_but_changed_commit_pairs=sum(p['same_action'] and not p['same_factual_commit_inputs'] for p in pairs),
                selected_plan_rejected_by_other_tier=sum(not p['held_plan_in_other_persona_tier'] for p in pairs),
                unrestricted_mean_other_root_gap=mean([p['unrestricted_other_root_gap'] for p in pairs]),
                unrestricted_mean_other_tail_gap=mean([p['unrestricted_other_tail_gap'] for p in pairs]),
                unrestricted_mean_other_plan_gap=mean([p['unrestricted_other_plan_gap'] for p in pairs]),
                mean_centered_estimate_difference=mean([p['centered_estimate_difference'] for p in pairs]))
        results.append(dict(id=case,tick=tick,factual_owner=rows[0]['factual_owner'],counts=counts))
    summary={}
    for count in ('3','8'):
        values=[r['counts'][count] for r in results]
        summary[count]=dict(roots=len(values),
            varying_action_roots=sum(v['unique_actions']>1 for v in values),
            varying_plan_roots=sum(v['unique_plans']>1 for v in values),
            differing_plan_same_action_roots=sum(v['unique_actions']==1 and v['unique_plans']>1 for v in values),
            persona_tier_varies_roots=sum(v['persona_tier_varies'] for v in values),
            selected_plan_rejected_by_other_tier=sum(v['selected_plan_rejected_by_other_tier'] for v in values),
            same_action_but_changed_commit_pairs=sum(v['same_action_but_changed_commit_pairs'] for v in values),
            unrestricted_mean_other_root_gap=mean([v['unrestricted_mean_other_root_gap'] for v in values]),
            unrestricted_mean_other_tail_gap=mean([v['unrestricted_mean_other_tail_gap'] for v in values]))
    result=dict(complete=True,adoption=False,at=datetime.now(timezone.utc).isoformat(),
        receipt_sha256=sha(receipt_raw),plan_sha256=sha(plan_raw),
        script_sha256=sha(Path(__file__).read_bytes()),source_receipt=str(execution/'verification.json'),
        source_ref=plan['source_ref'],registered_evaluations=len(receipt['rows']),
        new_forecasts=0,new_worlds=0,summary=summary,roots=results,
        limits=['All registered known-loss roots retained; not representative of ordinary states.',
                'Different banks of the same sample count are disjoint. Three- and eight-sample banks overlap and are not independent.',
                'Cross-bank gaps measure model-estimate selection sensitivity, not actual regret or causal long-play loss.',
                'Unrestricted gaps include proposals excluded by personality. They are accounting only, never an available improvement or intelligence error.',
                'A fixed plan is the same controller with different imagined observations, not an identical future trajectory.',
                'Same factual commit inputs compares the stored action/context/next-state packet; it is not a new feedback replay.',
                'Persona purpose sacrifice is recorded separately; no personality or selection rule is changed.',
                'No statistical confidence, better action claim, new scientific trial, or adoption follows.'])
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('xb') as stream:stream.write(encoded(result))
    return dict(complete=True,summary=summary,new_forecasts=0,new_worlds=0)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execution',required=True);parser.add_argument('--output',required=True)
    print(json.dumps(account(**vars(parser.parse_args()))))
