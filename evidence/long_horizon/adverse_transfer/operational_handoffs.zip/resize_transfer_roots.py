"""One finite capacity handoff. Scientific children drain without interruption."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

ROOT = Path('/home/ubuntu/recovery/transfer_loss_roots_20261030')
PREFIX = 'capacity_two_20261030'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_bytes())

def alive(pid):
    try:
        return Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()[0] != 'Z'
    except FileNotFoundError:
        return False

def save(value):
    target = ROOT / (PREFIX + '_state.json')
    temporary = target.with_suffix('.new')
    temporary.write_text(json.dumps(value, sort_keys=True), encoding='utf8')
    temporary.replace(target)

def main():
    with (ROOT / (PREFIX + '.lock')).open('x'):
        manifest = read(ROOT / 'manifest.json')
        assert sha(ROOT / 'manifest.json') == '512bc6945c9e009ce930130bdf552d1da28b5c141a6257b2b74b00063bdc5f88'
        for name, field in [('driver.py', 'driver_sha256'), ('probe_registered_owner.py', 'probe_sha256'), ('plan.json', 'plan_sha256')]:
            assert sha(ROOT / name) == manifest[field]
        assert read(ROOT.parent / 'purpose_tail_root_20261030/comparison.json')['complete']
        prior = read(ROOT / 'status.json'); parent = prior['pid']
        assert prior['state'] == 'running' and parent == 37874 and prior['local_workers'] == 1
        command = Path(f'/proc/{parent}/cmdline').read_bytes().split(b'\0')
        assert str(ROOT / 'driver.py').encode() in command and str(ROOT).encode() in command
        request = dict(parent=parent, prior=prior, new_workers=2, source_sha256=sha(__file__),
                       manifest_sha256=sha(ROOT / 'manifest.json'), reason='Completed finite H32 causal comparison frees one local CPU slot.')
        (ROOT / (PREFIX + '_request.json')).write_text(json.dumps(request, sort_keys=True), encoding='utf8')
        state = dict(state='draining', pid=os.getpid(), parent=parent, complete=False, adoption=False)
        save(state)
        os.kill(parent, signal.SIGINT)
        pids = [parent] + [v['child_pid'] for v in prior['active'].values()]
        while any(alive(pid) for pid in pids):
            time.sleep(5)
        status = read(ROOT / 'status.json')
        assert status['state'] == 'failed' and status['error'] == 'KeyboardInterrupt()'
        acknowledgement = sha(ROOT / 'status.json')
        (ROOT / (PREFIX + '_drained.json')).write_bytes((ROOT / 'status.json').read_bytes())
        source_plan = Path(manifest['worker']) / manifest['source_plan']
        os.environ.update(read(source_plan)['arithmetic'])
        os.environ.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
        with (ROOT / (PREFIX + '.stdout.log')).open('xb') as out, (ROOT / (PREFIX + '.stderr.log')).open('xb') as err:
            child = subprocess.Popen([sys.executable, '-u', str(ROOT / 'driver.py'), '--root', str(ROOT),
                                      '--workers', '2', '--acknowledge-interruption', acknowledgement],
                                     stdout=out, stderr=err, start_new_session=True)
        state.update(state='complete', complete=True, resumed_parent=child.pid, workers=2,
                     interruption_acknowledgement=acknowledgement, source_sha256=sha(__file__))
        save(state)

if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        save(dict(state='failed', complete=False, error=repr(error), pid=os.getpid()))
        raise
