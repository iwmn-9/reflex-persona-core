"""One-off priority handoff of an already registered diagnostic; no new science."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time

ROOT = Path('/home/ubuntu/recovery/transfer_loss_roots_20261030')


def read(name):
    return json.loads((ROOT / name).read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def alive(pid):
    try:
        return Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()[0] != 'Z'
    except FileNotFoundError:
        return False


def save(row):
    tmp = ROOT / 'priority_handoff_state.new'
    tmp.write_text(json.dumps(row, sort_keys=True), encoding='utf-8')
    tmp.replace(ROOT / 'priority_handoff_state.json')


def main():
    request = read('priority_handoff_request.json')
    manifest = read('manifest.json')
    assert sha(ROOT / 'manifest.json') == request['manifest_sha256']
    assert sha(ROOT / 'driver.py') == manifest['driver_sha256']
    assert sha(ROOT / 'probe_registered_owner.py') == manifest['probe_sha256']
    assert sha(ROOT / 'plan.json') == manifest['plan_sha256']
    source_plan = Path(manifest['worker']) / manifest['source_plan']
    os.environ.update(json.loads(source_plan.read_bytes())['arithmetic'])
    os.environ.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
    state = dict(pid=os.getpid(), state='draining_registered_child', adoption=False,
                 source_sha256=sha(__file__), request_sha256=sha(ROOT / 'priority_handoff_request.json'))
    with (ROOT / 'priority_handoff.lock').open('x'):
        save(state)
        prior_pids = [request['parent']] + [v['child_pid'] for v in request['prior_status']['active'].values()]
        while any(alive(pid) for pid in prior_pids):
            time.sleep(5)
        status = read('status.json')
        assert status['state'] == 'failed' and status['error'] == 'KeyboardInterrupt()'
        (ROOT / 'priority_handoff_drained_status.json').write_bytes((ROOT / 'status.json').read_bytes())
        acknowledge = sha(ROOT / 'status.json')
        plan = read('plan.json'); index = request['priority_index']; job = plan['jobs'][index]
        original_path = ROOT / 'inputs' / job['input_archive_member']
        assert sha(original_path) == job['input_sha256']
        output = ROOT / f'root-{index:03}.json'
        assert not output.exists()
        args = [sys.executable, str(ROOT / 'probe_registered_owner.py'),
                '--worker', manifest['worker'], '--plan', str(Path(manifest['worker']) / manifest['source_plan']),
                '--input', str(original_path), '--input-sha256', job['input_sha256'],
                '--tick', str(job['tick']), '--start', str(job['start']), '--samples', str(job['samples']),
                '--output', str(output)]
        with (ROOT / 'priority_probe.stdout.log').open('xb') as out, (ROOT / 'priority_probe.stderr.log').open('xb') as err:
            child = subprocess.Popen(args, stdout=out, stderr=err)
            state.update(state='registered_priority_probe', child=child.pid, index=index, job=job)
            save(state)
            code = child.wait()
            if code:
                raise subprocess.CalledProcessError(code, args)
        spec = importlib.util.spec_from_file_location('frozen_driver', ROOT / 'driver.py')
        driver = importlib.util.module_from_spec(spec); spec.loader.exec_module(driver)
        assert driver.validate(job, read(output.name), json.loads(original_path.read_bytes()),
                               plan['registration'], manifest['probe_sha256'])
        analyzer = ROOT / 'diagnose_goal_mean_alignment.py'
        assert sha(analyzer) == '44f270b718d4b7d00135fe4225ab6e0703d8d23a43c8f1345955a1b6fbff8683'
        subprocess.run([sys.executable, str(analyzer), '--worker', manifest['worker'],
                        '--source-plan', manifest['source_plan'], '--probe', str(ROOT / 'probe_registered_owner.py'),
                        '--source', str(output), '--output', str(ROOT / f'goal-mean-{index:03}.json')], check=True)
        assert sha(ROOT / 'status.json') == acknowledge
        with (ROOT / 'priority_resume.stdout.log').open('xb') as out, (ROOT / 'priority_resume.stderr.log').open('xb') as err:
            parent = subprocess.Popen([sys.executable, '-u', str(ROOT / 'driver.py'), '--root', str(ROOT),
                                       '--workers', '1', '--acknowledge-interruption', acknowledge],
                                      stdout=out, stderr=err, start_new_session=True)
        state.update(state='complete', complete=True, priority_result_sha256=sha(output),
                     original_control_exact=True, resumed_parent=parent.pid,
                     resumed_workers=1, interruption_acknowledgement=acknowledge)
        save(state)


if __name__ == '__main__':
    try:
        main()
    except BaseException as exc:
        save(dict(state='failed', complete=False, error=repr(exc), pid=os.getpid()))
        raise
