"""Repair a SIGINT-ignored coordinator handoff without interrupting its probes."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import signal
import subprocess
import sys
import time

ROOT=Path('/home/ubuntu/recovery/transfer_loss_roots_20261030')
PREFIX='capacity_three_recovery'

def read(path):return json.loads(Path(path).read_bytes())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def proc(pid):
    try:
        p=Path(f'/proc/{pid}');s=p.joinpath('stat').read_text().rsplit(')',1)[1].split()
        return dict(pid=pid,state=s[0],parent=int(s[1]),command=p.joinpath('cmdline').read_bytes().split(b'\0'))
    except FileNotFoundError:return None
def alive(pid):
    p=proc(pid);return p is not None and p['state']!='Z'
def serial(p):return dict(p,command=[s.decode() for s in p['command']])
def save(value):
    p=ROOT/(PREFIX+'_state.json');t=p.with_suffix('.new')
    t.write_text(json.dumps(value,sort_keys=True),encoding='utf8');t.replace(p)

def main():
    with (ROOT/(PREFIX+'.lock')).open('x'):
        manifest=read(ROOT/'manifest.json')
        assert sha(ROOT/'manifest.json')=='512bc6945c9e009ce930130bdf552d1da28b5c141a6257b2b74b00063bdc5f88'
        assert sha(ROOT/'driver.py')==manifest['driver_sha256']
        assert sha(ROOT/'probe_registered_owner.py')==manifest['probe_sha256']
        parent=proc(38857);helper=proc(39589)
        assert parent and str(ROOT/'driver.py').encode() in parent['command']
        assert helper and b'resize_transfer_roots_three.py' in helper['command']
        assert read(ROOT/'capacity_three_20261030_state.json')['state']=='draining'
        ignored=next(line.split()[1] for line in Path('/proc/38857/status').read_text().splitlines() if line.startswith('SigIgn:'))
        assert int(ignored,16)&(1 << (signal.SIGINT-1)), 'The ordinary cooperative stop must be used when available'
        os.kill(39589,signal.SIGTERM)
        os.kill(38857,signal.SIGSTOP)
        terminated=False
        try:
            children=[]
            for path in Path('/proc').iterdir():
                if path.name.isdigit():
                    item=proc(int(path.name))
                    if item and item['parent']==38857 and item['state']!='Z':
                        assert str(ROOT/'probe_registered_owner.py').encode() in item['command']
                        children.append(item)
            assert children
            prior=(ROOT/'status.json').read_bytes();prior_value=json.loads(prior)
            assert prior_value['pid']==38857 and prior_value['state']=='running'
            request=dict(parent=serial(parent),children=[serial(c) for c in children],
                prior_status=prior_value,prior_status_sha256=sha(ROOT/'status.json'),
                ignored_signal_mask=ignored,source_sha256=sha(__file__),workers=3,
                reason='Background launch inherited SIGINT ignore. Stop only the verified coordinator; all scientific children run to completion. Reset SIGINT handling for the replacement.')
            (ROOT/(PREFIX+'_request.json')).write_text(json.dumps(request,sort_keys=True),encoding='utf8')
            state=dict(pid=os.getpid(),state='draining_orphaned_scientific_children',complete=False,adoption=False,
                       children=[c['pid'] for c in children],parent=38857)
            save(state)
            os.kill(38857,signal.SIGTERM);os.kill(38857,signal.SIGCONT);terminated=True
        finally:
            if not terminated and alive(38857):os.kill(38857,signal.SIGCONT)
        while alive(38857) or any(alive(c['pid']) for c in children):time.sleep(5)
        spec=importlib.util.spec_from_file_location('fixed_driver',ROOT/'driver.py')
        driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
        plan=read(ROOT/'plan.json');completed=[]
        for child in children:
            command=child['command'];output=Path(command[command.index(b'--output')+1].decode())
            index=int(output.stem.split('-')[1]);job=plan['jobs'][index]
            original=read(ROOT/'inputs'/job['input_archive_member'])
            driver.validate(job,read(output),original,plan['registration'],manifest['probe_sha256'])
            completed.append(dict(index=index,file=output.name,sha256=sha(output)))
        with driver.exclusive(ROOT/'queue.lock'):
            assert (ROOT/'status.json').read_bytes()==prior
            (ROOT/(PREFIX+'_original_status.json')).write_bytes(prior)
            handoff=dict(prior_value,state='interrupted_for_capacity_handoff',complete=False,active={},
                         expected_interruption=True,reason=request['reason'],drained_children=completed)
            driver.save(ROOT/'status.json',handoff)
            acknowledge=sha(ROOT/'status.json')
            (ROOT/(PREFIX+'_drained_status.json')).write_bytes((ROOT/'status.json').read_bytes())
        source_plan=Path(manifest['worker'])/manifest['source_plan']
        os.environ.update(read(source_plan)['arithmetic'])
        os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
        signal.signal(signal.SIGINT,signal.default_int_handler)
        with (ROOT/(PREFIX+'.stdout.log')).open('xb') as out,(ROOT/(PREFIX+'.stderr.log')).open('xb') as err:
            replacement=subprocess.Popen([sys.executable,'-u',str(ROOT/'driver.py'),'--root',str(ROOT),
                '--workers','3','--acknowledge-interruption',acknowledge],stdout=out,stderr=err,start_new_session=True)
        state.update(state='complete',complete=True,resumed_parent=replacement.pid,workers=3,
            interruption_acknowledgement=acknowledge,drained_children=completed,source_sha256=sha(__file__))
        save(state)

if __name__=='__main__':
    try:main()
    except BaseException as error:
        save(dict(state='failed',complete=False,pid=os.getpid(),error=repr(error)));raise
