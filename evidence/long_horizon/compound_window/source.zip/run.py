"""Long-play diagnosis of perpetual preparation postponement, not adoption."""
import copy,hashlib,json,shutil,sys,time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed


def execution(root,spec,mode):
    import numpy as np
    from compound_adapter import Compound
    from reflex.closed_loop import owned_rollout,DecisionWindow
    from reflex.core import digest,character_key
    from reflex.decision_loop import DecisionLoop
    from reflex.model_observer import resolve_feedback
    from tools.run_owned_value import cumulative_basis
    from tools.owned_checkpoint import OwnedCheckpoint,encoded,sha
    root=Path(root);out=root/f"length-{spec['length']}-shock-{int(spec['shock'])}"/mode
    out.mkdir(parents=True,exist_ok=True)
    config=dict(**spec,mode=mode,tree_horizon=6,turns=128,
        driver=sha(Path(__file__).read_bytes()),
        adapter=sha(Path(__file__).with_name('compound_adapter.py').read_bytes()))
    g=Compound(spec['length'],payout=spec['length']*2+4,turns=128)
    w=g.start();a=g.actor(g.context(w),learning='segmented')
    fixed=character_key(g.context(w));window=DecisionWindow(g.context(w),6)
    storage=OwnedCheckpoint(out/'checkpoint.json',('compound',0,0,'public-shock' if spec['shock'] else 'constant',128,1,5,0),
        mode,configuration=config,every=1)
    trace=[];rng=np.random.default_rng(0);checks=dict(owner_parity=0,fixed_axes=0);start=time.monotonic()
    if storage.saved is not None:
        saved=storage.saved;trace=saved['trace'];w=saved['world'];checks=saved['checks']
        a=DecisionLoop.from_record(g.context(trace[-1]['before']),saved['owner'],predictor=a.predictor)
        window=DecisionWindow.from_record(g.context(w),trace[-1]['window'])
        start-=saved['elapsed'];rng.bit_generator.state=saved['rng']
    while not g.terminal(w):
        c=g.context(w);req=g.request(c);before=digest(a.record());clone=copy.deepcopy(a)
        horizon=window.remaining(c) if mode=='fixed-window' else 6
        ctrl=owned_rollout(a,observe=g.context,events=g.events,terminal=g.terminal,
            assess=lambda w:g.goal(w).record(),record=lambda w:w,request_for=g.request,
            feedback=g.feedback,model_id=digest(['compound',spec['length']]),target=g.target,
            tree_steps=horizon,tail_steps=0,world_model='posterior',future_choices='planned',
            cumulative_preference=cumulative_basis(g,True))
        cap={};planner=ctrl.planner(a,req,w,captured=cap)
        def complete(cs,ds):
            f=planner(cs,ds)
            if f is None:raise ValueError('incomplete forecast; no fallback')
            return f
        result=DecisionLoop.decide_batch([(a,req)],False,complete)[0];key=result['decision']['action_id']
        after,flow=g.transition(w,key,'0')
        if spec['shock'] and after['tick']==64:after['payout']=2.
        fb=g.feedback(w,after,key,c,flow);resolve_feedback(a,result['ticket'],fb)
        forced=DecisionLoop.decide_batch([(clone,req)],False,_counterfactual_roots=(key,))[0]
        resolve_feedback(clone,forced['ticket'],fb)
        assert digest(a.record())==digest(clone.record()) and character_key(result['context'])==fixed
        window.advance(c)
        trace.append(dict(tick=w['tick'],before=w,action=key,after=after,before_owner=before,
            owner=digest(a.record()),window=window.record(),horizon=horizon))
        w=after
        checks['owner_parity']+=1;checks['fixed_axes']+=1
        storage.save(w,a,rng,trace,checks,time.monotonic()-start,terminal=g.terminal(w))
        if len(trace)%32==0:print(json.dumps(dict(**spec,mode=mode,turns=len(trace),cash=w['cash'])),flush=True)
    state=g.start()
    for t in trace:
        assert state==t['before']
        state,_=g.transition(state,t['action'],'0')
        if spec['shock'] and state['tick']==64:state['payout']=2.
        assert state==t['after']
    assert state==w and len(trace)==128 and checks==dict(owner_parity=128,fixed_axes=128)
    result=dict(config=config,final=w,trace=trace,checks=checks,seconds=time.monotonic()-start,
        preparations=[t['tick'] for t in trace if t['action']=='y'])
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    return result


def pair(root,spec):
    rows=[execution(root,spec,mode) for mode in ('rolling','fixed-window')]
    result=dict(**spec,cash=[r['final']['cash'] for r in rows],
        delta=rows[1]['final']['cash']-rows[0]['final']['cash'],
        preparations=[r['preparations'] for r in rows],seconds=[r['seconds'] for r in rows])
    print(json.dumps(result),flush=True);return result


if __name__=='__main__':
    if '--frozen' not in sys.argv:
        R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R))
        root=R/'results/compound_window_diagnostic_v2'
        from tools.freeze_experiment import freeze
        # Check public payout causality before committing compute to the run.
        sys.path.insert(0,str(R/'results'))
        from probe_compound_preparation import Compound
        g=Compound(5,payout=14,turns=128);w=g.start();w.update(stage=4,cash=8)
        high=g.transition(w,'y','0')[0]
        changed=dict(w,payout=2.)
        low=g.transition(changed,'y','0')[0]
        assert high['cash']==21. and low['cash']==9.
        assert g.events(changed,'y')[0].public==low
        freeze(root)
        shutil.copyfile(__file__,root/'run.py')
        shutil.copyfile(R/'results/probe_compound_preparation.py',root/'compound_adapter.py')
        import subprocess
        subprocess.run([sys.executable,'-u',str(root/'run.py'),'--frozen'],check=True)
    else:
        root=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'_source'))
        manifest=json.loads((root/'source_snapshot.json').read_bytes())
        for f,sha in manifest.items():assert hashlib.sha256((root/'_source'/f).read_bytes()).hexdigest()==sha
        spec=[dict(length=n,shock=s) for n in (3,5) for s in (False,True)]
        reg=dict(cases=spec,turns=128,horizon=6,modes=['rolling','fixed-window'],
            semantics='Exact same-persona conditional search; only retained evaluation deadline differs. Recompute choices after every real observation; no forced action or future shock access. Selected deterministic mechanism test, not game-family confirmation.',
            driver=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            adapter=hashlib.sha256((root/'compound_adapter.py').read_bytes()).hexdigest())
        path=root/'registration.json'
        if path.exists():assert json.loads(path.read_bytes())==reg
        else:path.write_text(json.dumps(reg,indent=2)+'\n',encoding='utf8')
        with ProcessPoolExecutor(max_workers=2) as pool:
            rows=[f.result() for f in as_completed([pool.submit(pair,root,s) for s in spec])]
        for n in (3,5):
            for mode in ('rolling','fixed-window'):
                traces=[json.loads((root/f'length-{n}-shock-{s}'/mode/'result.json').read_bytes())['trace'] for s in (0,1)]
                for a,b in zip(traces[0][:64],traces[1][:64]):
                    assert all(a[k]==b[k] for k in ('before','action','before_owner'))
        (root/'summary.json').write_text(json.dumps(dict(complete=True,results=rows,identical_pre_shock_prefixes=4),indent=2)+'\n',encoding='utf8')
