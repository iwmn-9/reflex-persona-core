"""Post-hoc mechanism probe, no production or registered actor changes."""
import copy,json,sys,time
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R))
import numpy as np
from tools.preparation_world import DelayedYield
from tools.run_owned_value import cumulative_basis
from reflex.examples import effect
from reflex.closed_loop import owned_rollout
from reflex.core import digest
from reflex.decision_loop import DecisionLoop


class Compound(DelayedYield):
    def start(self):
        w=super().start();w['stage']=0;return w

    def keys(self,w):
        return () if self.terminal(w) else ('x',)+(('y',) if w['cash']>=1 else ())

    def transition(self,w,key,symbol):
        assert key in self.keys(w)
        n=copy.deepcopy(w);n.update(tick=w['tick']+1,signal='0',last=key)
        if key=='x':n['cash']+=1
        else:
            n['cash']-=1;n['stage']+=1
            if n['stage']==self.delay:n['stage']=0;n['cash']+=w['payout']
        gain=float(np.clip((n['cash']-w['cash'])/12,-1,1))
        return n,effect(gain,needs={'growth':gain,'safety':0.},values={'achievement':gain})


def choose(g,tree,tail,planned):
    w=g.start();c=g.context(w);a=g.actor(c,learning='segmented')
    before=digest(a.record());req=g.request(c);capture={}
    ctrl=owned_rollout(a,observe=g.context,events=g.events,terminal=g.terminal,
        assess=lambda w:g.goal(w).record(),record=lambda w:w,request_for=g.request,
        feedback=g.feedback,model_id=digest(['compound',g.delay,g.payout]),target=g.target,
        tree_steps=tree,tail_steps=tail,seeds=(701,),world_model='posterior',
        future_choices='planned' if planned else 'reflex',
        cumulative_preference=cumulative_basis(g,True))
    start=time.monotonic()
    result=DecisionLoop.decide_batch([(copy.deepcopy(a),req)],False,ctrl.planner(a,req,w,captured=capture))[0]
    assert digest(a.record())==before
    return dict(action=result['decision']['action_id'],seconds=time.monotonic()-start,
                complete=ctrl.last['complete'],nodes=ctrl.last['nodes'])


if __name__=='__main__':
    out=[]
    for length in (3,5,7):
        g=Compound(length,payout=length*2+4,turns=24)
        for mode,tree,tail,planned in [('long_reflex',1,15,False),('composed',length+1,0,True)]:
            row=dict(length=length,mode=mode,**choose(g,tree,tail,planned));out.append(row)
            print(json.dumps(row),flush=True)
    (R/'results/compound_preparation_probe.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
