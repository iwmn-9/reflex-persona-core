"""Record completed regression and a reverted OS-only priority pilot."""
import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

here = Path(__file__).resolve().parent
base = here.parents[2]
root = base / 'reflex-persona-core'
candidate = base / 'reflex-persona-relative-worlds'
regression = candidate / 'results/relative_full_regression_20261101'
out = root / 'evidence/long_horizon/relative_world_preparation'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def encoded(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

status = read(regression / 'status.json')
sources = read(regression / 'sources.json')
assert status['complete'] and status['passed'] and status['tests'] == 1383
assert len(status['skipped']) == 19 and not any(status[k] for k in ('failures','errors','unexpected_successes'))
assert len(sources) == 612 and sha(encoded(sources)) == status['source_sha256']
assert sha((regression/'tests.log').read_bytes()) == status['log_sha256']
assert all(sha((candidate/name).read_bytes()) == checksum for name,checksum in sources.items())
archive = out / 'source_regression.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name in ('status.json','sources.json','tests.log'):
        z.write(regression/name,name)
    z.write(here/'run_relative_regression.py','run_relative_regression.py')
    z.write(__file__,Path(__file__).name)
proof = dict(complete=True,adoption=False,world_quality_evidence=False,
    source_ref=status['source_commit'],source_sha256=status['source_sha256'],source_files=len(sources),
    tests=1383,passed=1364,skipped=19,failures=0,errors=0,
    skips='17 optional mahjong engine/environment tests; 2 Linux-specific process controls.',
    artifacts={'source_regression.zip':sha(archive.read_bytes())})
(out/'source_regression.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')

normal = read(here/'relative_critical_priority_reverted.json')
assert normal['all_normal'] and normal['all_advanced']
assert all(row['cpu_before'] is not None and row['cpu_delta'] > 0 for row in normal['workers'])
pilot = read(here/'relative_critical_priority_measurement.json')
assert any(row['cpu_before'] is None for row in pilot['workers'])
pilot_out = root/'evidence/long_horizon/gain_world_operation'
archive = pilot_out/'critical_priority_reverted.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name in ('relative_critical_priority/launch.json','relative_critical_priority_handoff.json',
                 'relative_critical_priority_measurement.json','relative_critical_priority_reverted.json',
                 'relative_world_priority_resumed/launch.json','prioritize_relative_critical_path.ps1',
                 'prioritize_relative_worlds_resumed.ps1'):
        z.write(here/name,name)
pilot_proof = dict(adopted=False,priority_restored='Normal',scientific_workers=len(normal['workers']),
    all_observed_workers_advanced=True,reverted_at=normal['utc'],source_or_rng_changed=False,
    scientific_worker_restarted=False,old_helper=28700,pilot_helper=13860,current_normal_helper=1836,
    reasons=['Operation commands experienced substantial delay; causal scheduling attribution is unproven.',
             'The pilot CPU-delta sample is INVALID: UInt32 versus Int32 dictionary keys lost the baselines. It cannot establish progress or speedup.',
             'After restoration a corrected string-key sample verified all20 workers Normal and progressing.'],
    archive_sha256=sha(archive.read_bytes()))
(pilot_out/'critical_priority_reverted.json').write_text(json.dumps(pilot_proof,indent=2)+'\n',encoding='utf-8')

resume_path = root/'results/long_horizon_resume_status.json'
resume = read(resume_path)
resume['updated'] = datetime.now(timezone.utc).isoformat()
resume['relative_integration']['full_regression'].update(state='complete_passed',pid=None,
    original_pid=9856,tests=1383,passed=1364,skipped=19,failures=0,errors=0,
    evidence=str(out/'source_regression.json'),repeat=False)
resume['active_worlds']['relative']['priority'].update(helper_pid=1836,
    script='prioritize_relative_worlds_resumed.ps1',root='relative_world_priority_resumed',
    scope='At most4 registered candidate children Normal; old Q/G also Normal. AboveNormal pilot reverted; helpers28700/13860 retired.')
resume['operational']['cpu_fairness']['priority']='Normal for all Q/G/N scientific workers; regression9856 completed.'
resume['operational']['cpu_fairness']['rejected_priority_pilot']=str(pilot_out/'critical_priority_reverted.json')
resume['next_actions'][1]='N regression9856 completed successfully and must not be repeated. Finite post-audit25740 already holds its completion handle and still waits for Nfinisher27664 before its registered archive/package replay.'
resume['completed']['purpose_pair_accounts']=dict(root=str(here/'purpose_completed_pairs'),
    cases=['auction-0-10061201-outside','auction-2-10061202-shift-return','auction-3-10061202-shift-return'],
    scope='Only finished pairs,128actual steps per arm. Full audit +every recorded selection +forecast/execution accounting. No root selection, cohort gate or adoption.',
    newest=dict(case='auction-0-10061201-outside',score_delta=-0.0068359375,
        conditional_delta=-0.016479492187499986,reference_choice_delta=0.002922957820125638,
        note='Own raw score149 versus146 is not total goal; rival score20 versus10 matters. Better forecast accuracy does not certify better total outcome.'))
resume_path.write_text(json.dumps(resume,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(dict(regression=proof,priority_pilot=pilot_proof),indent=2))
