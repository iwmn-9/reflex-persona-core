"""One local full regression of the fixed integrated experimental source."""
import ctypes,hashlib,json,os,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
import unittest
def sha(raw):return hashlib.sha256(raw).hexdigest()
def enc(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
local=Path(__file__).resolve().parent;base=local.parents[2]
source=base/'reflex-persona-relative-worlds'
output=source/'results/relative_full_regression_20261101'
output.mkdir(exist_ok=False)
if os.name=='nt':
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.GetCurrentProcess.restype=ctypes.c_void_p
    kernel.SetPriorityClass.argtypes=(ctypes.c_void_p,ctypes.c_uint)
    if not kernel.SetPriorityClass(kernel.GetCurrentProcess(),0x4000):raise ctypes.WinError(ctypes.get_last_error())
os.environ.update(NPY_DISABLE_CPU_FEATURES='AVX512F,AVX512CD,AVX512_SKX,AVX512_CLX,AVX512_CNL,AVX512_ICL',
    OPENBLAS_CORETYPE='Haswell',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
os.chdir(source);sys.path.insert(0,str(source));sys.path.insert(1,str(source/'tests'))
sources={p.relative_to(source).as_posix():sha(p.read_bytes()) for folder in ('reflex','tools','tests')
    for p in (source/folder).rglob('*.py')}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
assert head=='493a685ab2837c999d13d832dc25a51068845fb5'
status=dict(state='running',complete=False,pid=os.getpid(),source_commit=head,
    started=datetime.now(timezone.utc).isoformat(),source_sha256=sha(enc(sources)),
    script_sha256=sha(Path(__file__).read_bytes()),adoption=False)
(output/'sources.json').write_bytes(enc(sources));(output/'status.json').write_bytes(enc(status))
started=time.perf_counter()
suite=unittest.defaultTestLoader.discover(str(source/'tests'))
with (output/'tests.log').open('w',encoding='utf-8') as stream:
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
assert all(sha((source/name).read_bytes())==h for name,h in sources.items())
status.update(state='complete',complete=True,passed=result.wasSuccessful(),tests=result.testsRun,
    failures=[(str(test),trace) for test,trace in result.failures],errors=[(str(test),trace) for test,trace in result.errors],
    skipped=[(str(test),reason) for test,reason in result.skipped],
    unexpected_successes=[str(test) for test in result.unexpectedSuccesses],
    expected_failures=[(str(test),trace) for test,trace in result.expectedFailures],
    elapsed_seconds=time.perf_counter()-started,finished=datetime.now(timezone.utc).isoformat(),
    log_sha256=sha((output/'tests.log').read_bytes()),
    limits='Full local source regression. Not new long-world quality evidence, not a cohort passage, not a stable release.')
(output/'status.json').write_bytes(enc(status))
print(json.dumps({k:status[k] for k in ('complete','passed','tests','elapsed_seconds')}),flush=True)
sys.exit(0 if result.wasSuccessful() else 1)
