"""Finite post-audit dependency chain. No repeating task or scientific launch."""
import ctypes,json,os,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
from prepare_reserved_purpose_confirmation import read,encoded,sha


def wait_existing(pid):
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes=(ctypes.c_uint,ctypes.c_int,ctypes.c_uint)
    kernel.OpenProcess.restype=ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes=(ctypes.c_void_p,ctypes.c_uint)
    kernel.WaitForSingleObject.restype=ctypes.c_uint
    kernel.CloseHandle.argtypes=(ctypes.c_void_p,)
    handle=kernel.OpenProcess(0x100000,False,pid)
    if not handle:raise RuntimeError('original dependency process absent; inspect rather than restart')
    return kernel,handle


def main():
    local=Path(__file__).resolve().parent;root=local/'relative_post_archive'
    manifest=read(root/'manifest.json');state_path=root/'status.json'
    if state_path.exists():raise FileExistsError('do not duplicate or overwrite a prior post-audit execution')
    state=dict(pid=os.getpid(),state='waiting',complete=False,adoption=False,
        started=datetime.now(timezone.utc).isoformat(),manifest_sha256=sha((root/'manifest.json').read_bytes()))
    def save():
        state['updated']=datetime.now(timezone.utc).isoformat()
        tmp=state_path.with_suffix('.new');tmp.write_bytes(encoded(state));tmp.replace(state_path)
    def sources():
        for name,checksum in manifest['files'].items():
            if sha(Path(name).read_bytes())!=checksum:raise ValueError('registered operational source changed: '+name)
    handles=[]
    try:
        sources()
        for pid in manifest['dependency_pids']:handles.append(wait_existing(pid))
        save()
        for kernel,handle in handles:
            if kernel.WaitForSingleObject(handle,0xFFFFFFFF)!=0:raise RuntimeError('dependency wait failed')
        sources()
        end=read(Path(manifest['finisher_status']))
        if (end.get('complete') is not True or end.get('state')!='complete_requires_scientific_review'
                or end['manifest_sha256']!=manifest['finisher_manifest_sha256']):
            raise RuntimeError('whole world and diagnostic archive did not finish; no package success claim')
        regression=read(Path(manifest['regression_status']))
        if regression.get('complete') is not True or regression.get('passed') is not True:
            raise RuntimeError('full regression did not pass')
        for step in manifest['steps']:
            sources();state['state']=step['kind'];save()
            with (root/(step['kind']+'.stdout.log')).open('wb') as stdout, (root/(step['kind']+'.stderr.log')).open('wb') as stderr:
                child=subprocess.Popen([sys.executable,*step['args']],cwd=local,
                    env=dict(os.environ,**manifest['arithmetic']),stdout=stdout,stderr=stderr,
                    creationflags=subprocess.CREATE_NO_WINDOW)
                state['child_pid']=child.pid;save();code=child.wait()
            state.pop('child_pid',None)
            if code:raise subprocess.CalledProcessError(code,step['args'])
            proof=read(Path(step['proof']))
            if proof.get('complete') is not True:raise ValueError('complete post-audit proof required')
            if step['kind']=='package_history' and (proof['executions'],proof['actual_steps'])!=(20,2560):
                raise ValueError('entire original development comparison must replay')
        state.update(state='complete_requires_scientific_review',complete=True);save()
    except BaseException as error:
        state.update(state='failed_requires_inspection',error=repr(error));save();raise
    finally:
        for kernel,handle in handles:kernel.CloseHandle(handle)


if __name__=='__main__':main()
