"""Bind one post-audit package replay, without launching any world calculation."""
from datetime import datetime,timezone
from pathlib import Path
import json,subprocess
from prepare_reserved_purpose_confirmation import read,encoded,sha
local=Path(__file__).resolve().parent;base=local.parents[2]
source=base/'reflex-persona-relative-worlds'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()=='493a685ab2837c999d13d832dc25a51068845fb5'
finisher=local/'relative_world_finish'
finisher_sha=sha((finisher/'manifest.json').read_bytes())
assert finisher_sha=='4bf817ede8ad9cde3af03ae1821545985e8cbf580f64adfd05e825e4dd6348c3'
files={str(local/n):sha((local/n).read_bytes()) for n in ('finish_relative_post.py',
    'prepare_reserved_purpose_confirmation.py','prepare_reserved_relative_confirmation.py',
    'archive_relative_qualification.py','verify_installed_factual_histories.py',
    'run_relative_regression.py','replay_relative_controls.py','relative_control_replay.json')}
installed=source/'results/relative_installed'
files.update({str(p):sha(p.read_bytes()) for p in (installed/'reflex').glob('*.py')})
assert len(files)==180
worlds=source/'evidence/relative_gain/worlds/completed_local'
root=local/'relative_post_archive';root.mkdir(exist_ok=False)
manifest=dict(version=1,created=datetime.now(timezone.utc).isoformat(),adoption=False,
    recurring=False,launches_scientific_trials=False,dependency_pids=[27664,9856],
    finisher_status=str(finisher/'status.json'),finisher_manifest_sha256=finisher_sha,
    regression_status=str(source/'results/relative_full_regression_20261101/status.json'),
    files=files,arithmetic=read(source/'evidence/relative_gain/worlds/plan.json')['arithmetic'],
    steps=[dict(kind='source_qualification',args=[str(local/'archive_relative_qualification.py')],
        proof=str(source/'evidence/relative_gain/full_regression/verification.json')),
        dict(kind='package_history',args=[str(local/'verify_installed_factual_histories.py'),
            '--archive',str(worlds),'--host',str(source),'--installed',str(installed),
            '--output',str(source/'results/relative_complete_package_replay')],
            proof=str(source/'results/relative_complete_package_replay/verification.json'))],
    limits='Wait for already running world+root finisher and full regression. Complete package checks only; no automatic review, adoption or reserved40 launch.')
(root/'manifest.json').write_bytes(encoded(manifest))
print(json.dumps(dict(prepared=True,launched=False,manifest_sha256=sha(encoded(manifest)))))
