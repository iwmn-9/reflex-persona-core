"""Replay complete audited factual histories through an installed Python owner.

Actions are supplied from the audit. This validates learning/save/restore only;
it never counts as new world-quality evidence or recomputed planning decisions.
"""
import argparse,gzip,hashlib,json,os,platform,sys,zipfile
from contextlib import ExitStack
from pathlib import Path

def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(path):return json.loads(path.read_bytes())

def run(archive,host,installed,output,pairs=()):
    host,installed,output=map(lambda p:Path(p).resolve(),(host,installed,output))
    if output.exists():raise FileExistsError('preserve the prior replay and all original evidence')
    if bool(archive)==bool(pairs):raise ValueError('one complete cohort archive OR completed pair receipts required')
    input_files={};checkpoints={};rows=[];inputs=[]
    if pairs:
        for pair in pairs:
            pair=Path(pair).resolve();proof=read(pair/'verification.json')
            if not proof['pair_complete'] or proof['cohort_complete'] or proof['cohort_gate_evaluated']:
                raise ValueError('explicit complete-pair audit required; partial input is not a cohort')
            files=proof['source_files'];assert all(sha(Path(n).read_bytes())==h for n,h in files.items())
            arms=set(proof['receipts']);assert len(arms)==2 and 'stable' in arms
            inputs.append(dict(path=str(pair),sha256=sha((pair/'verification.json').read_bytes())))
            input_files.update(files);input_files[str(pair/'verification.json')]=inputs[-1]['sha256']
            found=set()
            for n in files:
                if Path(n).name!='checkpoint.json':continue
                checkpoint=read(Path(n));payload=checkpoint['payload'];assert sha(encoded(payload))==checkpoint['sha256']
                result=read(Path(n).with_name('result.json'));arm=result['configuration']['arm']
                spec=proof['spec'];assert arm in arms and arm not in found;found.add(arm)
                assert result['configuration']['spec']==spec and result['complete']
                assert payload['contract']['configuration']==result['configuration']
                assert result['configuration']['registration']==proof['registration']
                assert payload['trace']==result['trace'] and payload['contract']['runtime']==result['runtime']
                assert sha(Path(n).read_bytes())==proof['receipts'][arm]['checkpoint_sha256']
                assert sha((host/'tools/run_adverse_recovery.py').read_bytes())==result['configuration']['runner_sha256']
                assert all(sha((host/'tools'/name).read_bytes())==h for name,h in result['configuration']['adapters'].items())
                rows.append(dict(spec=spec,arm=arm,result=result));checkpoints[(spec['id'],arm)]=checkpoint
                sources=payload['contract']['sources']
                assert all(sha((host/name).read_bytes())==h for name,h in sources.items())
            assert found==arms
        assert len({(r['spec']['id'],r['arm']) for r in rows})==len(rows)
    else:
        archive=Path(archive).resolve()
        proof=read(archive/'verification.json');plan=read(archive/'plan.json');registration=read(archive/'registration.json')
        if not proof['complete']:raise ValueError('complete source/history audit required')
        input_files={str(archive/n):h for n,h in proof['artifacts'].items()}
        assert all(sha(Path(n).read_bytes())==h for n,h in input_files.items())
        assert sha((archive/'plan.json').read_bytes())==registration['plan_sha256']
        assert all(sha((host/n).read_bytes())==h for n,h in registration['sources'].items())
        assert all(os.environ.get(k)==value for k,value in plan['arithmetic'].items())
        rows=[json.loads(line) for line in gzip.decompress((archive/'runs.jsonl.gz').read_bytes()).splitlines()]
        expected={(s['id'],arm) for s in plan['specs'] for arm in plan['arms']}
        assert len(rows)==len(expected)==proof['executions']
        assert {(r['spec']['id'],r['arm']) for r in rows}==expected
        assert sum(len(r['result']['trace']) for r in rows)==proof['actual_steps']
        inputs.append(dict(path=str(archive),sha256=sha((archive/'verification.json').read_bytes())))
    sources={p.relative_to(installed).as_posix():sha(p.read_bytes()) for p in (installed/'reflex').glob('*.py')}
    assert sources
    sys.path[:0]=[str(installed),str(host)]
    import numpy as np
    import reflex
    assert Path(reflex.__file__).resolve().is_relative_to(installed)
    required_arithmetic=dict(NPY_DISABLE_CPU_FEATURES='AVX512F,AVX512CD,AVX512_SKX,AVX512_CLX,AVX512_CNL,AVX512_ICL',
        OPENBLAS_CORETYPE='Haswell',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    assert all(os.environ.get(k)==value for k,value in required_arithmetic.items())
    runtime=dict(python=sys.version,numpy=np.__version__,system=platform.system(),machine=platform.machine())
    if any(row['result']['runtime']!=runtime for row in rows):
        raise ValueError('exact factual replay requires the original Python/NumPy/platform runtime; do not weaken tolerances')
    from reflex.core import digest,character_key
    from reflex.decision_loop import DecisionLoop
    from reflex.experimental_gain import GainHorizonOwner,transfer_event_reader
    from reflex.fixed_horizon import FixedHorizonOwner
    from reflex.receding_owner import RecedingOwner
    from tools.run_continuation_portfolio import game_for
    from tools.run_owned_value import cumulative_basis,law,sample
    def controller(game,arm):
        actor=game.actor(game.context(game.start()),learning='segmented')
        if arm in ('transfer','transfer_purpose','transfer_purpose_gain','transfer_relative_gain'):
            reader=actor.predictor
            assert reader.learner.window==128
            actor.predictor=transfer_event_reader(actor.scope,reader.learner.names,reader.models_for,reader.outcome_for,
                legal_for=reader.legal_for,model_id=game.model_id,known_conditionals=True,
                factors=reader.learner.factors,features_for=reader.features_for,key=reader.key)
            if arm=='transfer_relative_gain':
                from reflex.experimental_gain import RelativeGainHorizonOwner
                cls=RelativeGainHorizonOwner
            else:cls=GainHorizonOwner
        elif arm=='stable':cls=FixedHorizonOwner
        elif arm=='original16':cls=RecedingOwner
        else:raise ValueError('unreviewed historical learner; no automatic conversion')
        opts=dict(observe=game.context,events=game.events,terminal=game.terminal,
            assess=lambda w:game.goal(w).record(),request_for=game.request,feedback=game.feedback,
            model_id=game.model_id,target=game.target,seeds=(701,702,703))
        if arm=='original16':
            opts.update(record=lambda w:w,tail_steps=15,world_model='posterior',purpose_estimator='conditional',tail_recovery=2)
        else:opts.update(horizon=32,recovery_cache=64,cumulative_preference=cumulative_basis(game,True))
        return cls(actor,**opts)
    output.mkdir()
    checks=[]
    with ExitStack() as stack:
        packed=None if pairs else stack.enter_context(zipfile.ZipFile(archive/'checkpoints.zip'))
        for row in rows:
            spec,arm,result=row['spec'],row['arm'],row['result'];game=game_for(spec)
            assert result['complete'] and len(result['trace'])==spec['turns']
            ctrl=controller(game,arm);world=game.start();axes=character_key(game.context(world))
            rng=np.random.default_rng(spec['seed'])
            for event in result['trace']:
                assert world==event['before'] and digest(ctrl.actor.record())==event['before_owner']
                request=game.request(game.context(world,ctrl.actor.state))
                if 'response_prediction' in event:
                    assert ctrl.actor.predictor.predict(request.context)==event['response_prediction']
                chosen=DecisionLoop.decide_batch([(ctrl.actor,request)],False,
                    _counterfactual_roots=(event['action'],))[0]
                truth=law(world['tick'],spec['turns'],spec['regime'])
                assert truth==event['truth'] and sample(truth,rng.random())==event['response']
                after,flow=game.transition(world,event['action'],event['response'])
                ctrl.resolve(chosen['ticket'],game.feedback(world,after,event['action'],chosen['context'],flow))
                if after!=event['after'] or digest(ctrl.actor.record())!=event['owner']:
                    (output/'failure.json').write_bytes(encoded(dict(id=spec['id'],arm=arm,tick=event['tick'],
                        world_matches=after==event['after'],actual_owner=ctrl.actor.record(),
                        expected_owner_sha256=event['owner'],actual_owner_sha256=digest(ctrl.actor.record()),
                        actual_context=chosen['context'],before=world)))
                    raise AssertionError(('factual replay mismatch',spec['id'],arm,event['tick']))
                assert character_key(game.context(after))==axes
                saved=json.loads(encoded(ctrl.checkpoint(after)))
                ctrl=ctrl.restored(after,saved)
                assert ctrl.checkpoint(after)==saved
                assert digest(ctrl.actor.record())==event['owner'];world=after
            final=(checkpoints[(spec['id'],arm)] if pairs else json.loads(packed.read(spec['id']+'/'+arm+'/checkpoint.json')))
            assert sha(encoded(final['payload']))==final['sha256']
            payload=final['payload']
            assert payload['owner']==ctrl.actor.record() and payload['world']==world==result['final']
            assert payload['rng']==rng.bit_generator.state==result['final_rng']
            checks.append(dict(id=spec['id'],arm=arm,steps=len(result['trace']),restores=len(result['trace']),
                final_owner=digest(ctrl.actor.record()),exact=True))
            (output/'progress.json').write_bytes(encoded(dict(completed=len(checks),total=len(rows),last=checks[-1])))
    assert all(sha((installed/n).read_bytes())==h for n,h in sources.items())
    assert all(sha(Path(n).read_bytes())==h for n,h in input_files.items())
    receipt=dict(complete=True,adoption=False,new_worlds=0,recomputed_planning_decisions=0,
        input_audits=inputs,cohort_complete=not bool(pairs),
        installed_sources=sources,installed_source_sha256=sha(encoded(sources)),
        executions=len(checks),actual_steps=sum(r['steps'] for r in checks),checks=checks,runtime=runtime,
        script_sha256=sha(Path(__file__).read_bytes()),
        limits='Every archived factual action was supplied, then actual learning and controller save/restore replayed exactly. This is not a new policy-quality trial or a replacement for full planning parity/independent confirmation.')
    (output/'verification.json').write_bytes(encoded(receipt))
    print(json.dumps({k:receipt[k] for k in ('complete','executions','actual_steps','new_worlds','recomputed_planning_decisions')}),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('host','installed','output'):p.add_argument('--'+name,required=True)
    group=p.add_mutually_exclusive_group(required=True)
    group.add_argument('--archive');group.add_argument('--pairs',nargs='+',default=())
    run(**vars(p.parse_args()))
