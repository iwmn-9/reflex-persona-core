"""Isolated package integration for the frozen relative candidate; no quality claim."""
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

def sha(raw):return hashlib.sha256(raw).hexdigest()
def enc(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
local=Path(__file__).resolve().parent
source=local.parents[2]/'reflex-persona-relative-worlds'
installed=source/'results/relative_installed'
out=source/'results/relative_package_check'
out.mkdir(exist_ok=False)
reg=json.loads((source/'evidence/relative_gain/worlds/registration.json').read_bytes())
assert all(sha((source/name).read_bytes())==h for name,h in reg['sources'].items())
wheel=source/'results/relative_dist/reflex_persona_core-0.1.1.dev0-py3-none-any.whl'
assert sha(wheel.read_bytes())=='e71ee435d38f8d4b3136a7b6432a89ad0dd6d72ac053d598fb864ee8ad345bf1'
files={p.relative_to(source).as_posix():sha(p.read_bytes()) for p in (source/'reflex').glob('*.py')}
assert len(files)==172
assert all(sha((installed/name).read_bytes())==h for name,h in files.items())
os.environ.update(NPY_DISABLE_CPU_FEATURES='AVX512F,AVX512CD,AVX512_SKX,AVX512_CLX,AVX512_CNL,AVX512_ICL',
    OPENBLAS_CORETYPE='Haswell',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
for name in ('stable_host.py','experimental_gain_host.py'):
    subprocess.run([sys.executable,str(source/'tools/verify_stable_host.py'),str(installed),
        '--example',name,'--output',str(out/name.removesuffix('.py'))],check=True,
        stdout=(out/(name+'.stdout.log')).open('w',encoding='utf8'),
        stderr=(out/(name+'.stderr.log')).open('w',encoding='utf8'))
consumer=out/'relative_consumer';consumer.mkdir()
(consumer/'stable_host.py').write_bytes((source/'examples/stable_host.py').read_bytes())
example=(source/'examples/experimental_gain_host.py').read_text(encoding='utf8')
assert example.count('GainHorizonOwner')==2
example=example.replace('GainHorizonOwner','RelativeGainHorizonOwner')
(consumer/'relative_host.py').write_text(example,encoding='utf8')
verifier=source/'tools/verify_stable_host.py'
tree=ast.parse(verifier.read_text(encoding='utf8'))
launch=ast.literal_eval(next(node.value for node in tree.body if isinstance(node,ast.Assign)
    and any(isinstance(t,ast.Name) and t.id=='LAUNCH' for t in node.targets)))
checks=[]
for command in (['--save','full.json'],['--save','prefix.json','--stop-after','3'],
        ['--resume','prefix.json','--save','resumed.json'],['--resume','full.json','--save','terminal.json']):
    result=subprocess.run([sys.executable,'-I','-c',launch,str(installed),str(consumer/'relative_host.py'),*command],
        cwd=consumer,text=True,encoding='utf8',capture_output=True)
    if result.returncode:
        (out/'failure.log').write_text(result.stdout+result.stderr,encoding='utf8')
        raise RuntimeError(result.stderr)
    checks.append(json.loads(result.stdout))
read=lambda name:json.loads((consumer/name).read_bytes())
assert read('full.json')==read('resumed.json')==read('terminal.json')
assert checks[0]['complete'] and checks[1]['tick']==3 and not checks[1]['complete']
assert all(sha((source/name).read_bytes())==h for name,h in reg['sources'].items())
proof=dict(complete=True,adoption=False,published=False,new_quality_trials=False,
    source_registration=dict(plan_sha256=reg['plan_sha256'],source_sha256=sha(enc(reg['sources']))),
    source_package_files_exact=172,wheel_sha256=sha(wheel.read_bytes()),research_imports_blocked=True,
    full_resumed_terminal_world_rng_owner_exact=True,examples=['stable','old-gain','relative-gain'],
    relative_checks=checks,script_sha256=sha(Path(__file__).read_bytes()),
    files={p.relative_to(out).as_posix():sha(p.read_bytes()) for p in out.rglob('*')
        if p.is_file() and '__pycache__' not in p.parts},
    limits='Short API/packaging checks only. No independent world evidence, no new Rust support, no replacement of stable release.')
(out/'verification.json').write_bytes(enc(proof))
print(json.dumps({k:proof[k] for k in ('complete','source_package_files_exact','full_resumed_terminal_world_rng_owner_exact','wheel_sha256')}))
