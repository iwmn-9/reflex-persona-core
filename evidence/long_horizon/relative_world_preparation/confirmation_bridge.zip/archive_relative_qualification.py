"""Archive finished regression and control replay; never claim new world data."""
from datetime import datetime, timezone
from pathlib import Path
import subprocess
from prepare_reserved_purpose_confirmation import encoded, read, sha
from prepare_reserved_relative_confirmation import FROZEN


def archive():
    local=Path(__file__).resolve().parent
    source=local.parents[2]/'reflex-persona-relative-worlds'
    regression=source/'results/relative_full_regression_20261101'
    status=read(regression/'status.json')
    replay=read(local/'relative_control_replay.json')
    sources=read(regression/'sources.json')
    registration=read(source/'evidence/relative_gain/worlds/registration.json')
    if (status.get('complete') is not True or status.get('passed') is not True
            or status['source_commit']!=FROZEN or status['failures'] or status['errors']
            or status['unexpected_successes'] or sources!=registration['sources']
            or status['source_sha256']!=sha(encoded(sources))):
        raise ValueError('whole fixed-source regression must finish successfully')
    if (replay.get('complete') is not True or replay['source']!=FROZEN
            or replay['source_registration']!={'plan_sha256':registration['plan_sha256'],
                'source_sha256':sha(encoded(sources))}
            or replay['controls']!=10 or replay['actual_steps']!=1280):
        raise ValueError('all1280 actual control transitions must replay exactly')
    if any(sha((source/name).read_bytes())!=checksum for name,checksum in sources.items()):
        raise ValueError('frozen source changed')
    if subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()!=FROZEN:
        raise ValueError('source commit changed')
    files={'regression_status.json':(regression/'status.json').read_bytes(),
        'sources.json':(regression/'sources.json').read_bytes(),
        'tests.log':(regression/'tests.log').read_bytes(),
        'control_replay.json':(local/'relative_control_replay.json').read_bytes(),
        'regression_runner.py':(local/'run_relative_regression.py').read_bytes(),
        'control_replay_runner.py':(local/'replay_relative_controls.py').read_bytes()}
    if (sha(files['tests.log'])!=status['log_sha256']
            or sha(files['regression_runner.py'])!=status['script_sha256']
            or sha(files['control_replay_runner.py'])!=replay['script_sha256']):
        raise ValueError('completed evidence or its execution code changed')
    out=source/'evidence/relative_gain/full_regression'
    out.mkdir(exist_ok=False)
    for name,raw in files.items():(out/name).write_bytes(raw)
    proof=dict(complete=True,adoption=False,world_quality_evidence=False,
        at=datetime.now(timezone.utc).isoformat(),source_ref=FROZEN,
        source_sha256=sha(encoded(sources)),tests=status['tests'],
        skipped=len(status['skipped']),original_control_steps=1280,
        artifacts={name:sha(raw) for name,raw in files.items()},
        limits='Whole source regression and supplied-action exact control replay. No new long-world judgments; actual development and independent confirmation remain separate gates.')
    (out/'verification.json').write_bytes(encoded(proof))
    print(encoded(proof).decode())


if __name__=='__main__':archive()
