"""Prepare the original forty conditions only after all relative-world gates.

This script never starts a worker. The exact development implementation is
retained, including both unchanged controls; all120 executions are registered.
"""
import argparse
from pathlib import Path
import subprocess
from prepare_reserved_purpose_confirmation import archive_proof, encoded, prepare, read, sha

FROZEN='493a685ab2837c999d13d832dc25a51068845fb5'
PLAN='cdd4132bfc137ddf251988a6313e0eee03402a8264de6eabfa0fa10dacabc62a'
CONTROL_BANK='061b200cd4b798c9d8525ad44bc80a09a2c3eefc5adc5f236fb28625fc451fef'


def qualify_same_source(source, runtime, development):
    proof=archive_proof(runtime)
    status=read(runtime/'regression_status.json')
    sources=read(runtime/'sources.json')
    replay=read(runtime/'control_replay.json')
    original=read(development/'verification.json')
    registration=read(development/'registration.json')
    plan=read(development/'plan.json')
    if (original['source_ref']!=FROZEN or registration['plan_sha256']!=PLAN
            or original['registration']['plan_sha256']!=PLAN
            or len(sources)!=612 or sources!=registration['sources']
            or original['registration']['source_sha256']!=sha(encoded(sources))):
        raise ValueError('complete exact registered relative development source required')
    if (not status.get('complete') or not status.get('passed')
            or status['source_commit']!=FROZEN or status['source_sha256']!=sha(encoded(sources))
            or status['failures'] or status['errors'] or status['unexpected_successes']
            or sha((runtime/'tests.log').read_bytes())!=status['log_sha256']):
        raise ValueError('completed passing whole-source regression required')
    if (replay.get('complete') is not True or replay['source']!=FROZEN
            or replay['source_registration']!=original['registration']
            or replay['controls']!=10 or replay['actual_steps']!=1280
            or replay['new_planning_decisions']!=0
            or {row['id'] for row in replay['rows']}!={spec['id'] for spec in plan['specs']}
            or any(row['steps']!=128 or not all(row[k] for k in
                ('predictions','learning','persona','policy','restoration','world_rng'))
                for row in replay['rows'])):
        raise ValueError('all original control learning/personality histories must replay exactly')
    if (plan['frozen_controls']['archive_sha256']!=CONTROL_BANK
            or replay['original_registration']!=plan['frozen_controls']['registration']
            or original.get('fresh_executions')!=10 or original.get('reused_executions')!=10):
        raise ValueError('preserve original reused control provenance and counts')
    if (proof.get('adoption') is not False or proof.get('world_quality_evidence') is not False
            or proof['source_ref']!=FROZEN
            or proof['source_sha256']!=sha(encoded(sources))):
        raise ValueError('source validation must not be relabeled as world quality or adoption')
    if any(sha((source/name).read_bytes())!=checksum for name,checksum in sources.items()):
        raise ValueError('the scientific implementation changed after qualification')
    commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
    if commit!=FROZEN:raise ValueError('retain the exact development commit for confirmation')
    return commit,sources


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('source','development','losses','review','runtime','output'):
        parser.add_argument('--'+name,required=True)
    prepare(**vars(parser.parse_args()), candidate='transfer_relative_gain',
            runtime_qualifier=qualify_same_source)
