"""Verify all retained controls' real learning under the candidate integration.

Actions are supplied from complete original histories; H32 is not recalculated.
This audits source compatibility, not new quality or independent evidence.
"""
from pathlib import Path
import ctypes,hashlib,json,os,sys,time
local=Path(__file__).resolve().parent;base=local.parents[2]
root=base/'reflex-persona-relative-worlds';sys.path.insert(0,str(root))
os.environ.update(NPY_DISABLE_CPU_FEATURES='AVX512F,AVX512CD,AVX512_SKX,AVX512_CLX,AVX512_CNL,AVX512_ICL',
    OPENBLAS_CORETYPE='Haswell',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
if os.name=='nt':
    kernel=ctypes.WinDLL('kernel32',use_last_error=True);kernel.GetCurrentProcess.restype=ctypes.c_void_p
    kernel.SetPriorityClass.argtypes=(ctypes.c_void_p,ctypes.c_uint)
    assert kernel.SetPriorityClass(kernel.GetCurrentProcess(),0x4000)
import numpy as np
from reflex.core import digest,character_key
from reflex.decision_loop import DecisionLoop
from reflex.model_observer import resolve_feedback
from tools.run_adverse_recovery import actor_for,game_for,verify_registration
from tools.run_owned_value import law,sample
from tools.frozen_controls import load_controls
from tools.owned_checkpoint import encoded
path=root/'evidence/relative_gain/worlds/plan.json'
plan=json.loads(path.read_bytes());bound=verify_registration(path);bank=load_controls(plan)
rows=[];started=time.monotonic()
for spec in plan['specs']:
    old=json.loads(bank['files'][(spec['id'],'result.json')])
    packet=json.loads(bank['files'][(spec['id'],'checkpoint.json')])['payload']
    game=game_for(spec);world=game.start();actor=actor_for(game,game.context(world),'stable')
    keys=('scope','seed','personality','values');axes={k:actor.record()[k] for k in keys}
    assert axes=={k:packet['owner'][k] for k in keys}
    policy_keys=('policy_residual','principle_priority','policy_commitments')
    assert {k:actor.record().get(k) for k in policy_keys}=={k:packet['owner'].get(k) for k in policy_keys}
    rng=np.random.default_rng(spec['seed'])
    for step in old['trace']:
        assert world==step['before'] and digest(actor.record())==step['before_owner']
        context=game.context(world,actor.state)
        assert actor.predictor.predict(context)==step['response_prediction']
        result=DecisionLoop.decide_batch([(actor,game.request(context))],False,_counterfactual_roots=(step['action'],))[0]
        truth=law(world['tick'],spec['turns'],spec['regime']);assert truth==step['truth']
        response=sample(truth,rng.random());assert response==step['response']
        after,flow=game.transition(world,step['action'],response)
        resolve_feedback(actor,result['ticket'],game.feedback(world,after,step['action'],context,flow))
        assert after==step['after'] and digest(actor.record())==step['owner']
        saved=json.loads(encoded(actor.record()));actor=DecisionLoop.from_record(context,saved,predictor=actor.predictor)
        assert actor.record()==saved and {k:saved[k] for k in keys}==axes
        world=after
    assert world==packet['world'] and actor.record()==packet['owner'] and rng.bit_generator.state==packet['rng']
    rows.append(dict(id=spec['id'],steps=len(old['trace']),predictions=True,learning=True,persona=True,policy=True,restoration=True,world_rng=True))
verify_registration(path)
receipt=dict(complete=True,source_registration=bound,original_registration=bank['registration'],
    source='493a685ab2837c999d13d832dc25a51068845fb5',controls=len(rows),actual_steps=sum(r['steps'] for r in rows),
    rows=rows,new_planning_decisions=0,adoption=False,seconds=time.monotonic()-started,
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    scope='Full1280 original actual transitions, predictions, exact owner learning/personality/policy and JSON restoration. Supplied historical actions; no new H32 judgments or independent samples.')
target=local/'relative_control_replay.json';assert not target.exists()
target.write_bytes(encoded(receipt));print(json.dumps({k:v for k,v in receipt.items() if k!='rows'}))
