"""Synthetic guard tests only; never register or run scientific conditions."""
import copy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import prepare_reserved_purpose_confirmation as bridge
from prepare_reserved_purpose_confirmation import encoded, sha


class Guards(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.candidate='transfer_relative_gain'
        self.plan=dict(candidate_arm=self.candidate,reference_arm='stable',
            specs=[dict(id=str(i)) for i in range(10)],concordant_adverse=['0'])
        self.summary=dict(complete=True,pairs_complete=10,development_gate_passed=True,
            pairs=[dict(id=str(i),score_delta=1.,conditional_delta=1.) for i in range(10)],
            families={g:dict(score=1.,conditional=1.) for g in ('auction','combat','gambling','resources')})
        self.proof=dict(complete=True,pairs=10,executions=20,actual_steps=2560,
            development_gate_passed=True)

    def save(self):
        for name,value in [('plan.json',self.plan),('summary.json',self.summary)]:
            (self.root/name).write_bytes(encoded(value))
        self.proof['artifacts']={name:sha((self.root/name).read_bytes()) for name in ('plan.json','summary.json')}
        (self.root/'verification.json').write_bytes(encoded(self.proof))

    def test_original_and_relative_candidates_use_same_gate(self):
        for candidate in ('transfer_purpose','transfer_purpose_gain','transfer_relative_gain'):
            self.plan['candidate_arm']=candidate;self.save()
            self.assertEqual(bridge.development_gate(self.root,candidate)[1],self.plan)
        with self.assertRaises(ValueError):bridge.development_gate(self.root,'arbitrary')

    def test_partial_and_failed_cohorts_do_not_pass(self):
        for field,value in [('complete',False),('pairs',9),('executions',19),('actual_steps',2559),('development_gate_passed',False)]:
            original=self.proof.copy();self.proof[field]=value;self.save()
            with self.subTest(field=field),self.assertRaises(ValueError):bridge.development_gate(self.root,self.candidate)
            self.proof=original
        self.summary['pairs'].pop();self.save()
        with self.assertRaises(ValueError):bridge.development_gate(self.root,self.candidate)

    def test_family_and_concordant_criteria_are_not_relaxed(self):
        original=copy.deepcopy(self.summary)
        self.summary['families']['combat']['conditional']=-.00001;self.save()
        with self.assertRaises(ValueError):bridge.development_gate(self.root,self.candidate)
        self.summary=original;self.summary['pairs'][0]['conditional_delta']=0;self.save()
        with self.assertRaises(ValueError):bridge.development_gate(self.root,self.candidate)

    def test_checksum_is_required(self):
        self.save();(self.root/'summary.json').write_bytes(b'{}')
        with self.assertRaises(ValueError):bridge.development_gate(self.root,self.candidate)

    def test_scientific_failure_never_calls_runtime_or_writes_registration(self):
        self.proof['complete']=False;self.save()
        with patch.object(bridge,'qualify_exact_runtime') as qualifier:
            with self.assertRaises(ValueError):
                bridge.prepare(self.root,self.root,self.root,self.root/'missing-review.json',
                    self.root,self.root/'confirmation',candidate=self.candidate,runtime_qualifier=qualifier)
            qualifier.assert_not_called()
        self.assertFalse((self.root/'confirmation').exists())

    def test_interleaving_retains_every_exact_job(self):
        jobs=[dict(spec=dict(id=f'{g}-{n}',game=g),arm=a,seed=701)
            for g in ('auction','combat','gambling','resources') for n in range(2)
            for a in ('original16','stable',self.candidate)]
        changed=bridge.interleave_job_families(jobs)
        self.assertEqual(sorted(map(encoded,jobs)),sorted(map(encoded,changed)))
        self.assertEqual([changed[i]['spec']['game'] for i in (0,3,6,9)],
            ['auction','combat','gambling','resources'])


if __name__=='__main__':unittest.main(verbosity=2)
