from pathlib import Path
import sys
sys.path.insert(0,"C:/Users/iwakura/Documents/Project(Gemini)/Colabo/github-preview/reflex-persona-consistent-reading/results/local_linux_recovery_20261029/cython_compiler")
from setuptools import setup,Extension
from Cython.Build import cythonize
modules=['cloning']
extensions=[Extension('reflex.'+n,['reflex/'+n+'.py'],extra_compile_args=['/fp:strict']) for n in modules]
setup(name='reflex-local-runtime-probe',version='0',packages=['reflex'],
 ext_modules=cythonize(extensions,compiler_directives=dict(language_level=3,binding=True,
 annotation_typing=False,infer_types=False,overflowcheck=True,boundscheck=True,
 wraparound=True,initializedcheck=True,nonecheck=True,cdivision=False,
 embedsignature=True),nthreads=0))

