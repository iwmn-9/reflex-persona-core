from pathlib import Path
import hashlib,json,shutil,zipfile
s=Path("C:/Users/iwakura/Documents/Project(Gemini)/Colabo/_native_probe_20261031");v=Path(__file__).parent;b=v.parents[2]
backup=s/'initial_compiled';backup.mkdir(exist_ok=False)
for n in ('source.json','build_probe.py','build.log','initial_tests.log'):
 shutil.copy2(s/n,backup/n)
for p in (s/'reflex').glob('*.pyd'):
 shutil.move(str(p),str(backup/p.name))
shutil.copy2(s/'reflex/cloning.py',backup/'cloning.py')
with zipfile.ZipFile(b/'reflex-persona-core/evidence/long_horizon/rejected_runtime_shortcuts/protocol_clone.zip') as z:
 for n in ('reflex/cloning.py','tests/test_protocol_cloning.py'):(s/n).write_bytes(z.read(n))
build=(s/'build_probe.py').read_text().replace("modules=['core','decision_loop','cloning','segmented_prediction','judgment']","modules=['cloning']")
(s/'build_clone.py').write_text(build)
original=json.loads((s/'source.json').read_bytes())
expected=original['sources'].copy()
for n in ('reflex/cloning.py','tests/test_protocol_cloning.py'):expected[n]=hashlib.sha256((s/n).read_bytes()).hexdigest()
(s/'clone_source.json').write_text(json.dumps(dict(original_source=original['source'],changes=['reflex/cloning.py'],added=['tests/test_protocol_cloning.py'],sources=expected),indent=2))
wrapper=(v/'check_native_runtime.py').read_text()
wrapper=wrapper.replace("('core','decision_loop','cloning','segmented_prediction','judgment')","('cloning',)")
wrapper=wrapper.replace("'source.json'","'clone_source.json'").replace("'build_probe.py'","'build_clone.py'").replace("'build.log'","'build_clone.log'")
(v/'check_native_clone_runtime.py').write_text(wrapper)

