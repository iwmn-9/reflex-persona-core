import argparse,hashlib,importlib,json,sys
from pathlib import Path
from check_gain_path_reuse import run
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--output',required=True);p.add_argument('--reference',required=True)
a=p.parse_args();source=Path(a.source).resolve();out=Path(a.output)
if out.exists():raise FileExistsError(out)
raw=out.with_suffix('.raw.json')
run(str(source),str(raw),a.reference)
proof=json.loads(raw.read_bytes());loaded={}
for name in ('core','decision_loop','cloning','segmented_prediction','judgment'):
 module=importlib.import_module('reflex.'+name);file=Path(module.__file__).resolve()
 assert file.parent==source/'reflex' and file.suffix=='.pyd'
 loaded[name]=dict(file=str(file),sha256=sha(file))
registration=json.loads((source/'source.json').read_bytes())
assert all(sha(source/n)==h for n,h in registration['sources'].items())
proof.update(compiled=True,loaded=loaded,source_manifest_sha256=sha(source/'source.json'),
 build_script_sha256=sha(source/'build_probe.py'),build_log_sha256=sha(source/'build.log'),
 script_sha256=sha(__file__),runtime=sys.version,
 note='Unmodified Python sources compiled in an isolated probe; no live scientific worker replacement.')
out.write_text(json.dumps(proof,sort_keys=True,separators=(',',':')))
print(json.dumps(dict(compiled=True,cpu=proof['new_cpu'],reference_cpu=proof['old_cpu'],differences=proof['differences'])),flush=True)

