"""Copy owned graphs without scalar dispatch in builtin containers.

Keep Python's copy/reduction protocols, aliases and cycles. The standard
reconstructor receives this recursive copier, so an owner's state dictionary
can use the same scalar fast path as an ordinary context. Custom hooks still
run on the original object and share the original memo. Explicit public memo
arguments keep the standard-library entry point.
"""
import copy as _standard
from copyreg import dispatch_table

copy = _standard.copy
_ATOMIC = frozenset((type(None),bool,int,float,complex,str,bytes,range,
                    type(Ellipsis),type(NotImplemented)))
_MISSING = object()


def _clone(value,memo):
    identity=id(value)
    previous=memo.get(identity,_MISSING)
    if previous is not _MISSING:return previous
    kind=type(value)
    if kind in _ATOMIC:return value
    if kind is dict:
        result={};memo[identity]=result
        for key,item in value.items():
            # Value before key, matching Python assignment and deepcopy.
            # A custom hook may override an atomic object in the shared memo.
            result[memo.get(id(key),key) if type(key) in _ATOMIC else _clone(key,memo)]=(memo.get(id(item),item) if type(item) in _ATOMIC else _clone(item,memo))
    elif kind is list:
        result=[];memo[identity]=result
        result.extend(memo.get(id(item),item) if type(item) in _ATOMIC else _clone(item,memo) for item in value)
    elif kind is tuple:
        items=[memo.get(id(item),item) if type(item) in _ATOMIC else _clone(item,memo) for item in value]
        if identity in memo:return memo[identity]
        result=value if all(a is b for a,b in zip(items,value)) else tuple(items)
    else:
        handler=_standard._deepcopy_dispatch.get(kind)
        if handler is not None:
            result=handler(value,memo)
        elif issubclass(kind,type):
            result=value
        else:
            hook=getattr(value,'__deepcopy__',None)
            if hook is not None:
                result=hook(memo)
            else:
                reducer=dispatch_table.get(kind)
                if reducer:
                    reduction=reducer(value)
                else:
                    reducer=getattr(value,'__reduce_ex__',None)
                    if reducer is not None:
                        reduction=reducer(4)
                    else:
                        reducer=getattr(value,'__reduce__',None)
                        if not reducer:raise _standard.Error('un(deep)copyable object of type %s' % kind)
                        reduction=reducer()
                result=value if isinstance(reduction,str) else _standard._reconstruct(value,memo,*reduction,deepcopy=_clone)
    if result is not value:
        memo[identity]=result
        _standard._keep_alive(value,memo)
    return result


def deepcopy(value,memo=None):
    if memo is not None:return _standard.deepcopy(value,memo)
    return _clone(value,{})
