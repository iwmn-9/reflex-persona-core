from pathlib import Path
import hashlib,json,shutil,subprocess
v=Path(__file__).parent;b=v.parents[2];k=b/'reflex-persona-retry-runtime'
out=Path('C:/Users/iwakura/Documents/Project(Gemini)/Colabo/_native_probe_20261031')
out.mkdir(exist_ok=False)
names=subprocess.check_output(['git','ls-files','reflex','tools','tests'],cwd=k,text=True).splitlines()
sources={}
for n in names:
 p=k/n
 if p.is_file():
  q=out/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
  sources[n]=hashlib.sha256(q.read_bytes()).hexdigest()
(out/'source.json').write_text(json.dumps(dict(source='9309ad944d32dcd3c7c3965e698d2d6416fa7657',sources=sources),indent=2))
print(json.dumps(dict(staging=str(out),files=len(sources))))

