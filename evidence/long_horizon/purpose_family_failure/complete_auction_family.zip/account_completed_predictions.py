"""Score complete pair histories, without replacing whole-cohort review."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

def read(path):
    return json.loads(path.read_bytes())

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def account(source, pair):
    receipt = read(pair/'verification.json')
    assert receipt['pair_complete'] and not receipt['cohort_gate_evaluated']
    assert all(sha(Path(path).read_bytes()) == value for path,value in receipt['source_files'].items())
    sys.path.insert(0,str(source))
    from tools.review_adverse_predictions import score_prediction,mean_scores
    arms = {}
    observations = None
    for name in receipt['source_files']:
        if Path(name).name != 'result.json':
            continue
        result = read(Path(name))
        trace = result['trace']
        assert result['complete'] and len(trace) == receipt['spec']['turns'] == 128
        assert [row['tick'] for row in trace] == list(range(128))
        events = [(row['truth'],row['response']) for row in trace]
        if observations is None:
            observations = events
        assert observations == events
        rows = [score_prediction(row['response_prediction'],row['truth'],row['response']) for row in trace]
        arms[result['configuration']['arm']] = dict(means=mean_scores(rows),
            phases=[dict(start=start,end=start+32,means=mean_scores(rows[start:start+32])) for start in range(0,128,32)])
    # Earlier receipts in this same study predate explicit arm fields.
    reference,candidate = receipt.get('reference_arm','stable'),receipt.get('candidate_arm','transfer_purpose')
    assert set(arms) == {reference,candidate}
    left,right = arms[reference]['means'],arms[candidate]['means']
    result = dict(case=receipt['case'],pair_complete=True,cohort_complete=False,cohort_gate_evaluated=False,
        adoption=False,source_receipt_sha256=sha((pair/'verification.json').read_bytes()),
        reviewer_sha256=sha((source/'tools/review_adverse_predictions.py').read_bytes()),
        script_sha256=sha(Path(__file__).read_bytes()),arms=arms,
        loss_delta={key:right[key]-left[key] for key in left},
        limits=['All128 pre-reveal predictions scored; zero new game decisions or selected probe roots.',
                'True laws are retrospective scoring targets only. Smaller prediction loss does not prove better long-term decisions.',
                'These paired streams are not independent repeated trials and cannot pass a cohort or alter its criteria.'])
    with (pair/'prediction_accounting.json').open('x',encoding='utf8') as stream:
        json.dump(result,stream,sort_keys=True,indent=2)
    return dict(case=result['case'],loss_delta=result['loss_delta'])

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--source',required=True)
    parser.add_argument('--pairs',nargs='+',required=True)
    args=parser.parse_args()
    print(json.dumps([account(Path(args.source).resolve(),Path(pair).resolve()) for pair in args.pairs],indent=2))
