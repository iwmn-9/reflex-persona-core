"""Apply an unchanged family gate only to its entire audited registered set.

No incomplete family can pass. A fully known failing family blocks adoption,
but does not cancel other cases or permit early loss-probe/root selection.
"""
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import statistics


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


if __name__ == '__main__':
    root = Path(__file__).resolve().parent
    base = root.parents[2]
    plan_path = base/'reflex-persona-purpose-tail/evidence/long_horizon/adverse_purpose_tail/plan.json'
    assert sha(plan_path) == 'd6af04445fc54f18cf16b60648fe075b10e4e8cd06c9124b797beb91e5783c7f'
    plan = read(plan_path)
    criterion = 'Every family mean score and conditional increment delta >= -1e-12 versus stable H32. All individual losses retained and diagnosed.'
    assert plan['criteria']['family_gate'] == criterion
    groups = defaultdict(list)
    for spec in plan['specs']:
        groups[spec['game']].append(spec)
    families = {}
    files = {}
    for family, specs in groups.items():
        rows = []
        for spec in specs:
            folder = root/'purpose_completed_pairs'/spec['id']
            if not (folder/'verification.json').exists():
                continue
            receipt = read(folder/'verification.json')
            assert receipt['pair_complete'] and not receipt['cohort_gate_evaluated']
            assert receipt['spec'] == spec
            assert receipt['source_ref'] == '243c42aef2c9da21ccf4e21e4093aa73f8c0f4d7'
            assert receipt['registration']['plan_sha256'] == sha(plan_path)
            assert all(sha(Path(path)) == value for path, value in receipt['source_files'].items())
            analysis = read(folder/'analysis.json')
            assert sha(folder/'analysis.json') == receipt['analysis_sha256']
            for name in ('verification.json', 'analysis.json', 'prediction_accounting.json',
                         'selection_accounting.json', 'forecast_execution_accounting.json'):
                files[str(folder/name)] = sha(folder/name)
            prediction = read(folder/'prediction_accounting.json')
            rows.append(dict(case=spec['id'], differences=analysis['differences'],
                             prediction_loss_delta=prediction['loss_delta']))
        complete = len(rows) == len(specs)
        means = {key:statistics.fmean(row['differences'][key] for row in rows)
                 for key in ('score','conditional','reference_choice')} if complete else None
        families[family] = dict(registered_pairs=len(specs), audited_pairs=len(rows),
            complete=complete, means=means, failure_proven=complete and any(
                means[key] < -1e-12 for key in ('score','conditional')), rows=rows)
    result = dict(created=datetime.now(timezone.utc).isoformat(),
        plan_sha256=sha(plan_path), family_criterion=criterion, families=families, files=files,
        adoption_blocked=any(value['failure_proven'] for value in families.values()),
        cohort_complete=False, loss_roots_selected=False, adoption=False,
        limits=['Every registered member of a family is required; no partial-family average is used.',
                'The four auction persona conditions share only two world observation streams; not four independent stochastic replications.',
                'Lower prediction loss does not establish causal improvement of the selected plan or long-term result.',
                'Remaining original cases and complete-cohort loss/personality diagnostics continue unchanged.'])
    path = root/'purpose_completed_family_account.json'
    with path.open('x',encoding='utf8') as stream:
        json.dump(result, stream, indent=2, ensure_ascii=False)
    print(json.dumps({name:{key:value[key] for key in ('registered_pairs','audited_pairs','failure_proven','means')}
                      for name,value in families.items()}))
