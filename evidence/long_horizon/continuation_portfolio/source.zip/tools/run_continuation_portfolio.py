"""Long-play mechanism screen; never substitutes for the registered 40/8/8."""
import argparse
import copy
import json
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from reflex.core import character_key, digest
from reflex.decision_loop import DecisionLoop
from reflex.laboratory import PROFILES
from reflex.model_observer import resolve_feedback
from tools.continuation_portfolio import portfolio_planner
from tools.owned_checkpoint import OwnedCheckpoint, encoded, sha
from tools.preparation_world import DelayedYield, PreparationChain
from tools.run_owned_value import cumulative_basis


def game_for(spec):
    cls = DelayedYield if spec['mechanism'] == 'delayed' else PreparationChain
    return cls(spec['length'], payout=spec['payout'], turns=spec['turns'], profile=PROFILES[spec['profile']])


def execution(root, spec, retry, *, max_decisions=None):
    root = Path(root); root.mkdir(parents=True, exist_ok=True)
    hashes = {n: sha(Path(__file__).with_name(n).read_bytes()) for n in (
        'run_continuation_portfolio.py', 'continuation_portfolio.py', 'preparation_world.py')}
    config = dict(spec=spec, retry=retry, sources=hashes, horizon=16, seeds=[701])
    g = game_for(spec); w = g.start(); c = g.context(w)
    actor = g.actor(c, learning='segmented'); axes = character_key(c)
    store = OwnedCheckpoint(root/'checkpoint.json', ('continuation-portfolio', spec['id']),
        'portfolio' if retry else 'reflex-tail', configuration=config, every=1, max_decisions=max_decisions)
    trace=[]; checks=dict(owner_parity=0, fixed_axes=0, restored=0); rng=np.random.default_rng(0)
    start=time.monotonic()
    if store.saved is not None:
        saved=store.saved; w=saved['world']; trace=saved['trace']; checks=saved['checks']
        actor=DecisionLoop.from_record(g.context(trace[-1]['before']), saved['owner'], predictor=actor.predictor)
        rng.bit_generator.state=saved['rng']; start-=saved['elapsed']
    while not g.terminal(w):
        c=g.context(w, actor.state); req=g.request(c); cap={}; prior=actor.record()
        detached=copy.deepcopy(actor)
        planner=portfolio_planner(actor, req, w, observe=g.context, events=g.events, terminal=g.terminal,
            assess=lambda w:g.goal(w).record(), request_for=g.request, feedback=g.feedback,
            model_id=g.model_id, target=g.target, horizon=16, seeds=(701,),
            cumulative_preference=cumulative_basis(g, True), include_retry=retry, captured=cap)
        result=DecisionLoop.decide_batch([(actor, req)], False, planner)[0]
        key=result['decision']['action_id']; after,flow=g.transition(w,key,'0')
        # The schedule is owned by the real world only. The controller receives
        # the changed payout after this event, never its time or future value.
        for tick,payout in spec['changes']:
            if after['tick']==tick:after['payout']=payout
        feedback=g.feedback(w,after,key,c,flow)
        resolve_feedback(actor,result['ticket'],feedback)
        replay=DecisionLoop.decide_batch([(detached,req)],False,_counterfactual_roots=(key,))[0]
        resolve_feedback(detached,replay['ticket'],feedback)
        assert actor.record()==detached.record()
        assert character_key(result['context'])==axes
        checks['owner_parity']+=1;checks['fixed_axes']+=1
        if w['tick']%23==0:
            record=json.loads(encoded(actor.record()))
            actor=DecisionLoop.from_record(c,record,predictor=actor.predictor)
            assert actor.record()==record;checks['restored']+=1
        diagnostic=result['deliberation']; f=cap['forecast']
        selected=diagnostic['selected_plan']; proposal=f.audit['plans'][selected]['proposal']
        trace.append(dict(tick=w['tick'],before=w,after=after,action=key,
            before_owner=digest(prior),owner=digest(actor.record()),
            selected_policy=proposal,selected_purpose=diagnostic['selected_purpose'],
            predicted_actions=cap['modeled'][proposal][0]['actions'],
            simulated_steps=cap['simulated_steps']))
        w=after
        store.save(w,actor,rng,trace,checks,time.monotonic()-start,terminal=g.terminal(w))
        if len(trace)%32==0:print(json.dumps(dict(id=spec['id'],retry=retry,turn=len(trace),cash=w['cash'])),flush=True)
        if store.stopping(len(trace)) and not g.terminal(w):return None
    replay=g.start()
    for entry in trace:
        assert entry['before']==replay
        replay,_=g.transition(replay,entry['action'],'0')
        for tick,payout in spec['changes']:
            if replay['tick']==tick:replay['payout']=payout
        assert entry['after']==replay
    assert replay==w and len(trace)==spec['turns']
    row=dict(configuration=config,complete=True,final=w,score=g.goal(w).value,
        trace=trace,checks=checks,seconds=time.monotonic()-start,physical_replay=len(trace))
    (root/'result.json').write_bytes(encoded(row))
    return row


def pair(root,spec):
    rows=[]
    for retry in (False,True):
        directory=Path(root)/spec['id']/('candidate' if retry else 'baseline')
        dest=directory/'result.json'
        row=json.loads(dest.read_bytes()) if dest.exists() else execution(directory,spec,retry)
        envelope=json.loads((directory/'checkpoint.json').read_bytes());saved=envelope['payload']
        assert sha(encoded(saved))==envelope['sha256']
        assert saved['trace']==row['trace'] and saved['world']==row['final']
        assert saved['contract']['configuration']==row['configuration']
        assert row['configuration']['spec']==spec and row['complete']
        assert row['physical_replay']==len(row['trace'])==spec['turns']
        rows.append(row)
    result=dict(id=spec['id'],spec=spec,cash=[r['final']['cash'] for r in rows],
        delta=rows[1]['final']['cash']-rows[0]['final']['cash'],
        seconds=[r['seconds'] for r in rows],
        actions=[{k:sum(t['action']==k for t in r['trace']) for k in ('x','y')} for r in rows])
    print(json.dumps(dict(completed_pair=result)),flush=True)
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',required=True)
    parser.add_argument('--frozen',action='store_true');parser.add_argument('--workers',type=int,default=2)
    args=parser.parse_args();root=Path(args.root).resolve()
    if not args.frozen:
        from tools.freeze_experiment import dispatch
        return dispatch(root,Path(__file__).name,['--workers',str(args.workers)])
    specs=[]
    for mechanism,length,good in (('delayed',11,6.),('chain',5,14.)):
        for profile in (0,2):
            for kind,payout,changes in (('stable',good,[]),('loss',good,[[73,2.]]),('opportunity',2.,[[29,good]])):
                specs.append(dict(id=f'{mechanism}-{profile}-{kind}',mechanism=mechanism,length=length,
                    payout=payout,changes=changes,profile=profile,turns=128))
    plan=dict(version=1,specs=specs,source=sha(encoded(json.loads((root/'source_snapshot.json').read_bytes()))),
        purpose='mechanism screen only; no adoption and no replacement of registered 40/8/8',
        criteria='all cases complete; fixed personality and actual feedback parity; report every loss; preparation gain and abandonment of unprofitable work; new opportunity inside a former fixed window')
    plan_path=root/'plan.json'
    if plan_path.exists():assert json.loads(plan_path.read_bytes())==plan
    else:plan_path.write_bytes(encoded(plan))
    rows=[]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(pair,root,s) for s in specs]
        for future in as_completed(futures):
            rows.append(future.result())
            (root/'summary.json').write_bytes(encoded(dict(complete=len(rows)==len(specs),
                completed_pairs=len(rows),registered_pairs=len(specs),rows=sorted(rows,key=lambda r:r['id']))))


if __name__=='__main__':main()
