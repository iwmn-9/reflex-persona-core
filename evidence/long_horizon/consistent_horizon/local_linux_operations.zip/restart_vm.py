from pathlib import Path
import json,subprocess,ctypes,sys
r=Path(__file__).resolve().parent
state=json.loads((r/'vm.json').read_bytes())
handle=ctypes.windll.kernel32.OpenProcess(0x1000,False,state['vm_pid'])
if handle:
    code=ctypes.c_ulong()
    ctypes.windll.kernel32.GetExitCodeProcess(handle,ctypes.byref(code))
    ctypes.windll.kernel32.CloseHandle(handle)
    assert code.value!=259,'prior VM still active'
label=sys.argv[1]
assert label in ('host','xsaves','xsaves4')
(r/f'vm.before-{label}.json').write_bytes((r/'vm.json').read_bytes())
args=state['args'];args[args.index('-cpu')+1]='host' if label=='host' else 'Haswell-noTSX,xsaves=on,xsavec=on'
if label=='xsaves4':
    args[args.index('-smp')+1]='4'
    args[args.index('-m')+1]='1536'
args[args.index('-serial')+1]='file:'+str(r/f'console-{label}.log')
with (r/f'qemu-{label}.stdout.log').open('ab') as out,(r/f'qemu-{label}.stderr.log').open('ab') as err:
    p=subprocess.Popen(args,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
state['vm_pid']=p.pid
(r/'vm.json').write_text(json.dumps(state,indent=2))
print(p.pid)
