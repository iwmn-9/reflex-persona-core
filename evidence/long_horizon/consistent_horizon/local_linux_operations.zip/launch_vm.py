from pathlib import Path
import json,subprocess,shutil,sys,os,socket
r=Path(__file__).resolve().parent;q=r/'qemu'
assert not (r/'vm.json').exists(),'inspect existing VM before launch'
for port in (48361,48362,48363):
 with socket.socket() as s:s.bind(('127.0.0.1',port))
key=r/'ssh_key'
if not key.exists():subprocess.run(['C:/Windows/System32/OpenSSH/ssh-keygen.exe','-q','-t','ed25519','-N','','-f',str(key),'-C','reflex-local-recovery'],check=True)
http=r/'http';seed=http/'seed';seed.mkdir(parents=True,exist_ok=True)
pub=key.with_suffix('.pub').read_text().strip()
(seed/'meta-data').write_text('instance-id: reflex-local-20261029\nlocal-hostname: reflex-local\n',encoding='ascii')
(seed/'user-data').write_text('#cloud-config\nusers:\n  - name: ubuntu\n    groups: [sudo]\n    shell: /bin/bash\n    sudo: ["ALL=(ALL) NOPASSWD:ALL"]\n    lock_passwd: true\n    ssh_authorized_keys:\n      - '+pub+'\nssh_pwauth: false\ndisable_root: true\n',encoding='ascii')
(seed/'vendor-data').write_text('#cloud-config\n',encoding='ascii')
(seed/'network-config').write_text('version: 2\nethernets:\n  eth0:\n    match:\n      name: "en*"\n    dhcp4: true\n',encoding='ascii')
if not (http/'python-linux.tar.gz').exists():os.link(r/'python-linux.tar.gz',http/'python-linux.tar.gz')
disk=r/'worker.qcow2'
if not disk.exists():subprocess.run([str(q/'qemu-img.exe'),'create','-f','qcow2','-F','qcow2','-b',str(r/'ubuntu.img'),str(disk),'10G'],check=True)
vars=r/'uefi-vars.fd'
if not vars.exists():shutil.copyfile(q/'share/edk2-i386-vars.fd',vars)
flags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS
server=subprocess.Popen([sys.executable,'-u','-m','http.server','48361','--bind','127.0.0.1','--directory',str(http)],stdout=(r/'http.stdout.log').open('ab'),stderr=(r/'http.stderr.log').open('ab'),creationflags=flags)
args=[str(q/'qemu-system-x86_64.exe'),'-accel','whpx','-machine','q35','-cpu','Haswell-noTSX','-smp','2','-m','1024',
 '-drive',f'if=pflash,format=raw,readonly=on,file={q / "share/edk2-x86_64-code.fd"}',
 '-drive',f'if=pflash,format=raw,file={vars}',
 '-drive',f'if=virtio,format=qcow2,file={disk}',
 '-netdev','user,id=net0,hostfwd=tcp:127.0.0.1:48362-:22','-device','virtio-net-pci,netdev=net0',
 '-smbios','type=1,serial=ds=nocloud;s=http://10.0.2.2:48361/seed/',
 '-display','none','-serial',f'file:{r / "console.log"}','-monitor','none',
 '-qmp','tcp:127.0.0.1:48363,server=on,wait=off','-no-reboot']
vm=subprocess.Popen(args,cwd=q,stdout=(r/'qemu.stdout.log').open('ab'),stderr=(r/'qemu.stderr.log').open('ab'),creationflags=flags)
state=dict(vm_pid=vm.pid,http_pid=server.pid,ssh_port=48362,qmp_port=48363,http_port=48361,args=args,root=str(r),host_settings_changed=False)
(r/'vm.json').write_text(json.dumps(state,indent=2),encoding='utf8')
print(json.dumps({k:state[k] for k in ('vm_pid','http_pid','ssh_port')}))
