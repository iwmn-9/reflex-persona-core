"""Finite local-only continuation of all registered histories, no adoption."""
import contextlib,datetime,fcntl,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path('/home/ubuntu/recovery')
def read(p):return json.loads(Path(p).read_bytes())
def encoded(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,x):
 p=Path(p);temp=p.with_suffix('.new');temp.write_bytes(encoded(x));temp.replace(p)
@contextlib.contextmanager
def lock(path):
 with Path(path).open('ab+') as f:
  fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
  try:yield
  finally:fcntl.flock(f,fcntl.LOCK_UN)
def progress(folder):
 p=Path(folder);s=read(p/'status.json') if (p/'status.json').exists() else {}
 cp=p/'checkpoint.json';n=0
 if cp.exists():
  e=read(cp);v=e['payload'];assert sha(encoded(v))==e['sha256']
  n=len(v['trace']);assert n==v['world']['tick']==v['owner']['last_tick']+1
 return dict(complete=s.get('complete',False),state=s.get('state','pending'),actual_steps=n,
             checkpoint_mtime=cp.stat().st_mtime if cp.exists() else None,pid=s.get('pid'),error=s.get('error'))
def worker(index):
 m=read(ROOT/'queue_manifest.json');job=m['jobs'][index];out=Path(job['output'])
 with lock(out/'worker.lock'):
  sys.path.insert(0,job['source'])
  from tools.run_adverse_recovery import verify_registration,run
  from tools.adverse_segment import audit
  reg=verify_registration(job['plan']);assert reg==job['registration']
  old=read(out/'checkpoint.json')['payload']['trace'] if (out/'checkpoint.json').exists() else []
  state=dict(state='running',complete=False,pid=os.getpid(),case=job['spec']['id'],arm=job['arm'],registration=reg,
             from_tick=len(old),retained_prefix_sha256=sha(encoded(old)),started=now())
  save(out/'status.json',state)
  try:
   run(out,job['spec'],job['arm'],registration=reg)
   facts=audit(out,job['spec'],job['arm'],reg)
   trace=read(out/'checkpoint.json')['payload']['trace'];assert trace[:len(old)]==old
   assert facts['complete'] and facts['actual_steps']==job['spec']['turns']
   state.update(facts,state='complete',updated=now());save(out/'status.json',state)
  except BaseException as e:
   state.update(complete=False,state='failed',error=repr(e),updated=now());save(out/'status.json',state);raise
def prepare():
 assert not (ROOT/'queue_manifest.json').exists()
 bundle=read(ROOT/'bundle_manifest.json');jobs=[]
 for study in bundle['studies']:
  base=ROOT/study['name'];proof=read(base/'prefix_audit.json')
  assert proof['complete'] and proof['artifacts']==len(list((base/'initial').glob('*/checkpoint.json')))
  shutil.copytree(base/'initial',base/'latest')
  source=base/'source';plan=source/study['plan'];p=read(plan)
  for spec in p['specs']:
   for arm in p['arms']:
    out=base/'latest'/f"adverse-{spec['id']}-{arm}";out.mkdir(exist_ok=True)
    jobs.append(dict(study=study['name'],source=str(source),plan=str(plan),spec=spec,arm=arm,
                     output=str(out),registration=proof['source_registration'],arithmetic=p['arithmetic']))
 save(ROOT/'queue_manifest.json',dict(version=1,jobs=jobs,driver_sha256=sha(Path(__file__).read_bytes()),
              local_only=True,adoption=False,original_histories_preserved=True,created=now()))
class ExistingWorker:
 def __init__(self,folder,pid):self.folder,self.pid=Path(folder),pid
 def poll(self):
  try:
   with lock(self.folder/'worker.lock'):pass
  except BlockingIOError:return None
  return 0 if progress(self.folder)['complete'] else 1
def coordinate(workers):
 m=read(ROOT/'queue_manifest.json');assert sha(Path(__file__).read_bytes())==m['driver_sha256']
 with lock(ROOT/'queue.lock'):
  active={};done=set();failures={}
  for i,j in enumerate(m['jobs']):
   # A live worker from a lost coordinator must not be duplicated.
   try:
    with lock(Path(j['output'])/'worker.lock'):pass
   except BlockingIOError:
    status=read(Path(j['output'])/'status.json')
    assert status['registration']==j['registration'] and status['case']==j['spec']['id'] and status['arm']==j['arm']
    active[i]=(ExistingWorker(j['output'],status['pid']),[])
  while True:
   rows=[]
   for i,j in enumerate(m['jobs']):
    p=progress(j['output']);rows.append(dict(index=i,study=j['study'],case=j['spec']['id'],arm=j['arm'],**p))
    if p['complete']:
     assert p['actual_steps']==j['spec']['turns'];done.add(i)
   for i,(p,logs) in list(active.items()):
    code=p.poll()
    if code is None:continue
    for f in logs:f.close()
    del active[i]
    if code or not progress(m['jobs'][i]['output'])['complete']:failures[i]=dict(returncode=code,progress=progress(m['jobs'][i]['output']))
    else:done.add(i)
   if not failures:
    for i,j in enumerate(m['jobs']):
     if len(active)>=workers:break
     if i in done or i in active:continue
     out=Path(j['output']);logs=[(out/n).open('ab') for n in ('execution.stdout.log','execution.stderr.log')]
     env=os.environ.copy();env.update(j['arithmetic']);env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
     p=subprocess.Popen([sys.executable,'-u',str(Path(__file__)),'worker',str(i)],cwd=j['source'],env=env,
                        stdout=logs[0],stderr=logs[1]);active[i]=(p,logs)
   save(ROOT/'queue_state.json',dict(updated=now(),pid=os.getpid(),active={i:p.pid for i,(p,_) in active.items()},
       executions_complete=len(done),executions_registered=len(m['jobs']),complete=len(done)==len(m['jobs']),
       failures=failures,progress=rows,adoption=False,manifest_sha256=sha((ROOT/'queue_manifest.json').read_bytes())))
   if not active and (failures or len(done)==len(m['jobs'])):
    if failures:raise RuntimeError('worker failure; preserve histories and inspect')
    return
   time.sleep(15)
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='worker':worker(int(sys.argv[2]))
 elif sys.argv[1]=='coordinate':coordinate(int(sys.argv[2]))
 else:raise ValueError('explicit finite mode required')
