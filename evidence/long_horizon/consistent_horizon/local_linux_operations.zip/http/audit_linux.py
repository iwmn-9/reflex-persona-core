import json, os, sys, time
from pathlib import Path
root=Path('/home/ubuntu/recovery')
name=sys.argv[1]
source=root/name/'source'
sys.path.insert(0,str(source))
from tools.owned_checkpoint import OwnedCheckpoint,sha,encoded
from tools.run_adverse_recovery import verify_registration
from tools.adverse_segment import audit
manifest=json.loads((root/'bundle_manifest.json').read_bytes())
study=next(x for x in manifest['studies'] if x['name']==name)
registration=verify_registration(source/study['plan'])
for file,expected in study['initial'].items():
    assert sha((root/name/'initial'/file).read_bytes())==expected,file
rows=[]
for directory in sorted((root/name/'initial').iterdir()):
    checkpoint=directory/'checkpoint.json'
    saved=json.loads(checkpoint.read_bytes())['payload']
    contract=saved['contract']
    store=OwnedCheckpoint(checkpoint,contract['job'],contract['arm'],configuration=contract['configuration'])
    assert store.saved==saved
    start=time.monotonic()
    facts=audit(directory,contract['configuration']['spec'],contract['arm'],registration)
    rows.append(dict(directory=directory.name,seconds=time.monotonic()-start,**facts))
    print(json.dumps(rows[-1]),flush=True)
result=dict(complete=True,studies=[name],artifacts=len(rows),rows=rows,source_registration=registration,
            arithmetic={k:os.environ.get(k) for k in ('OPENBLAS_CORETYPE','NPY_DISABLE_CPU_FEATURES','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')},
            original_history_modified=False)
(root/name/'prefix_audit.json').write_bytes(encoded(result))
