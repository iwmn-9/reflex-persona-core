from pathlib import Path
import hashlib, json, tarfile
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parents[2]
studies=[('sample8','reflex-persona-core','adverse_sample_budget','adverse_sample_budget_20261028'),
         ('transfer','reflex-persona-prediction-transfer','adverse_transfer','adverse_transfer_20261029')]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
manifest={'studies':[], 'host_settings_changed':False, 'remote_execution':False}
with tarfile.open(ROOT/'http/recovery.tar.gz','w:gz') as archive:
    for name,repo,evidence,output in studies:
        source=BASE/repo
        plan=Path('evidence/long_horizon')/evidence/'plan.json'
        registration=plan.with_name('registration.json')
        reg=json.loads((source/registration).read_bytes())
        assert sha(source/plan)==reg['plan_sha256']
        for file,expected in reg['sources'].items():
            assert sha(source/file)==expected, file
            archive.add(source/file,arcname=f'{name}/source/{file}',recursive=False)
        for file in (plan,registration):
            archive.add(source/file,arcname=f'{name}/source/{file}',recursive=False)
        files={}
        latest=source/'results'/output/'latest'
        for directory in sorted(latest.iterdir()):
            if not (directory/'checkpoint.json').exists(): continue
            for file in sorted(directory.glob('*.json')):
                rel=file.relative_to(latest).as_posix()
                files[rel]=sha(file)
                archive.add(file,arcname=f'{name}/initial/{rel}',recursive=False)
        manifest['studies'].append(dict(name=name,plan=plan.as_posix(),registration=reg,initial=files))
(ROOT/'bundle_manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2),encoding='utf8')
(ROOT/'http/bundle_manifest.json').write_bytes((ROOT/'bundle_manifest.json').read_bytes())
print(json.dumps({'sha256':sha(ROOT/'http/recovery.tar.gz'),'studies':[{ 'name':x['name'],'sources':len(x['registration']['sources']),'initial_files':len(x['initial'])} for x in manifest['studies']]}))
