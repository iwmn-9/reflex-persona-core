from pathlib import Path
import urllib.request,hashlib,json,subprocess
from concurrent.futures import ThreadPoolExecutor
r=Path(__file__).resolve().parent
items=[('qemu.exe','https://qemu.weilnetz.de/w64/qemu-w64-setup-20260811.exe','sha512','https://qemu.weilnetz.de/w64/qemu-w64-setup-20260811.sha512','qemu-w64-setup-20260811.exe'),('ubuntu.img','https://cloud-images.ubuntu.com/minimal/releases/noble/release/ubuntu-24.04-minimal-cloudimg-amd64.img','sha256','https://cloud-images.ubuntu.com/minimal/releases/noble/release/SHA256SUMS','ubuntu-24.04-minimal-cloudimg-amd64.img')]
release=json.loads(subprocess.check_output(['C:/Program Files/GitHub CLI/gh.exe','api','repos/actions/python-versions/releases/tags/3.12.14-31661455385']))
asset=next(x for x in release['assets'] if x['name']=='python-3.12.14-linux-24.04-x64.tar.gz')
(r/'python-asset.json').write_text(json.dumps(asset,indent=2),encoding='utf8')
items.append(('python-linux.tar.gz',asset['browser_download_url'],'sha256',None,None))
def one(item):
 name,url,algorithm,checksums,target=item;p=r/name
 expected=None
 if checksums:
  data=urllib.request.urlopen(checksums).read();(r/(name+'.checksums')).write_bytes(data)
  expected=next(line.split()[0] for line in data.decode().splitlines() if line.rstrip().endswith(target))
 elif asset.get('digest'):expected=asset['digest'].removeprefix('sha256:')
 if not p.exists():
  temporary=p.with_suffix(p.suffix+'.part')
  with urllib.request.urlopen(url) as incoming,temporary.open('wb') as out:
   while b:=incoming.read(1024*1024):out.write(b)
  temporary.replace(p)
 checksum=hashlib.new(algorithm,p.read_bytes()).hexdigest()
 if expected:assert checksum==expected,(name,checksum,expected)
 result=dict(file=name,url=url,size=p.stat().st_size,algorithm=algorithm,checksum=checksum,publisher_checksum_verified=expected is not None)
 print(json.dumps(result),flush=True);return result
with ThreadPoolExecutor(max_workers=3) as pool:records=list(pool.map(one,items))
(r/'downloads.json').write_text(json.dumps(records,indent=2),encoding='utf8')
