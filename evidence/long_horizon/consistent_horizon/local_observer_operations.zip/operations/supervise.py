"""One finite local collection/audit task. Never dispatch worlds or adopt."""
from pathlib import Path
import datetime,hashlib,json,os,sys,time,traceback
V=Path(__file__).resolve().parent
U=V.parents[1]
sys.path.insert(0,str(U))
from tools.local_adverse_queue import exclusive
from tools.local_checkpoint_io import read_json, atomic_json
from tools.archive_adverse_study import archive
from pulse import pulse
from sync import sync
def read(p):return read_json(p)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(value):
 atomic_json(V/'supervisor_state.json',value)
def main():
 R=U.parent/'reflex-persona-core';T=U.parent/'reflex-persona-prediction-transfer'
 jobs={
 'sample8':dict(plan=R/'evidence/long_horizon/adverse_sample_budget/plan.json',source='19462563a54cd36f43ff14679bf0e731de687cfe',out=R/'evidence/long_horizon/adverse_sample_budget/completed_local'),
 'transfer':dict(plan=T/'evidence/long_horizon/adverse_transfer/plan.json',source='36f5850ba2cd8355aa4083ef40bd5a4b9d24217d',out=T/'evidence/long_horizon/adverse_transfer/completed_local'),
 'consistent':dict(plan=U/'evidence/long_horizon/consistent_horizon/plan.json',source='a14d164db0a94820d78ed4605a780162467e5ccb',out=U/'evidence/long_horizon/consistent_horizon/completed_local')}
 with exclusive(V/'supervisor.lock'):
  done={};state=dict(pid=os.getpid(),adoption=False,collection_complete=False,driver_sha256=sha(__file__),
    operations_sha256={str(p.relative_to(U)):sha(p) for p in
      (U/'tools/local_adverse_queue.py',U/'tools/local_checkpoint_io.py',U/'tools/archive_adverse_study.py',
       V/'pulse.py',V/'sync.py',V/'vmctl.py')})
  for name,job in jobs.items():
   verification=job['out']/'verification.json'
   if not job['out'].exists():continue
   if not verification.exists():raise RuntimeError('Incomplete archive exists; inspect before retry: '+str(job['out']))
   proof=read(verification)
   assert proof['complete'] and proof['pairs']==10 and proof['executions']==20 and proof['actual_steps']==2560
   assert proof['source_ref']==job['source'] and proof['registration']['plan_sha256']==sha(job['plan'])
   assert all(sha(job['out']/n)==h for n,h in proof['artifacts'].items())
   done[name]=dict(output=str(job['out']),verification_sha256=sha(verification),development_gate_passed=proof['development_gate_passed'])
  last_sync=0.
  try:
   while len(done)<len(jobs):
    observed=pulse(emit=False)
    if observed['linux']['failures'] or observed['windows']['failures']:raise RuntimeError('Computation failure: '+json.dumps(observed))
    groups={**observed['linux']['pairs'],**observed['windows']['pairs']}
    ready=[n for n in jobs if n not in done and groups[n]['complete']==groups[n]['registered']==10]
    if not (V/'linux_complete.json').exists() and (time.monotonic()-last_sync>=300 or any(n!='consistent' for n in ready)):
     sync();last_sync=time.monotonic()
    for name in ready:
     job=jobs[name]
     folder=U/'results/local_adverse_20261029/consistent' if name=='consistent' else Path(read(V/'latest_snapshot.json')['path'])/name
     proof=archive(folder,job['plan'],job['source'],job['out'])
     done[name]=dict(output=str(job['out']),verification_sha256=sha(job['out']/'verification.json'),development_gate_passed=proof['development_gate_passed'])
    if observed['linux']['complete'] and {'sample8','transfer'}<=done.keys() and not (V/'linux_complete.json').exists():
     (V/'linux_complete.json').write_bytes((V/'linux_live_state.json').read_bytes())
    state.update(state='needs_causal_review' if len(done)==len(jobs) else 'collecting_existing_local_worlds',
      updated=datetime.datetime.now(datetime.timezone.utc).isoformat(),collection_complete=len(done)==len(jobs),archives=done,progress=observed)
    save(state)
    if state['collection_complete']:return
    time.sleep(50)
  except BaseException as error:
   state.update(state='failed',error=repr(error),archives=done,collection_complete=False,updated=datetime.datetime.now(datetime.timezone.utc).isoformat())
   save(state);raise
if __name__=='__main__':main()
