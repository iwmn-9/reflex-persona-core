from pathlib import Path
import subprocess, sys
ROOT = Path(__file__).resolve().parent
def run(script, *, check=True, capture=False):
    args = ['C:/Windows/System32/OpenSSH/ssh.exe', '-i', str(ROOT/'ssh_key'),
            '-p', '48362', '-o', 'UserKnownHostsFile='+str(ROOT/'known_hosts'),
            '-o', 'StrictHostKeyChecking=yes', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15',
            'ubuntu@127.0.0.1', 'bash -se']
    return subprocess.run(args, input=script.replace('\r\n', '\n').replace('\r', '').encode('utf8'), check=check, capture_output=capture)
if __name__ == '__main__':
    run(sys.stdin.read())
