from pathlib import Path
import json,time,sys
from vmctl import run
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]))
from tools.local_checkpoint_io import read_json, atomic_json
def read(p):return read_json(p)
def pulse(emit=True):
    final=ROOT/'linux_complete.json'
    linux=read(final) if final.exists() else json.loads(run('cat /home/ubuntu/recovery/queue_state.json',capture=True).stdout)
    if final.exists():
        assert linux['complete'] and linux['executions_complete']==40 and not linux['failures']
        assert all(x['complete'] and x['actual_steps']==128 for x in linux['progress'])
    atomic_json(ROOT/'linux_live_state.json',linux)
    windows=read(ROOT.parent/'local_adverse_20261029/state.json')
    prep=read(ROOT.parent/'current_model_preparation_20261029/status.json')
    psteps=None
    if prep.get('checkpoint'):
        path=Path(prep['checkpoint'])
        if path.exists():psteps=len(read(path)['payload']['trace'])
    def compact(s):
        groups={}
        for row in s['progress']:
            group=groups.setdefault(row['study'],{})
            group.setdefault(row['case'],[]).append(row['complete'])
        pairs={name:dict(complete=sum(all(flags) for flags in cases.values()),registered=len(cases)) for name,cases in groups.items()}
        return dict(complete=s['complete'],finished=s['executions_complete'],total=s['executions_registered'],failures=s['failures'],
                    pairs=pairs,
                    active=[dict(study=x['study'],case=x['case'],arm=x['arm'],steps=x['actual_steps']) for x in s['progress'] if str(x['index']) in s['active']])
    result=dict(linux=compact(linux),windows=compact(windows),preparation=dict(complete=prep.get('complete'),pairs=prep['pairs_complete'],case=prep.get('case'),mode=prep.get('mode'),steps=psteps,error=prep.get('error')))
    if emit:print(json.dumps(result,separators=(',',':')))
    return result
if __name__=='__main__':pulse()
