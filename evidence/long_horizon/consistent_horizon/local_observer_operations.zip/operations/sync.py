from pathlib import Path
import hashlib,io,json,tarfile,sys
from vmctl import run
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]))
from tools.local_checkpoint_io import atomic_json
def sync():
    result=run("cd /home/ubuntu/recovery\ntar -czf - queue_state.json queue_manifest.json launch.json sample8/prefix_audit.json transfer/prefix_audit.json sample8/latest/*/*.json transfer/latest/*/*.json",capture=True)
    raw=result.stdout
    # Atomic host snapshot: do not expose a partially copied checkpoint to readers.
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        state=json.load(archive.extractfile('queue_state.json'))
        base=ROOT.parent/'linux_snapshots'
        base.mkdir(exist_ok=True)
        number=1+max([int(p.name) for p in base.iterdir() if p.name.isdigit()] or [0])
        target=base/f'{number:04d}'
        target.mkdir(parents=True,exist_ok=False)
        archive.extractall(target,filter='data')
    latest=ROOT/'latest_snapshot.json'
    atomic_json(latest,dict(path=str(target),state=state,
        tar_sha256=hashlib.sha256(raw).hexdigest()))
    print(json.dumps(dict(complete=state['complete'],executions_complete=state['executions_complete'],failures=state['failures'],
        active=[dict(case=x['case'],arm=x['arm'],steps=x['actual_steps']) for x in state['progress'] if str(x['index']) in state['active']]),sort_keys=True))
    return target
if __name__=='__main__':sync()
