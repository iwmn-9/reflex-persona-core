"""Replace only the unstarted waiter, retaining its original bound operation."""
import importlib.util
import json
from pathlib import Path
import sys

V=Path(__file__).parent;old=V/'purpose_finish';root=V/'purpose_finish_env';root.mkdir(exist_ok=False)
script=V/'finish_purpose_study_v2.py'
spec=importlib.util.spec_from_file_location('finish_v2',script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert m.read(old/'status.json')['state']=='retired_before_first_stage'
manifest=m.read(old/'manifest.json')
assert m.read(old/'status.json')['steps']==[]
plan=Path(manifest['stages'][0]['args'][manifest['stages'][0]['args'].index('--plan')+1])
manifest['arithmetic']=dict(m.read(plan)['arithmetic'],OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
manifest['supersedes_unstarted_manifest_sha256']=m.sha(old/'manifest.json')
manifest['files'].pop(str(V/'finish_purpose_study.py'))
manifest['files'][str(script)]=m.sha(script)
(root/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2),encoding='utf8')
# Exercise the real child-launch path without any scientific workload.
test=root/'synthetic_env_test';test.mkdir();proof=test/'child.json';queue=test/'queue.json'
queue.write_text(json.dumps(dict(pid=0,manifest_sha256='synthetic',complete=True,failures={},active={},
    executions_registered=20,executions_complete=20,progress=[dict(complete=True,actual_steps=128) for _ in range(20)])))
keys=list(manifest['arithmetic'])
code="import json,os,sys;from pathlib import Path;Path(sys.argv[1]).write_text(json.dumps(dict(complete=True,adoption=False,scope='synthetic environment only',environment={k:os.environ.get(k) for k in json.loads(sys.argv[2])})))"
fake=dict(parent_pid=0,queue_manifest_sha256='synthetic',queue_state=str(queue),cwd=str(test),
    files={str(script):m.sha(script)},arithmetic=manifest['arithmetic'],
    stages=[dict(kind='env_test',args=['-c',code,str(proof),json.dumps(keys)],proof=str(proof))])
(test/'manifest.json').write_text(json.dumps(fake))
m.run(test)
assert m.read(test/'status.json')['complete'] and m.read(proof)['environment']==manifest['arithmetic']
assert not m.queue_complete(m.read(manifest['queue_state']),manifest)
receipt=dict(complete=True,scientific_execution_started=False,actual_child_environment_matched=True,
    original_process_wait_preflight_sha256=m.sha(old/'preflight.json'),retired_before_any_stage=True,
    manifest_sha256=m.sha(root/'manifest.json'),arithmetic=manifest['arithmetic'])
(root/'preflight.json').write_text(json.dumps(receipt,sort_keys=True),encoding='utf8')
print(json.dumps(dict(root=str(root),**receipt)))
