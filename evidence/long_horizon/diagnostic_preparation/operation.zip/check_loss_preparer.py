import hashlib
import importlib.util
import json
from pathlib import Path

B=Path(__file__).resolve().parents[3]
R=B/'reflex-persona-core';U=B/'reflex-persona-consistent-reading';V=Path(__file__).parent
spec=importlib.util.spec_from_file_location('prepare_loss',R/'tools/prepare_registered_loss_roots.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
old=V/'consistent_loss_roots_20261031';new=V/'loss_preparer_rehearsal_20261031'
assert m.read(old/'plan.json')==m.read(new/'plan.json')
jobs=m.read(new/'plan.json')['jobs']
assert len(jobs)==72 and len({(j['id'],j['tick']) for j in jobs})==12
assert all(m.sha((new/'inputs'/j['input_archive_member']).read_bytes())==j['input_sha256'] for j in jobs)
assert m.sha((new/'driver.py').read_bytes())==m.sha((old/'driver.py').read_bytes())
assert m.sha((new/'probe_registered_owner.py').read_bytes())==m.sha((old/'probe_registered_owner.py').read_bytes())
negative=V/'preparer_negative';negative.mkdir(exist_ok=True)
kwargs=dict(study=negative,worker=B/'reflex-persona-consistent-worker',
    source_plan='evidence/long_horizon/consistent_horizon/plan.json',
    resolver=R/'evidence/long_horizon/adverse_sample_budget/loss_root_resolver.py',
    driver=U/'tools/run_registered_loss_roots.py',probe=U/'tools/probe_registered_owner.py',
    output=negative/'must-not-exist')
checks=[]
def rejected(name,expected,**overrides):
    try:m.prepare(**(kwargs|overrides))
    except (ValueError,FileExistsError) as error:
        assert expected in str(error),(name,error)
        checks.append(dict(case=name,error=str(error)))
    else:raise AssertionError(name)
    assert not (negative/'must-not-exist').exists()
(negative/'verification.json').write_text(json.dumps(dict(complete=False)))
rejected('unfinished','complete audited study required')
(negative/'x').write_bytes(b'changed')
(negative/'verification.json').write_text(json.dumps(dict(complete=True,artifacts={'x':m.sha(b'original')})))
rejected('corrupt_archive','audited artifact changed')
rejected('existing_execution','retain the existing prepared execution',output=new)
rejected('foreign_worker','source and completed study plans differ',
    study=U/'evidence/long_horizon/consistent_horizon/completed_local',
    worker=B/'reflex-persona-purpose-worker',source_plan='evidence/long_horizon/adverse_purpose_tail/plan.json')
try:m.inside(negative,'../escape')
except ValueError:checks.append(dict(case='path_escape',rejected=True))
else:raise AssertionError('path escape')
proof=dict(complete=True,executed_diagnostics=False,adoption=False,exact_original_plan=True,
    exact_prepared_inputs=len(jobs),exact_original_driver_and_probe=True,negative_checks=checks,
    preparer_sha256=m.sha((R/'tools/prepare_registered_loss_roots.py').read_bytes()),
    prepared_manifest_sha256=m.sha((new/'manifest.json').read_bytes()),
    source_study_verification_sha256=m.read(new/'prepared.json')['study_verification_sha256'])
(V/'loss_preparer_verification.json').write_bytes(m.encoded(proof))
print(json.dumps(proof))
