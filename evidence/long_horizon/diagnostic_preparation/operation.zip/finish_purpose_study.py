"""One finite dependency chain; waits on the existing process, never restarts it."""
import argparse
import ctypes
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_bytes())
def write(path,value):
    temp=path.with_suffix('.new');temp.write_text(json.dumps(value,sort_keys=True),encoding='utf8');temp.replace(path)


def queue_complete(state,manifest):
    if (state.get('manifest_sha256')!=manifest['queue_manifest_sha256'] or state.get('pid')!=manifest['parent_pid']):
        raise ValueError('different registered queue')
    if state.get('failures'):raise RuntimeError('registered queue reports a failure')
    return (state.get('complete') is True and not state.get('active')
        and state.get('executions_complete')==state.get('executions_registered')==20
        and len(state.get('progress',[]))==20
        and all(r.get('complete') is True and r.get('actual_steps')==128 for r in state['progress']))


def wait_for_parent(manifest):
    state=read(manifest['queue_state'])
    if queue_complete(state,manifest):return
    if os.name!='nt':raise RuntimeError('native Windows process wait required')
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes=[ctypes.c_uint32,ctypes.c_int,ctypes.c_uint32]
    kernel.OpenProcess.restype=ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_uint32]
    kernel.WaitForSingleObject.restype=ctypes.c_uint32
    kernel.CloseHandle.argtypes=[ctypes.c_void_p]
    handle=kernel.OpenProcess(0x00100000,False,manifest['parent_pid'])
    if not handle:raise RuntimeError('original coordinator is absent before completion; inspect, do not restart')
    try:
        if kernel.WaitForSingleObject(handle,0xFFFFFFFF)!=0:raise RuntimeError('coordinator wait failed')
    finally:kernel.CloseHandle(handle)
    if not queue_complete(read(manifest['queue_state']),manifest):
        raise RuntimeError('coordinator exited before all registered executions completed')


def verify_proof(path,kind):
    proof=read(path)
    required='prepared_complete' if kind=='prepare' else 'complete'
    if proof.get(required) is not True or proof.get('adoption') is not False:
        raise ValueError('stage did not produce a complete non-adoption receipt')
    for name,expected in proof.get('artifacts',{}).items():
        if sha(path.parent/name)!=expected:raise ValueError('completed artifact changed')
    if kind=='study' and (proof['pairs'],proof['executions'],proof['actual_steps'])!=(10,20,2560):
        raise ValueError('all ten pairs and 2560 actual steps required')
    return proof


def run(root):
    root=Path(root).resolve();manifest=read(root/'manifest.json')
    import msvcrt
    with (root/'exclusive.lock').open('ab+') as lock:
        lock.seek(0);lock.write(b'0');lock.flush();lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        state_path=root/'status.json'
        if state_path.exists():raise RuntimeError('inspect existing execution receipt before any restart')
        state=dict(pid=os.getpid(),complete=False,adoption=False,state='waiting_for_original_coordinator',
            manifest_sha256=sha(root/'manifest.json'),steps=[])
        def save():
            state['updated']=datetime.now(timezone.utc).isoformat();write(state_path,state)
        def sources():
            for name,expected in manifest['files'].items():
                if sha(name)!=expected:raise ValueError('bound execution file changed: '+name)
        try:
            sources();save();wait_for_parent(manifest)
            for stage in manifest['stages']:
                sources();state['state']=stage['kind'];save()
                proof_path=Path(stage['proof'])
                if proof_path.exists():raise FileExistsError('inspect existing stage output before resuming: '+str(proof_path))
                with (root/(stage['kind']+'.stdout.log')).open('wb') as stdout, (root/(stage['kind']+'.stderr.log')).open('wb') as stderr:
                    child=subprocess.Popen([sys.executable,*stage['args']],stdout=stdout,stderr=stderr,
                        cwd=manifest['cwd'],creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
                    state['child_pid']=child.pid;save();code=child.wait()
                state.pop('child_pid',None)
                if code:raise subprocess.CalledProcessError(code,stage['args'])
                proof=verify_proof(proof_path,stage['kind'])
                state['steps'].append(dict(kind=stage['kind'],proof=str(proof_path),sha256=sha(proof_path)))
                save()
            state.update(complete=True,state='complete_requires_scientific_review');save()
        except BaseException as error:
            state.update(state='failed_requires_inspection',error=repr(error));save();raise


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',required=True);run(parser.parse_args().root)
