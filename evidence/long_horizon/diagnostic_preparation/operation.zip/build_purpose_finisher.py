"""Bind one finite after-completion workflow; it never schedules repetition."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

V=Path(__file__).resolve().parent;B=V.parents[2]
R=B/'reflex-persona-core';U=B/'reflex-persona-consistent-reading'
Q=B/'reflex-persona-purpose-tail';W=B/'reflex-persona-purpose-worker'
script=V/'finish_purpose_study.py'
spec=importlib.util.spec_from_file_location('finish',script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
root=V/'purpose_finish';root.mkdir(exist_ok=False)
queue=Q/'results/purpose_development_20261031';queue_hash='4211226e040e2142a3315f4eac7d08dd9b0d92dc50b96eb11d46b5ea66810380'
assert m.sha(queue/'manifest.json')==queue_hash
state=m.read(queue/'state.json');assert state['pid']==2372 and not state['failures']
manifest=dict(parent_pid=2372,queue_manifest_sha256=queue_hash,queue_state=str(queue/'state.json'),
    cwd=str(R),classification='One-shot original-study audit and all-loss diagnostics. No adoption or reserved confirmation.',
    source_ref='243c42aef2c9da21ccf4e21e4093aa73f8c0f4d7')
assert not m.queue_complete(state,manifest)
study=Q/'evidence/long_horizon/adverse_purpose_tail/completed_local'
diagnostics=V/'purpose_roots';completed=Q/'evidence/long_horizon/adverse_purpose_tail/roots_complete'
assert not any(p.exists() for p in (study,diagnostics,completed))
plan=W/'evidence/long_horizon/adverse_purpose_tail/plan.json'
resolver=R/'evidence/long_horizon/adverse_sample_budget/loss_root_resolver.py'
driver=U/'tools/run_registered_loss_roots.py';probe=U/'tools/probe_registered_owner.py'
collector=U/'tools/archive_registered_loss_roots.py';prepare=R/'tools/prepare_registered_loss_roots.py'
study_collector=Q/'tools/archive_adverse_study.py'
protocol=Q/'evidence/long_horizon/adverse_purpose_tail/loss_diagnosis_protocol.json'
assert m.sha(resolver)==m.read(protocol)['resolver']['sha256']
assert m.sha(driver)==m.read(protocol)['operational_driver_sha256']
assert m.sha(probe)==m.read(protocol)['diagnostic_source_sha256']
assert m.sha(collector)==m.read(protocol)['collector_sha256']
def stage(kind,args,proof):return dict(kind=kind,args=list(map(str,args)),proof=str(proof))
manifest['stages']=[
    stage('study',[study_collector,'--root',queue/'purpose','--plan',plan,'--source-ref',manifest['source_ref'],
        '--output',study],study/'verification.json'),
    stage('prepare',[prepare,'--study',study,'--worker',W,'--source-plan',plan.relative_to(W),
        '--resolver',resolver,'--driver',driver,'--probe',probe,'--output',diagnostics],diagnostics/'prepared.json'),
    stage('diagnose',[diagnostics/'driver.py','--root',diagnostics,'--workers','8'],diagnostics/'verification.json'),
    stage('archive',[collector,'--execution',diagnostics,'--study',study,'--root-plan',diagnostics/'plan.json',
        '--prepared-manifest',diagnostics/'manifest.json','--resolver',resolver,'--output',completed],completed/'verification.json')]
manifest['files']={str(p):m.sha(p) for p in (script,queue/'manifest.json',plan,plan.parent/'registration.json',
    resolver,driver,probe,collector,prepare,study_collector,protocol)}
(root/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2),encoding='utf8')
# Test only the orchestration, using explicitly synthetic completion receipts.
test=root/'synthetic_wait_test';test.mkdir();state_path=test/'queue.json'
fixture=dict(manifest_sha256='synthetic',pid=0,failures={},complete=False,executions_complete=0,
    executions_registered=20,active={'fixture':0},progress=[])
state_path.write_text(json.dumps(fixture))
code="import json,time,os;from pathlib import Path;p=Path(__import__('sys').argv[1]);time.sleep(.3);p.write_text(json.dumps(dict(manifest_sha256='synthetic',pid=os.getpid(),failures={},complete=True,executions_complete=20,executions_registered=20,active={},progress=[dict(complete=True,actual_steps=128) for _ in range(20)])))"
child=subprocess.Popen([sys.executable,'-c',code,str(state_path)],creationflags=subprocess.CREATE_NO_WINDOW)
fixture['pid']=child.pid;state_path.write_text(json.dumps(fixture))
synthetic=dict(queue_state=str(state_path),parent_pid=child.pid,queue_manifest_sha256='synthetic')
m.wait_for_parent(synthetic);assert child.wait()==0
done=m.read(state_path);assert m.queue_complete(done,synthetic)
done['progress'].pop();assert not m.queue_complete(done,synthetic)
done['failures']={'synthetic':'failure'}
try:m.queue_complete(done,synthetic)
except RuntimeError:pass
else:raise AssertionError('failure did not stop finalization')
receipt=dict(complete=True,scientific_execution_started=False,synthetic_process_wait_passed=True,
    truncated_completion_rejected=True,failures_rejected=True,original_queue_untouched=True,
    all_registered_protocol_tool_hashes_match=True,manifest_sha256=m.sha(root/'manifest.json'))
(root/'preflight.json').write_text(json.dumps(receipt,sort_keys=True),encoding='utf8')
print(json.dumps(dict(root=str(root),**receipt)))
