"""Post-hoc diagnosis at every preregistered high-regret state, not adoption.

The references omit personality and future belief learning. Sensitivity at these
selected states neither estimates a population error rate nor proves that a
different sample bank improves actual long-term play.
"""
import argparse
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--root', default='results/continuation_regret_sampling')
root = Path(parser.parse_args().root); sha = lambda b: hashlib.sha256(b).hexdigest()
plan_bytes = (root / 'plan.json').read_bytes(); plan = json.loads(plan_bytes)
summary = json.loads((root / 'summary.json').read_bytes())
manifest = json.loads((root / 'source_snapshot.json').read_bytes())
assert sha(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()) == plan['source']
assert summary['complete'] and summary['source'] == plan['source']
assert summary['plan_sha256'] == sha(plan_bytes)
assert sha((root / 'manager.py').read_bytes()) == plan['diagnostic_sha256']
for name, expected in manifest.items():
    assert sha((root / '_source' / name).read_bytes()) == expected
sys.path.insert(0, str((root / '_source').resolve()))
from tools.combat_reference import reference
from tools.diagnose_auction_continuity import reference as auction_reference
from tools.run_continuation_portfolio import game_for
from tools.run_owned_value import law

cases = {c['id']: c for c in plan['cases']}; banks = {b['id']: b['seeds'] for b in plan['banks']}
rows = summary['rows']; indexed = {(r['case']['id'], r['bank']): r for r in rows}
assert len(rows) == len(indexed) == len(cases) * len(banks) == 18
assert set(indexed) == {(c, b) for c in cases for b in banks}
prior = json.loads((root / 'selection_input.json').read_bytes())
assert sha((root / 'selection_input.json').read_bytes()) == plan['selection_input']['sha256']
ranked = sorted(prior['rows']['fixed32']['account']['increments'],
    key=lambda r: (-r['purpose_opportunity_loss'], r['tick']))[:6]
assert [c['tick'] for c in plan['cases']] == [r['tick'] for r in ranked]
reviewed = []; actual_replayed = 0
for case in plan['cases']:
    data = (root / case['input']).read_bytes(); assert sha(data) == case['sha256']
    saved = json.loads(data)['payload']; entry = saved['trace'][case['tick']]
    spec = saved['contract']['configuration']['spec']; turns = spec['turns']; world = entry['before']
    original = indexed[case['id'], 'original']; belief = original['root_prediction']
    assert original['fixed32_selected'] == case['fixed32_ballot']
    assert original['fixed32_selected']['action'] == entry['action']
    evaluations = {}
    for end in sorted({turns, min(turns, case['tick']+32)}):
        evaluations[str(end)] = {}
        for kind in ('true_law', 'stationary_root_belief'):
            probabilities = ((lambda t: tuple(law(t, turns, spec['regime']).values())) if kind == 'true_law'
                else (lambda _: tuple(belief.values())))
            if spec['game'] == 'combat':
                _, choices = reference(end, probabilities)
                values = {k: v*end/turns for k, v in choices(world).items()}
                checks = 0
            elif spec['game'] == 'auction':
                game = game_for(spec)
                q = auction_reference(end, spec['seed'] % 2, probabilities)
                def options(w):
                    offset = (w['score']-w['rival'])/(8*turns)
                    return {k:v*end/turns+offset for k,v in q(w['tick'],int(w['cash'])).items()}
                def value(w):
                    return game.goal(w).value if w['tick'] == end else max(options(w).values())
                values = options(world)
                assert set(values) == set(game.keys(world))
                for action, expected in values.items():
                    actual = sum(p*value(game.transition(world,action,str(z))[0])
                        for z,p in enumerate(probabilities(world['tick'])))
                    assert abs(actual-expected) < 1e-10
                checks = len(values)
            else:
                raise ValueError('Existing evaluator references cover auction and combat')
            best = max(values.values())
            evaluations[str(end)][kind] = dict(values=values,
                best_actions=sorted(k for k,v in values.items() if abs(v-best) < 1e-12),
                bellman_checks=checks)
    samples = []
    for bank, seeds in banks.items():
        r = indexed[case['id'], bank]
        assert r['case'] == case and r['seeds'] == seeds and r['minimum_horizon'] == 32
        assert r == json.loads((root / (case['id']+'-'+bank+'.json')).read_bytes())
        assert r['factual_owner_unchanged'] and r['factual_world_unchanged']
        assert r['source_owner'] == case['actual_fixed32_owner'] == entry['before_owner']
        assert r['root_prediction'] == belief
        assert len(r['ballots']) == 1 and r['ballots'][0] == r['fixed32_selected'] == r['consensus_selected']
        action = r['fixed32_selected']['action']; losses = {}
        for end, refs in evaluations.items():
            losses[end] = {kind: max(ref['values'].values())-ref['values'][action] for kind, ref in refs.items()}
        samples.append(dict(bank=bank, seeds=seeds, action=action, horizon=r['fixed32_selected']['horizon'],
            model_purpose=r['purpose_review'], reference_losses=losses))
        actual_replayed += case['tick']
    full_belief = evaluations[str(turns)]['stationary_root_belief']['best_actions']
    reviewed.append(dict(case=case['id'], tick=case['tick'], regret_rank=case['regret_rank'],
        factual_action=entry['action'], world=world, root_prediction=belief,
        actual_observations=dict(Counter(t['response'] for t in saved['trace'][:case['tick']])),
        factual_action_matches_stationary_reference=entry['action'] in full_belief,
        action_varies=len({r['action'] for r in samples}) > 1,
        references=evaluations, samples=samples))
out = dict(complete=True, adoption=False, source=plan['source'], plan_sha256=sha(plan_bytes),
    probes=18, original_actions_and_purposes_reproduced=6, actual_past_decisions_replayed=actual_replayed,
    varying_states=sum(r['action_varies'] for r in reviewed),
    factual_choices_matching_stationary_reference=sum(r['factual_action_matches_stationary_reference'] for r in reviewed),
    rows=reviewed, input_summary_sha256=sha((root/'summary.json').read_bytes()),
    script_sha256=sha(Path(__file__).read_bytes()), limit=__doc__)
(root/'review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))
