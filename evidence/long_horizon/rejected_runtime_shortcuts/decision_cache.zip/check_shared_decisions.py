"""Exact output/cost comparison before and after duplicate continuation reuse."""
import argparse
import dataclasses
import hashlib
import json
from pathlib import Path
import sys
import time


def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(raw):return hashlib.sha256(raw).hexdigest()


def normalized(value):
    value=json.loads(encoded(value))
    counts=value['deliberation']['metadata']['continuation_portfolio']
    counts.pop('recovery_cache');counts['tail_purpose_reflex'].pop('calls')
    counts.pop('reused_steps',None);counts.pop('memoized_decisions',None)
    return value


def run(source,output,reference=None):
    source,output=Path(source),Path(output)
    if output.exists():raise FileExistsError(output)
    sys.path.insert(0,str(source))
    from tests.test_gain_retry import evaluate
    from tools.preparation_world import PreparationChain,DelayedYield
    from tools.continuing_games import ContinuingGame
    from reflex.laboratory import PROFILES
    specs=[(name,ContinuingGame(name,PROFILES[0],turns=128),4)
           for name in ('auction','combat','gambling','resources')]
    specs += [('chain5',PreparationChain(5,payout=14.,turns=128),8),
              ('chain11',PreparationChain(11,payout=24.,turns=128),32),
              ('delayed11',DelayedYield(11,payout=6.,turns=128),32)]
    rows=[];sources={str(p.relative_to(source)):sha(p.read_bytes())
        for folder in ('reflex','tools') for p in (source/folder).rglob('*.py')}
    for name,game,horizon in specs:
        start=time.perf_counter();cpu=time.process_time()
        result,cap=evaluate(game,True,horizon=horizon)
        wall=time.perf_counter()-start;cpu=time.process_time()-cpu
        forecast=dataclasses.asdict(cap['forecast'])
        # Only actual computation counters may change. Logical paths, values,
        # all final owners, selection and logical simulated steps must match.
        counts=forecast['audit']['continuation_portfolio']
        runtime=dict(recovery_cache=counts.pop('recovery_cache'),
            purpose_calls=counts['tail_purpose_reflex'].pop('calls'),
            reused_steps=counts.pop('reused_steps',0),memoized_decisions=counts.pop('memoized_decisions',0))
        payload=dict(forecast=forecast,decision=result['decision'],deliberation=result['deliberation'],
            paths={key:[dataclasses.asdict(b) for b in branches] for key,branches in cap['paths'].items()},
            modeled=cap['modeled'],logical_steps=cap['simulated_steps'])
        rows.append(dict(case=name,horizon=horizon,cpu=cpu,wall=wall,runtime=runtime,
            result=payload,result_sha256=sha(encoded(payload))))
    proof=dict(complete=True,rows=rows,sources=sources,adoption=False)
    if reference:
        before=json.loads(Path(reference).read_bytes())
        proof['differences']=[new['case'] for old,new in zip(before['rows'],rows)
            if encoded(normalized(old['result']))!=encoded(normalized(new['result']))]
        proof['normalized_sha256']=[sha(encoded(normalized(r['result']))) for r in rows]
        proof['reference_sha256']=sha(Path(reference).read_bytes())
        proof['old_cpu']=sum(r['cpu'] for r in before['rows']);proof['new_cpu']=sum(r['cpu'] for r in rows)
    output.write_bytes(encoded(proof))
    print(json.dumps(dict(cases=len(rows),cpu=sum(r['cpu'] for r in rows),
        differences=proof.get('differences'),reused_steps=sum(r['runtime']['reused_steps'] for r in rows))))
    if proof.get('differences'):raise AssertionError(proof['differences'])


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--output',required=True)
    p.add_argument('--reference');run(**vars(p.parse_args()))
