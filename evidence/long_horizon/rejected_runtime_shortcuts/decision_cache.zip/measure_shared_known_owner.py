"""Paired runtime measurement on the already published 96-step owner.

This is an equivalence check, not a new world or a newly selected adverse root.
"""
import argparse
import dataclasses
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import time
import zipfile

def encoded(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(raw):return hashlib.sha256(raw).hexdigest()

def measure(source,archive,output):
    source,archive,output=map(lambda p:Path(p).resolve(),(source,archive,output))
    if output.exists():raise FileExistsError('retain the existing measurement')
    if sha(archive.read_bytes())!='363945f33fa9146a4a96bff86e6f92b02bb9d7fd2c62f02b3d384ef5457f6f94':
        raise ValueError('unchanged published factual owner required')
    sources={p.relative_to(source).as_posix():sha(p.read_bytes())
        for folder in ('reflex','tools') for p in (source/folder).rglob('*.py')}
    with zipfile.ZipFile(archive) as packed:
        saved=json.loads(packed.read('input.json'));golden=json.loads(packed.read('transfer_purpose.json'))
    sys.path.insert(0,str(source))
    import numpy as np
    from reflex.core import character_key,digest
    from reflex.decision_loop import DecisionLoop
    from reflex.model_observer import resolve_feedback
    from tools import run_adverse_recovery as runtime
    from tools.run_owned_value import law,sample
    assert Path(runtime.__file__).resolve().is_relative_to(source)
    spec=saved['configuration']['spec'];game=runtime.game_for(spec)
    world=game.start();actor=runtime.actor_for(game,game.context(world),'transfer_purpose_gain')
    rng=np.random.default_rng(spec['seed']);persona=character_key(game.context(world))
    for row in saved['trace'][:96]:
        assert world==row['before'] and digest(actor.record())==row['before_owner']
        context=game.context(world,actor.state)
        result=DecisionLoop.decide_batch([(actor,game.request(context))],False,
            _counterfactual_roots=(row['action'],))[0]
        truth=law(world['tick'],spec['turns'],spec['regime'])
        assert truth==row['truth'] and sample(truth,rng.random())==row['response']
        after,flow=game.transition(world,row['action'],row['response'])
        resolve_feedback(actor,result['ticket'],game.feedback(world,after,row['action'],context,flow))
        assert after==row['after'] and digest(actor.record())==row['owner']
        assert character_key(game.context(after))==persona
        world=after
    owner=digest(actor.record());assert owner==golden['factual_owner']
    wall=time.perf_counter();cpu=time.process_time()
    result,cap=runtime.decide(actor,game,world,'transfer_purpose_gain',seeds=(701,702,703))
    elapsed=time.perf_counter()-wall;cpu=time.process_time()-cpu
    forecast=dataclasses.asdict(cap['forecast'])
    counts=forecast['audit']['continuation_portfolio']
    costs=dict(recovery_cache=counts.pop('recovery_cache'),purpose_calls=counts['tail_purpose_reflex'].pop('calls'),
        reused_steps=counts.pop('reused_steps'),memoized_decisions=counts.pop('memoized_decisions',0))
    deliberation=json.loads(encoded(result['deliberation']))
    dcounts=deliberation['metadata']['continuation_portfolio']
    dcounts.pop('recovery_cache');dcounts['tail_purpose_reflex'].pop('calls');dcounts.pop('reused_steps');dcounts.pop('memoized_decisions',None)
    symbol=sample(law(world['tick'],spec['turns'],spec['regime']),rng.random())
    action=result['decision']['action_id'];after,flow=game.transition(world,action,symbol)
    resolve_feedback(actor,result['ticket'],game.feedback(world,after,action,result['context'],flow))
    saved_owner=json.loads(encoded(actor.record()))
    restored=DecisionLoop.from_record(result['context'],saved_owner,predictor=actor.predictor)
    assert restored.record()==saved_owner
    actual=dict(factual_owner=owner,forecast=forecast,decision=result['decision'],deliberation=deliberation,
        modeled=cap['modeled'],paths={k:[dataclasses.asdict(b) for b in bs] for k,bs in cap['paths'].items()},
        logical_steps=cap['simulated_steps'],one_step=dict(symbol=symbol,after=after,owner=saved_owner,rng=rng.bit_generator.state))
    assert all(sha((source/n).read_bytes())==h for n,h in sources.items())
    proof=dict(complete=True,adoption=False,source=str(source),sources=sources,source_sha256=sha(encoded(sources)),
        exact_96_step_owner=True,one_actual_feedback_and_restore=True,actual=actual,
        normalized_sha256=sha(encoded(actual)),costs=costs,cpu_seconds=cpu,wall_seconds=elapsed,
        archive_sha256=sha(archive.read_bytes()),script_sha256=sha(Path(__file__).read_bytes()),
        runtime=dict(python=sys.version,numpy=np.__version__,system=platform.system(),machine=platform.machine(),
            arithmetic={k:os.environ.get(k) for k in ('NPY_DISABLE_CPU_FEATURES','OPENBLAS_CORETYPE','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')}),
        scope='Known published owner only; exact runtime comparison plus one counterfactual physical transition/feedback/restore, not a new long-world study.')
    output.write_bytes(encoded(proof))
    print(json.dumps({k:proof[k] for k in ('complete','normalized_sha256','cpu_seconds','wall_seconds','exact_96_step_owner')}),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ('source','archive','output'):parser.add_argument('--'+key,required=True)
    measure(**vars(parser.parse_args()))
