from pathlib import Path
p=Path("C:/Users/iwakura/Documents/Project(Gemini)/Colabo/github-preview/reflex-persona-shared-runtime/reflex/_continuation_portfolio.py")
s=p.read_text()
start=s.index('                            future = None\n')
end=s.index("                            key = result['decision']['action_id']\n",start)
old=s[start:end]
intro="""                            decision_stamp = None
                            if retry_until_gain and _DECISION_CACHE_CAPACITY and current_request.reader is None and current_request.value_proposal is None:
                                # One invocation, complete same-world/same-owner
                                # input, same request and remaining recovery budget.
                                # Pure model callbacks are the existing contract.
                                # Outcomes and factual feedback still run separately.
                                try:
                                    decision_stamp = digest([w, own.record(), asdict(current_request), key, recovery_calls])
                                except (TypeError, ValueError):
                                    pass
                            if decision_stamp is not None and decision_stamp in decision_cache:
                                cached = decision_cache[decision_stamp]
                                decision_cache.move_to_end(decision_stamp)
                                own, result = copy.deepcopy(cached['owner']), copy.deepcopy(cached['result'])
                                recovery_calls = cached['recovery_calls']
                                decision_hits += 1
                            else:
"""
body=''.join('    '+line if line.strip() else line for line in old.splitlines(True))
outro="""                                if decision_stamp is not None:
                                    decision_cache[decision_stamp] = dict(owner=copy.deepcopy(own),
                                        result=copy.deepcopy(result), recovery_calls=recovery_calls)
                                    while len(decision_cache) > _DECISION_CACHE_CAPACITY:
                                        decision_cache.popitem(last=False)
"""
s=s[:start]+intro+body+outro+s[end:]
needle="            metadata['continuation_portfolio']['reused_steps'] = reused_steps"
s=s.replace(needle,needle+"\n            metadata['continuation_portfolio']['memoized_decisions'] = decision_hits")
p.write_text(s)

