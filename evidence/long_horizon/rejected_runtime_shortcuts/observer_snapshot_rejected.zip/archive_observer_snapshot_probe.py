"""Reject a runtime shortcut without treating tiny timing changes as progress."""
from datetime import datetime,timezone
from pathlib import Path
import json,subprocess,zipfile
from prepare_reserved_purpose_confirmation import read,encoded,sha
local=Path(__file__).resolve().parent;base=local.parents[2]
probe=base/'reflex-persona-observer-runtime';repository=base/'reflex-persona-core'
matrix=read(local/'observer_snapshot_matrix.json')
known=read(local/'observer_snapshot_known_owner.json')
old=read(local/'prepared_responses_known_candidate.json')
assert matrix['complete'] and not matrix['differences'] and len(matrix['rows'])==7
assert known['complete'] and known['actual']==old['actual']
assert known['normalized_sha256']=='c8bb84020793305a4cb0e7597084390c5ee7fb2ca4ae3dc1432ae9f564ac441a'
changed=subprocess.check_output(['git','diff','--name-only'],cwd=probe,text=True).splitlines()
assert changed==['reflex/_continuation_portfolio.py']
patch=subprocess.check_output(['git','diff','--binary'],cwd=probe)
out=repository/'evidence/long_horizon/rejected_runtime_shortcuts'
archive=out/'observer_snapshot_rejected.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as packed:
    packed.writestr('rejected.patch',patch)
    for name in ('observer_snapshot_matrix.json','observer_snapshot_known_owner.json',
            'prepared_responses_matrix.json','prepared_responses_known_candidate.json',
            'check_gain_path_reuse.py','measure_gain_known_owner.py','archive_observer_snapshot_probe.py'):
        packed.write(local/name,name)
proof=dict(complete=True,adopted=False,at=datetime.now(timezone.utc).isoformat(),
    base_source='493a685ab2837c999d13d832dc25a51068845fb5',
    patch_sha256=sha(patch),archive_sha256=sha(archive.read_bytes()),
    cases_exact=7,experienced_h32_forecast_feedback_restore_exact=True,
    matrix_cpu_seconds=[matrix['old_cpu'],matrix['new_cpu']],
    experienced_cpu_seconds=[old['cpu_seconds'],known['cpu_seconds']],
    reason='Both CPU differences are about2 percent, insufficient evidence of a useful reduction to justify a second snapshot contract. Retain original full detached-owner semantics.',
    limits=['Comparison reference timings were collected earlier, so small differences are not a reliable speedup estimate.',
        'World studies, sources, thresholds, personality and original stable/Rust are unchanged.',
        'No extra full regression or adoption work is launched for this rejected shortcut.'])
(out/'observer_snapshot_rejected.json').write_bytes(encoded(proof))
resume=repository/'results/long_horizon_resume_status.json';state=read(resume)
state['updated']=datetime.now(timezone.utc).isoformat()
state['active_observer_snapshot_probe'].update(state='complete_rejected',running=False,
    evidence=str(out/'observer_snapshot_rejected.json'),
    experienced_cpu_seconds=proof['experienced_cpu_seconds'])
resume.write_text(json.dumps(state,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(proof))
