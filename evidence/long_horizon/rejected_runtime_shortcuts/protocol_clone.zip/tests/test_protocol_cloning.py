"""Owned-state acceleration must preserve the standard copy protocols."""
import copy
import unittest
from collections import OrderedDict, deque

from reflex.cloning import deepcopy


class ProtocolCloningTests(unittest.TestCase):
    def test_custom_hook_can_override_later_atomic_values_in_shared_memo(self):
        atom = 782394572349
        class Hook:
            def __deepcopy__(self, memo):
                memo[id(atom)] = 'replacement'
                return 'hook'
        original = [Hook(), atom, {atom: atom}, (atom,)]
        self.assertEqual(deepcopy(original), copy.deepcopy(original))

    def test_slot_state_and_reduction_keep_cross_type_aliases_and_cycles(self):
        class Owner:
            __slots__ = ('child', 'other', 'history')
        owner = Owner()
        owner.child = OrderedDict()
        owner.other = owner.child
        owner.history = deque([owner.child], maxlen=4)
        owner.child['parent'] = owner
        for copied in (deepcopy(owner), copy.deepcopy(owner)):
            self.assertIsNot(copied, owner)
            self.assertIs(copied.child, copied.other)
            self.assertIs(copied.history[0], copied.child)
            self.assertIs(copied.child['parent'], copied)
            self.assertEqual(copied.history.maxlen, 4)

    def test_custom_state_and_instance_reducer_are_still_executed(self):
        calls = []
        class State:
            def __getstate__(self):
                calls.append('get'); return {'values': [1, 2]}
            def __setstate__(self, state):
                calls.append('set'); self.values = state['values'] + [3]
        owner = State()
        expected = copy.deepcopy(owner); reference = calls[:]; calls.clear()
        actual = deepcopy(owner)
        self.assertEqual(vars(actual), vars(expected)); self.assertEqual(calls, reference)
        owner.__reduce_ex__ = lambda protocol: (dict, (), None, None, iter([('protocol', protocol)]))
        self.assertEqual(deepcopy(owner), copy.deepcopy(owner))


if __name__ == '__main__':
    unittest.main()
