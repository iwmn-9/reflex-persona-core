"""Paired runtime measurement on the already published 96-step owner.

This is an equivalence check, not a new world or a newly selected adverse root.
"""
import argparse
import dataclasses
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import time
import zipfile

def encoded(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(raw):return hashlib.sha256(raw).hexdigest()

def measure(source,archive,output):
    source,archive,output=map(lambda p:Path(p).resolve(),(source,archive,output))
    if output.exists():raise FileExistsError('retain the existing measurement')
    if sha(archive.read_bytes())!='363945f33fa9146a4a96bff86e6f92b02bb9d7fd2c62f02b3d384ef5457f6f94':
        raise ValueError('unchanged published factual owner required')
    sources={p.relative_to(source).as_posix():sha(p.read_bytes())
        for folder in ('reflex','tools') for p in (source/folder).rglob('*.py')}
    with zipfile.ZipFile(archive) as packed:
        saved=json.loads(packed.read('input.json'));golden=json.loads(packed.read('transfer_purpose.json'))
    sys.path.insert(0,str(source))
    import numpy as np
    from reflex.core import character_key,digest
    from reflex.decision_loop import DecisionLoop
    from reflex.model_observer import resolve_feedback
    from tools import run_adverse_recovery as runtime
    from tools.run_owned_value import law,sample
    assert Path(runtime.__file__).resolve().is_relative_to(source)
    spec=saved['configuration']['spec'];game=runtime.game_for(spec)
    world=game.start();actor=runtime.actor_for(game,game.context(world),'transfer_purpose_gain')
    rng=np.random.default_rng(spec['seed']);persona=character_key(game.context(world))
    for row in saved['trace'][:96]:
        assert world==row['before'] and digest(actor.record())==row['before_owner']
        context=game.context(world,actor.state)
        result=DecisionLoop.decide_batch([(actor,game.request(context))],False,
            _counterfactual_roots=(row['action'],))[0]
        truth=law(world['tick'],spec['turns'],spec['regime'])
        assert truth==row['truth'] and sample(truth,rng.random())==row['response']
        after,flow=game.transition(world,row['action'],row['response'])
        resolve_feedback(actor,result['ticket'],game.feedback(world,after,row['action'],context,flow))
        assert after==row['after'] and digest(actor.record())==row['owner']
        assert character_key(game.context(after))==persona
        world=after
    owner=digest(actor.record());assert owner==golden['factual_owner']

    import importlib.util
    module_spec=importlib.util.spec_from_file_location('previous_cloning',str(source.parent/'reflex-persona-retry-runtime'/'reflex'/'cloning.py'))
    previous=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(previous)
    from reflex import cloning
    measurements=[]
    for label,value in [('experienced_owner',actor),('effective_context',game.context(world,actor.state))]:
        for repeat in range(3):
            for name,clone in [('previous',previous.deepcopy),('proposed',cloning.deepcopy)]:
                start=time.process_time()
                for _ in range(100):copied=clone(value)
                used=time.process_time()-start
                assert (copied.record()==value.record()) if label=='experienced_owner' else copied==value
                measurements.append(dict(case=label,repeat=repeat,variant=name,cpu_seconds=used))
    proof=dict(complete=True,adopt=False,measurements=measurements,owner=owner,
        source_sha256=sha(encoded(sources)),sources=sources,script_sha256=sha(Path(__file__).read_bytes()),
        note='Matched copy microbenchmark; no additional scientific outcomes or full forecast validation.')
    output.write_bytes(encoded(proof))
    print(json.dumps(proof['measurements']),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ('source','archive','output'):parser.add_argument('--'+key,required=True)
    measure(**vars(parser.parse_args()))
