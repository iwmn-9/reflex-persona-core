"""Retain the completed, rejected runtime screen; never touch live science."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

base=Path(__file__).resolve().parent
workspace=base.parents[2]
repo=workspace/'reflex-persona-core'
candidate=workspace/'reflex-persona-preflight-runtime'
destination=repo/'evidence/long_horizon/rejected_runtime_shortcuts'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
screen=json.loads((base/'preflight_runtime_screen.json').read_bytes())
assert screen['exact'] and screen['cases']==13 and screen['ratio']>=1
before=json.loads((base/'preflight_runtime_before.json').read_bytes())
after=json.loads((base/'preflight_runtime_after.json').read_bytes())
assert all(a['result']==b['result'] for a,b in zip(before['rows'],after['rows']))
assert len(before['rows'])==len(after['rows'])==13
patch=subprocess.check_output(['git','diff','--binary','--','reflex/_continuation_portfolio.py'],cwd=candidate)
assert patch
archive=destination/'preflight_rejected.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as packed:
    for name in ('check_preflight_runtime.py','run_preflight_screen.py',
                 'preflight_runtime_before.json','preflight_runtime_after.json',
                 'preflight_runtime_screen.json','preflight_runtime_screen.stdout.log',
                 'preflight_runtime_screen.stderr.log'):
        packed.writestr(name,(base/name).read_bytes())
    packed.writestr('runtime.patch',patch)
    packed.writestr('candidate_continuation_portfolio.py',(candidate/'reflex/_continuation_portfolio.py').read_bytes())
    packed.writestr('archive_preflight_rejection.py',Path(__file__).read_bytes())
proof=dict(complete=True,adopted=False,at=datetime.now(timezone.utc).isoformat(),
    base_source='493a685ab2837c999d13d832dc25a51068845fb5',
    archive_sha256=sha(archive.read_bytes()),patch_sha256=sha(patch),
    cases_exact=13,cpu_seconds=[screen['before_cpu'],screen['after_cpu']],
    reason='All full forecasts, decisions, trajectories, learner hashes and counters match, but the fixed screen gives no CPU reduction. Do not invest in further qualification or replace any live worker.',
    limits=['Fixed-root runtime screen only, not a quality or long-play comparison.',
            'No experienced-owner or full regression qualification claimed for this rejected change.',
            'Stable release, Rust, live study sources, seeds, histories and adoption criteria remain unchanged.'])
output=destination/'preflight_rejected.json'
with output.open('x',encoding='utf-8') as stream:json.dump(proof,stream,ensure_ascii=False,sort_keys=True,indent=2)
handoff=repo/'results/long_horizon_resume_status.json'
saved=json.loads(handoff.read_bytes())
saved['updated']=proof['at']
saved['operational']['active_runtime_probe']['status']='Completed and rejected:13 exact outputs,68.65625 to69.28125 CPU seconds. No active runtime screen.'
saved['operational']['active_runtime_probe']['next']='Preserve rejection; do not run the prepared experienced-owner screen or qualify this runtime change.'
saved['completed']['rejected_preflight_runtime']=dict(proof=str(output),result=proof['reason'])
handoff.write_text(json.dumps(saved,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof))
