"""One finite serial before/after screen; no live study is modified."""
import json
import os
from pathlib import Path
import subprocess
import sys
import hashlib

here=Path(__file__).resolve().parent;base=here.parents[2]
os.environ.update(NPY_DISABLE_CPU_FEATURES='AVX512F,AVX512CD,AVX512_SKX,AVX512_CLX,AVX512_CNL,AVX512_ICL',
    OPENBLAS_CORETYPE='Haswell',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
for name,source in [('before',base/'reflex-persona-relative-worlds'),('after',base/'reflex-persona-preflight-runtime')]:
    output=here/f'preflight_runtime_{name}.json'
    if output.exists():raise FileExistsError('inspect retained output before any explicit new screen')
    subprocess.run([sys.executable,'-u',str(here/'check_preflight_runtime.py'),'--source',str(source),'--output',str(output)],
        check=True,creationflags=(subprocess.CREATE_NO_WINDOW|subprocess.NORMAL_PRIORITY_CLASS) if os.name=='nt' else 0)
before=json.loads((here/'preflight_runtime_before.json').read_bytes())
after=json.loads((here/'preflight_runtime_after.json').read_bytes())
assert [row['case'] for row in before['rows']]==[row['case'] for row in after['rows']]
differences=[a['case'] for a,b in zip(before['rows'],after['rows']) if a['result']!=b['result']]
record=dict(exact=not differences,differences=differences,cases=len(after['rows']),
    before_cpu=before['cpu_seconds'],after_cpu=after['cpu_seconds'],
    ratio=after['cpu_seconds']/before['cpu_seconds'],
    before_sha256=hashlib.sha256((here/'preflight_runtime_before.json').read_bytes()).hexdigest(),
    after_sha256=hashlib.sha256((here/'preflight_runtime_after.json').read_bytes()).hexdigest(),
    runtime_only=True,adoption=False,current_studies_changed=False)
with (here/'preflight_runtime_screen.json').open('x',encoding='utf8') as stream:json.dump(record,stream,indent=2)
print(json.dumps(record),flush=True)
if differences:raise AssertionError(differences)
