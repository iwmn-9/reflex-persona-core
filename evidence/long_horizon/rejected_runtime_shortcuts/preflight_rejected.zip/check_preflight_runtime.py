"""Isolated exact-output/cost screen for eliminating unused preflight work."""
import argparse
import dataclasses
import hashlib
import json
from pathlib import Path
import sys
import time

def encoded(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def run(source,output):
    source,output=Path(source).resolve(),Path(output).resolve()
    if output.exists():raise FileExistsError('retain measurements')
    sources={p.relative_to(source).as_posix():sha(p.read_bytes())
             for folder in ('reflex','tools','tests') for p in (source/folder).rglob('*.py')}
    sys.path.insert(0,str(source))
    from tests.test_gain_retry import evaluate as origin
    from tests.test_relative_gain import evaluate as relative
    from tools.continuing_games import ContinuingGame
    from tools.preparation_world import PreparationChain,DelayedYield
    from tools.background_preparation import BackgroundChain
    from reflex.laboratory import PROFILES
    cases=[('origin-'+name,origin,ContinuingGame(name,PROFILES[0],turns=128),dict(enabled=True,horizon=4))
           for name in ('auction','combat','gambling','resources')]
    cases += [('chain5',origin,PreparationChain(5,payout=14.,turns=128),dict(enabled=True,horizon=8)),
              ('chain11',origin,PreparationChain(11,payout=24.,turns=128),dict(enabled=True,horizon=32)),
              ('delayed11',origin,DelayedYield(11,payout=6.,turns=128),dict(enabled=True,horizon=32))]
    cases += [('relative-'+name,relative,ContinuingGame(name,PROFILES[0],turns=128),dict(horizon=4,seeds=(701,702)))
              for name in ('auction','combat','gambling','resources')]
    cases += [('background-profitable',relative,BackgroundChain(1.125,payout=14.),dict(horizon=8)),
              ('background-unprofitable',relative,BackgroundChain(1.125,payout=5.),dict(horizon=8))]
    rows=[]
    for name,evaluate,game,options in cases:
        cpu=time.process_time();wall=time.perf_counter()
        result,cap=evaluate(game,**options)
        elapsed_cpu=time.process_time()-cpu;elapsed_wall=time.perf_counter()-wall
        payload=dict(forecast=dataclasses.asdict(cap['forecast']),result=result,
            paths={key:[dataclasses.asdict(branch) for branch in branches] for key,branches in cap['paths'].items()},
            modeled=cap['modeled'],logical_steps=cap['simulated_steps'])
        rows.append(dict(case=name,cpu_seconds=elapsed_cpu,wall_seconds=elapsed_wall,
            result=payload,sha256=sha(encoded(payload))))
        print(json.dumps(dict(case=name,cpu_seconds=elapsed_cpu,wall_seconds=elapsed_wall)),flush=True)
    if any(sha((source/name).read_bytes())!=value for name,value in sources.items()):
        raise ValueError('Source changed during the fixed screen')
    proof=dict(complete=True,source=str(source),sources=sources,source_sha256=sha(encoded(sources)),
        rows=rows,cpu_seconds=sum(r['cpu_seconds'] for r in rows),script_sha256=sha(Path(__file__).read_bytes()),
        adoption=False,new_world_histories=0,scope='Fresh and synthetic fixed roots for exact implementation/cost comparison, not a new long-play result.')
    with output.open('xb') as stream:stream.write(encoded(proof))
    print(json.dumps(dict(complete=True,cases=len(rows),cpu_seconds=proof['cpu_seconds'])),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--output',required=True)
    run(**vars(p.parse_args()))
