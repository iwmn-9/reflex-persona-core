from pathlib import Path
import hashlib,json,subprocess,zipfile
def sha(raw):return hashlib.sha256(raw).hexdigest()
def enc(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
local=Path(__file__).resolve().parent;base=local.parents[2]
source=base/'reflex-persona-prefix-runtime'
original=base/'reflex-persona-gain-integration'
output=base/'reflex-persona-core/evidence/long_horizon/rejected_runtime_shortcuts'
matrix=json.loads((local/'gain_prefix_matrix.json').read_bytes())
known=json.loads((local/'gain_prefix_known_candidate.json').read_bytes())
old=json.loads((local/'prepared_responses_known_candidate.json').read_bytes())
assert matrix['complete'] and matrix['differences']==[]
assert known['complete'] and known['actual']==old['actual']
assert known['normalized_sha256']==old['normalized_sha256']
assert all(sha((source/n).read_bytes())==h for n,h in known['sources'].items())
base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
assert base_commit=='65958eb3b2a76a939c19466325b693e9321e0254'
patch=subprocess.check_output(['git','diff','--binary','--','reflex/_continuation_portfolio.py'],cwd=source)
assert patch
proof=dict(complete=True,adopted=False,base_commit=base_commit,
    change='Replay common until-gain prefix only once, then continue the same learned owner after the structural policy fork.',
    exact_matrix_cases=7,exact_experienced_h32_payload=known['normalized_sha256'],
    matrix_cpu=dict(reference=matrix['old_cpu'],candidate=matrix['new_cpu']),
    experienced_cpu=dict(reference=old['cpu_seconds'],candidate=known['cpu_seconds']),
    regression_suite_run=False,test_draft_run=False,
    decision='Reject: no demonstrated processing-time reduction. Avoid maintaining another continuation state path for this result.',
    limits='Two bounded runtime comparisons, not new scientific trials, an adoption gate or broad performance proof. All live sources and stable package unchanged.')
archive=output/'gain_prefix_rejected.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as packed:
    packed.writestr('patch.diff',patch);packed.writestr('verification.json',enc(proof))
    for name in ('gain_prefix_matrix.json','gain_prefix_known_candidate.json','prepared_responses_known_candidate.json'):
        packed.write(local/name,name)
    packed.write(source/'tests/test_gain_prefix_runtime.py','unrun_test_draft.py')
    packed.write(Path(__file__),Path(__file__).name)
proof['archive_sha256']=sha(archive.read_bytes())
(output/'gain_prefix_rejected.json').write_bytes(enc(proof))
print(json.dumps(proof),flush=True)
