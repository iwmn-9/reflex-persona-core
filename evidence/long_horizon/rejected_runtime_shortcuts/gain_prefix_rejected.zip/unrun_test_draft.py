"""Same complete learned continuations, computed once up to their first fork."""
import copy
from dataclasses import asdict
import unittest
from unittest.mock import patch

from reflex import _continuation_portfolio as runtime
from reflex.core import digest
from reflex.decision_loop import DecisionLoop
from reflex.laboratory import PROFILES
from tools.continuing_games import ContinuingGame
from tools.preparation_world import PreparationChain, DelayedYield
from tools.run_owned_value import cumulative_basis


def evaluate(game, *, reuse, horizon, sampling='independent', scope='root', world_model='posterior'):
    world=game.start();actor=game.actor(game.context(world),learning='segmented')
    before=digest(actor.record());request=game.request(game.context(world,actor.state));captured={}
    planner=runtime.portfolio_planner(actor,request,world,observe=game.context,events=game.events,
        terminal=game.terminal,assess=lambda w:game.goal(w).record(),request_for=game.request,
        feedback=game.feedback,model_id=game.model_id,target=game.target,horizon=horizon,
        seeds=(701,702),world_model=world_model,cumulative_preference=cumulative_basis(game,True),
        captured=captured,purpose_estimator='conditional',tail_recovery=2,recovery_cache=64,
        coherent_cumulative_mean=True,tail_purpose_reflex=True,retry_until_gain=True,
        capture_prefixes=True,sampling=sampling,continuation_scope=scope)
    original=runtime._gain_path_fork
    with patch.object(runtime,'_gain_path_fork',original if reuse else lambda *args:None):
        result=DecisionLoop.decide_batch([(copy.deepcopy(actor),request)],False,planner)[0]
    assert digest(actor.record())==before and world==game.start()
    counters=[]
    for metadata in (result['deliberation']['metadata'],captured['forecast'].audit):
        counts=metadata['continuation_portfolio']
        counters.append(counts.pop('reused_steps'))
        counts.pop('recovery_cache');counts['tail_purpose_reflex'].pop('calls')
    payload=dict(result=result,forecast=asdict(captured['forecast']),modeled=captured['modeled'],
        paths={name:[asdict(path) for path in rows] for name,rows in captured['paths'].items()},
        logical_steps=captured['simulated_steps'])
    return payload,counters


class GainPrefixRuntimeTests(unittest.TestCase):
    def compare(self,game,**options):
        reference,old=evaluate(game,reuse=False,**options)
        actual,new=evaluate(game,reuse=True,**options)
        self.assertEqual(actual,reference)
        self.assertGreaterEqual(new[0],old[0])
        self.assertEqual(actual['logical_steps'],sum(len(row['actions']) for rows in actual['modeled'].values() for row in rows))
        return actual,new[0]-old[0]

    def test_preparation_fork_preserves_all_learning_flows_and_prefixes(self):
        for game,horizon in ((PreparationChain(5,payout=14.,turns=128),8),
                (DelayedYield(11,payout=6.,turns=128),12),
                (PreparationChain(3,payout=10.,turns=3),8)):
            with self.subTest(game=game.model_id):
                _,saved=self.compare(game,horizon=horizon)
                self.assertGreater(saved,0)

    def test_different_world_models_seeds_and_shared_proposals_keep_exact_paths(self):
        cases=(('auction','frozen','independent','shared'),
            ('combat','posterior','stratified','root'),
            ('gambling','persistent','independent','root'),
            ('resources','posterior','stratified','shared'))
        for family,world_model,sampling,scope in cases:
            with self.subTest(family=family):
                self.compare(ContinuingGame(family,PROFILES[2],turns=128),horizon=4,
                    world_model=world_model,sampling=sampling,scope=scope)


if __name__=='__main__':unittest.main()
