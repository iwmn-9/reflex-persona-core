"""Exercise the real runtime binding without inventing scientific evidence."""
from pathlib import Path
import json
from prepare_reserved_gain_confirmation import qualified_response_sources,prepare,qualify_response_runtime
from prepare_reserved_purpose_confirmation import read,sha

v=Path(__file__).parent;b=v.parents[2]
source=b/'reflex-persona-shared-runtime'
runtime=source/'evidence/prepared_response_runtime'
development=b/'reflex-persona-preview-runtime/evidence/long_horizon/adverse_gain_tail'
original=read(development/'registration.json')['sources']
commit,sources=qualified_response_sources(source,runtime,original)
refused=[]
def refuse(name,fn):
    try:fn()
    except (ValueError,FileNotFoundError):refused.append(name)
    else:raise AssertionError(name+' was unexpectedly accepted')
refuse('wrong_worker',lambda:qualified_response_sources(b/'reflex-persona-retry-runtime',runtime,original))
wrong=dict(original);wrong[next(iter(wrong))]='0'*64
refuse('wrong_registration',lambda:qualified_response_sources(source,runtime,wrong))
out=v/'must_not_create_reserved_response_worlds'
assert not out.exists()
refuse('incomplete_worlds',lambda:prepare(source,development,v/'missing_loss_archive',v/'missing_review.json',
    runtime,out,candidate='transfer_purpose_gain',runtime_qualifier=qualify_response_runtime))
assert not out.exists()
result=dict(complete=True,adoption=False,runtime_only_qualified=True,source=commit,files=len(sources),
    refused=refused,full_world_gate=False,reserved_worlds_started=False,
    script_sha256=sha((v/'prepare_reserved_gain_confirmation.py').read_bytes()),
    note='Actual qualified source and original registration. Scientific development/loss/persona evidence remains mandatory; no positive world evidence was fabricated.')
(v/'reserved_response_runtime_check.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
