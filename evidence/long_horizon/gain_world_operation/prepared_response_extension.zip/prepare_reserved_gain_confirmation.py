"""Gated operational bridge for G; no independent world starts here.

Reuse unchanged whole-study/all-loss/personality/forty-condition gates. Bind
the qualified prepared-context runtime instead of the older O runtime.
"""
import argparse
import json
from pathlib import Path
import subprocess
import zipfile
from prepare_reserved_purpose_confirmation import read,encoded,sha,prepare

FROZEN='71bf6b2f3e40724a7bb33be14dc3bd3311ee18f8'
RUNTIME_PROOF='68c72dae536c82e88c308a5276a916deeec76f9d1c1e49dc98b24881ced97f8c'
RETRY_RUNTIME='9309ad944d32dcd3c7c3965e698d2d6416fa7657'
RETRY_PROOF='ee1c04c310f1754ddf083c8f00b17295de302587268b7d033493399f0fe88cf1'
RESPONSE_RUNTIME='78a55acb04a5d3e5afe35db4a1d152cec1fd9000'
RESPONSE_PROOF='7d97768d1d64830f8dff456174f21594e1a70711a35e92daa48811b3c3404347'

def qualify_prepared_runtime(source,runtime,development):
    if sha((runtime/'verification.json').read_bytes())!=RUNTIME_PROOF:
        raise ValueError('the reviewed prepared-context runtime proof is required')
    qualified=read(runtime/'verification.json')
    if (not qualified['complete'] or qualified['adoption'] or not qualified['exact_known_h32_forecast']
            or qualified['exact_matrix_cases']!=7 or qualified['tests']['remaining_failures']
            or qualified['tests']['unique_methods_passed']!=53):
        raise ValueError('complete unchanged runtime qualification required')
    for name,checksum in qualified['files'].items():
        if sha((runtime/name).read_bytes())!=checksum:raise ValueError('runtime artifact changed')
    with zipfile.ZipFile(runtime/'verification_data.zip') as packed:
        baseline=json.loads(packed.read('prepared_context_exact_root.json'))
    if baseline['source_sha256']!=qualified['source_sha256']:
        raise ValueError('qualified source map mismatch')
    registration=read(development/'registration.json')
    sources=registration['sources']
    if len(sources)!=600 or sha(encoded(sources))!='9296505d89131f26e8ad06bfefbf6687a2fa79e0aed40952a945ca1f8767b208':
        raise ValueError('unchanged600-file gain-world scientific registration required')
    if any(sha((source/n).read_bytes())!=h for n,h in sources.items()):
        raise ValueError('a development scientific source changed')
    if any(sha((source/n).read_bytes())!=h for n,h in baseline['sources'].items()):
        raise ValueError('worker differs from qualified runtime')
    commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
    if commit!=FROZEN or read(development/'verification.json')['source_ref']!=FROZEN:
        raise ValueError('retain the same frozen gain-world worker and actual study')
    return commit,sources


def qualified_retry_sources(source,runtime,original):
    """Runtime/source qualification only; the caller must gate all world evidence."""
    if sha((runtime/'verification.json').read_bytes())!=RETRY_PROOF:
        raise ValueError('the reviewed unchanged-retry runtime proof is required')
    proof=read(runtime/'verification.json')
    if (not proof['complete'] or proof['adoption'] or proof['development_source_ref']!=FROZEN
            or proof['previous_runtime_qualification']!=RUNTIME_PROOF
            or proof['exact_matrix_cases']!=7 or not proof['exact_experienced_h32_owner']
            or not proof['exact_actual_feedback_and_restore']
            or proof['tests']['passed']!=25 or proof['tests']['failures']):
        raise ValueError('complete exact runtime and affected owner checks required')
    for name,checksum in proof['artifacts'].items():
        if sha((runtime/name).read_bytes())!=checksum:raise ValueError('qualified artifact changed')
    sources=read(runtime/'sources.json')
    if len(sources)!=601 or sha(encoded(sources))!=proof['source_sha256']:
        raise ValueError('complete qualified601-file source required')
    if len(original)!=600 or sha(encoded(original))!='9296505d89131f26e8ad06bfefbf6687a2fa79e0aed40952a945ca1f8767b208':
        raise ValueError('original gain-world scientific source required')
    if (sorted(n for n,h in original.items() if sources.get(n)!=h)!=proof['changed']
            or sorted(set(sources)-set(original))!=proof['added']):
        raise ValueError('only the explicitly qualified runtime changes are permitted')
    if any(sha((source/n).read_bytes())!=h for n,h in sources.items()):
        raise ValueError('worker differs from qualified retry runtime')
    commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
    if commit!=RETRY_RUNTIME:raise ValueError('the fixed qualified retry-runtime commit is required')
    return commit,sources


def qualify_retry_runtime(source,runtime,development):
    if read(development/'verification.json')['source_ref']!=FROZEN:
        raise ValueError('this exact original gain-world development must qualify')
    return qualified_retry_sources(source,runtime,read(development/'registration.json')['sources'])


def qualified_response_sources(source,runtime,original):
    """Qualify the reviewed runtime; full scientific gates remain outside."""
    if sha((runtime/'verification.json').read_bytes())!=RESPONSE_PROOF:
        raise ValueError('the reviewed response-preparation proof is required')
    proof=read(runtime/'verification.json')
    if (not proof['complete'] or proof['adoption'] or proof['development_source_ref']!=FROZEN
            or proof['previous_runtime_qualification']!=RETRY_PROOF
            or proof['exact_matrix_cases']!=7 or not proof['exact_experienced_h32_owner']
            or not proof['exact_actual_feedback_and_restore']
            or proof['affected_tests']!=64 or proof['additional_unique_methods']!=9):
        raise ValueError('complete exact response runtime qualification required')
    for name,checksum in proof['artifacts'].items():
        if sha((runtime/name).read_bytes())!=checksum:raise ValueError('qualified artifact changed')
    sources=read(runtime/'sources.json')
    if len(sources)!=602 or sha(encoded(sources))!=proof['source_sha256']:
        raise ValueError('complete qualified602-file source required')
    if len(original)!=600 or sha(encoded(original))!='9296505d89131f26e8ad06bfefbf6687a2fa79e0aed40952a945ca1f8767b208':
        raise ValueError('original gain-world scientific source required')
    if (sorted(n for n,h in original.items() if sources.get(n)!=h)!=[
            'reflex/_continuation_portfolio.py','reflex/closed_loop.py']
            or sorted(set(sources)-set(original))!=[
                'tests/test_prepared_responses.py','tests/test_unchanged_retry_runtime.py']):
        raise ValueError('only the two qualified equivalent runtime changes are permitted')
    if any(sha((source/n).read_bytes())!=h for n,h in sources.items()):
        raise ValueError('worker differs from qualified response runtime')
    commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
    if commit!=RESPONSE_RUNTIME:raise ValueError('the fixed qualified response-runtime commit is required')
    return commit,sources


def qualify_response_runtime(source,runtime,development):
    if read(development/'verification.json')['source_ref']!=FROZEN:
        raise ValueError('this exact original gain-world development must qualify')
    return qualified_response_sources(source,runtime,read(development/'registration.json')['sources'])


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('source','development','losses','review','runtime','output'):
        parser.add_argument('--'+name,required=True)
    parser.add_argument('--runtime-kind',choices=('prepared','unchanged-retry','prepared-responses'),default='prepared')
    args=vars(parser.parse_args());kind=args.pop('runtime_kind')
    qualifiers={'prepared':qualify_prepared_runtime,'unchanged-retry':qualify_retry_runtime,
                'prepared-responses':qualify_response_runtime}
    prepare(**args,candidate='transfer_purpose_gain',runtime_qualifier=qualifiers[kind])
