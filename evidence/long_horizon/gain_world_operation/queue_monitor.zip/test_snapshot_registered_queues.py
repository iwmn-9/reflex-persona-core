import json
import tempfile
from pathlib import Path
import unittest
import snapshot_registered_queues as subject


class MonitorTests(unittest.TestCase):
    def setUp(self):
        self.job = dict(spec=dict(id='example', turns=128), arm='stable', registration={'source': 'bound'})
        self.final = dict(saved_turn=128, terminal_notice=True)
        self.status = dict(case='example', arm='stable', registration={'source': 'bound'},
                           state='complete', complete=True, actual_steps=128)

    def no_read(self):
        raise AssertionError('Live status must not be opened')

    def test_saved_complete_is_not_worker_complete(self):
        for before, after in (([{'pid': 1}], []), ([], [{'pid': 2}]), ([{'pid': 1}], [{'pid': 1}])):
            result = subject.classify(self.job, self.final, before, after, self.no_read)
            self.assertFalse(result['audited_complete'])

    def test_partial_exit_is_not_complete_and_no_status_read(self):
        result = subject.classify(self.job, dict(saved_turn=118, terminal_notice=False), [], [], self.no_read)
        self.assertEqual(result['state'], 'not_running_saved_partial')

    def test_inactive_final_requires_matching_audited_status(self):
        load = lambda: (self.status, 'hash')
        self.assertTrue(subject.classify(self.job, self.final, [], [], load)['audited_complete'])
        for change in (dict(registration={}), dict(state='failed'), dict(actual_steps=127), dict(complete=False)):
            bad = dict(self.status, **change)
            self.assertFalse(subject.classify(self.job, self.final, [], [], lambda: (bad, 'hash'))['audited_complete'])

    def test_missing_final_record_is_review_not_success(self):
        def missing():
            raise FileNotFoundError('status')
        self.assertEqual(subject.classify(self.job, self.final, [], [], missing)['state'], 'inactive_needs_review')

    def test_worker_matching_includes_retired_parent(self):
        with tempfile.TemporaryDirectory() as root:
            manifest = str(Path(root)/'directory with spaces'/'manifest.json')
            rows = [dict(ProcessId=7, ParentProcessId=99, CreationDate='old',
                         CommandLine=f'python.exe driver.py --manifest "{manifest}" --job 2'),
                    dict(ProcessId=8, ParentProcessId=100, CreationDate='new',
                         CommandLine=f'python.exe driver.py --manifest "{manifest}" --workers 8')]
            workers = subject.match_workers(rows, manifest)
            self.assertEqual(list(workers), [2])
            self.assertEqual(workers[2][0]['parent'], 99)

    def test_only_complete_matching_log_lines(self):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root)/'log'
            rows = [dict(id='example', arm='stable', turn=127, complete=False),
                    dict(id='foreign', arm='stable', turn=128, complete=True)]
            path.write_bytes(('\n'.join(json.dumps(row) for row in rows)+'\n'+json.dumps(
                dict(id='example', arm='stable', turn=128, complete=True))).encode())
            self.assertEqual(subject.saved_notice(path, self.job['spec'], 'stable')['saved_turn'], 127)
            with path.open('ab') as stream:
                stream.write(b'\n')
            self.assertTrue(subject.saved_notice(path, self.job['spec'], 'stable')['terminal_notice'])


if __name__ == '__main__':
    unittest.main()
