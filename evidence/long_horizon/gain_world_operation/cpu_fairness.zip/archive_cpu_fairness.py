"""Archive one operational repair without changing scientific registrations."""
import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

here = Path(__file__).resolve().parent
root = here.parents[2] / "reflex-persona-core"
out = root / "evidence/long_horizon/gain_world_operation"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

before = read(here / "world_cpu_fairness_measurement.json")
after = read(here / "world_cpu_fairness_measurement_after_retained_fix.json")
assert len(after["samples"]) == 21 and after["all21_advanced"]
assert all(row["cpu_delta"] > 0 and row["priority"] == "Normal" for row in after["samples"])
assert {row["pid"] for row in before["rows"] if row["cpu_increase"] == 0} == {14912, 7452, 2704, 24316}
names = ["world_cpu_fairness_measurement.json", "world_cpu_fairness_measurement_after_retained_fix.json",
         "world_cpu_fairness/launch.json", "world_cpu_fairness/retained_gain_workers.json",
         "restore_world_cpu_fairness.ps1", Path(__file__).name]
archive = out / "cpu_fairness.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for name in names:
        z.write(here / name, name)
proof = dict(utc=after["utc"], operational_repair_verified=True, scientific_cohort_complete=False,
    all_21_processes_advanced=True, observation_seconds=after["elapsed_seconds"],
    before_zero_cpu_workers=[14912, 7452, 2704, 24316],
    worker_restart=False, source_or_seed_change=False, affinity_change=False,
    limitation="CPU progress is not proof of cohort completion or a total runtime speedup.",
    retained_workers="Their original coordinator was retired by a verified handoff; OS parent identity did not change.",
    archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
(out / "cpu_fairness.json").write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8")
resume_path = root / "results/long_horizon_resume_status.json"
resume = read(resume_path)
resume["updated"] = datetime.now(timezone.utc).isoformat()
resume["operational"]["observation"] = "Use append-only worker/test logs and OS CPU/creation time only. Do not read any live worker or queue JSON/state file; Windows readers can obstruct atomic replacement. Read final state after its writer exits."
resume["operational"]["cpu_fairness"] = dict(helper_pid=21496, root=str(here / "world_cpu_fairness"),
    proof=str(out / "cpu_fairness.json"), priority="Normal for all Q/G/N scientific workers and regression",
    retained_gain_workers=[14912,7452,2704,24316],
    duplicate_launch=False, note="Finite helper covers current Q/G coordinator children. Retained G workers with original parent20924 were verified and raised once. No source/RNG/checkpoint changes.")
resume["active_worlds"]["relative"]["priority"]["scope"] = "At most4 original new-candidate workers Normal. Q/G also Normal after measured scheduling starvation; all scientific registrations unchanged."
resume_path.write_text(json.dumps(resume, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps(proof, indent=2))
