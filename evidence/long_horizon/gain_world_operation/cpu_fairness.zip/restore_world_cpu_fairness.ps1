$ErrorActionPreference='Stop'
$out=Join-Path $PSScriptRoot 'world_cpu_fairness'
if(Test-Path -LiteralPath $out){throw 'Existing fairness helper; inspect rather than duplicate'}
$registrations=@()
foreach($entry in @(@{pid=2372;label='purpose';fragment='purpose_development_20261031'},@{pid=9944;label='origin_gain';fragment='gain_development_20261031'})){
    $parent=Get-CimInstance Win32_Process -Filter "ProcessId = $($entry.pid)"
    if(-not $parent -or $parent.CommandLine -notlike "*$($entry.fragment)*driver.py*"){throw 'Original coordinator missing or different'}
    $entry.created=$parent.CreationDate;$registrations+=$entry
}
New-Item -ItemType Directory -Path $out | Out-Null
$seen=@{}
$receipt=@{pid=$PID;started=[DateTime]::UtcNow.ToString('o');parents=$registrations;state='running';recurring=$false;source_changed=$false;affinity_changed=$false;workers=$seen}
$receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $out 'launch.json') -Encoding utf8
try {
    while($true){
        $active=0
        foreach($entry in $registrations){
            $current=Get-CimInstance Win32_Process -Filter "ProcessId = $($entry.pid)"
            if(-not $current -or $current.CreationDate -ne $entry.created){continue}
            $active++
            $children=@(Get-CimInstance Win32_Process -Filter "ParentProcessId = $($entry.pid)" | Where-Object {$_.Name -eq 'python.exe' -and $_.CommandLine -like '*--job *'})
            if($children.Count -gt 8){throw 'Unexpected scientific worker count'}
            foreach($child in $children){
                if($child.CommandLine -notlike "*$($entry.fragment)*"){throw 'Unexpected child scientific source'}
                $key=[string]$child.ProcessId;$process=Get-Process -Id $child.ProcessId
                if(-not $seen.ContainsKey($key)){
                    $seen[$key]=@{created=$child.CreationDate;original=[string]$process.PriorityClass;cpu_before=$process.CPU;study=$entry.label}
                }
                if($seen[$key].created -ne $child.CreationDate){throw 'Worker PID was reused'}
                if($process.PriorityClass -ne 'Normal'){
                    $process.PriorityClass='Normal'
                    @{pid=$child.ProcessId;created=$child.CreationDate;cpu_before=$seen[$key].cpu_before;at=[DateTime]::UtcNow.ToString('o');priority='Normal';study=$entry.label} | ConvertTo-Json -Compress | Write-Output
                }
            }
        }
        if($active -eq 0){break}
        Start-Sleep -Seconds 20
    }
    $receipt.state='complete'
}catch{$receipt.state='failed';$receipt.error=$_.Exception.Message}
finally{
    foreach($key in $seen.Keys){
        $current=Get-CimInstance Win32_Process -Filter "ProcessId = $key"
        if($current -and $current.CreationDate -eq $seen[$key].created){(Get-Process -Id ([int]$key)).PriorityClass=$seen[$key].original}
    }
    $receipt.finished=[DateTime]::UtcNow.ToString('o')
    $receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $out 'complete.json') -Encoding utf8
}
