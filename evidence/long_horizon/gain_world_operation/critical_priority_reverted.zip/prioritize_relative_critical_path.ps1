$ErrorActionPreference='Stop'
$out=Join-Path $PSScriptRoot 'relative_critical_priority'
if(Test-Path -LiteralPath $out){throw 'Existing finite helper; inspect rather than duplicate'}
if((Get-CimInstance Win32_ComputerSystem).NumberOfLogicalProcessors -lt 8){throw 'Five priority workers require the verified eight-CPU host'}
$parent=Get-CimInstance Win32_Process -Filter 'ProcessId=27860'
$regression=Get-CimInstance Win32_Process -Filter 'ProcessId=9856'
if(-not $parent -or $parent.CreationDate.ToString('yyyy-MM-ddTHH:mm:ss.fff') -ne '2026-11-01T03:00:03.728' -or $parent.CommandLine -notlike '*relative_development_20261101*driver.py*'){throw 'Registered parent identity mismatch'}
if(-not $regression -or $regression.CreationDate.ToString('yyyy-MM-ddTHH:mm:ss.fff') -ne '2026-11-01T03:03:51.135' -or $regression.CommandLine -notlike '*run_relative_regression.py*'){throw 'Registered regression identity mismatch'}
New-Item -ItemType Directory -Path $out | Out-Null
$seen=@{}
$receipt=@{pid=$PID;started=[DateTime]::UtcNow.ToString('o');parent=$parent.ProcessId;parent_created=$parent.CreationDate;regression=$regression.ProcessId;regression_created=$regression.CreationDate;maximum_priority_workers=5;logical_cpus=8;state='running';recurring=$false;source_changed=$false;science_restarted=$false;affinity_changed=$false;workers=$seen}
$receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $out 'launch.json') -Encoding utf8
try {
    while($true){
        $targets=@();$active=0
        $current=Get-CimInstance Win32_Process -Filter 'ProcessId=27860'
        if($current -and $current.CreationDate -eq $parent.CreationDate){
            $active++
            $children=@(Get-CimInstance Win32_Process -Filter 'ParentProcessId=27860' | Where-Object {$_.Name -eq 'python.exe' -and $_.CommandLine -like '*--job *'})
            if($children.Count -gt 4){throw 'More than four registered candidate workers'}
            foreach($child in $children){if($child.CommandLine -notlike '*relative_development_20261101*'){throw 'Unexpected candidate child'}}
            $targets+=$children
        }
        $current=Get-CimInstance Win32_Process -Filter 'ProcessId=9856'
        if($current -and $current.CreationDate -eq $regression.CreationDate){$active++;$targets+=$current}
        if($active -eq 0){break}
        if($targets.Count -gt 5){throw 'Bounded priority allocation exceeded'}
        foreach($target in $targets){
            $key=[string]$target.ProcessId
            $process=Get-Process -Id $target.ProcessId -ErrorAction SilentlyContinue
            if(-not $process){continue}
            if(-not $seen.ContainsKey($key)){$seen[$key]=@{created=$target.CreationDate;original=[string]$process.PriorityClass}}
            if($seen[$key].created -ne $target.CreationDate){throw 'Process identity was reused'}
            if($process.PriorityClass -ne 'AboveNormal'){
                $process.PriorityClass='AboveNormal'
                @{pid=$target.ProcessId;created=$target.CreationDate;at=[DateTime]::UtcNow.ToString('o');priority='AboveNormal';cpu_seconds=$process.CPU}|ConvertTo-Json -Compress|Write-Output
            }
        }
        Start-Sleep -Seconds 20
    }
    $receipt.state='complete'
}catch{$receipt.state='failed';$receipt.error=$_.Exception.Message}
finally{
    foreach($key in $seen.Keys){
        $current=Get-CimInstance Win32_Process -Filter "ProcessId=$key"
        if($current -and $current.CreationDate -eq $seen[$key].created){(Get-Process -Id ([int]$key)).PriorityClass=$seen[$key].original}
    }
    $receipt.finished=[DateTime]::UtcNow.ToString('o')
    $receipt|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $out 'complete.json') -Encoding utf8
}
