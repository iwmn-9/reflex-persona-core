$ErrorActionPreference='Stop'
$study='C:/Users/iwakura/Documents/Project(Gemini)/Colabo/github-preview/reflex-persona-relative-worlds/results/relative_development_20261101'
$launch=Get-Content -LiteralPath (Join-Path $study 'launch.json') -Raw | ConvertFrom-Json
$original=Get-CimInstance Win32_Process -Filter "ProcessId = $($launch.pid)"
if (-not $original -or $original.CommandLine -notlike '*relative_development_20261101*driver.py*') { throw 'Registered coordinator required' }
$workers=@{}
$receipt=@{parent=$launch.pid;parent_created=$original.CreationDate;helper_pid=$PID;started=[DateTime]::UtcNow.ToString('o');state='running';live_status_reads=0;workers=$workers}
$out=Join-Path $PSScriptRoot 'relative_world_priority_resumed'
if (Test-Path -LiteralPath $out) { throw 'Existing helper receipt' }
New-Item -ItemType Directory -Path $out | Out-Null
$receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $out 'launch.json') -Encoding utf8
(Get-Process -Id $PID).PriorityClass='BelowNormal'
try {
    while ($true) {
        $current=Get-CimInstance Win32_Process -Filter "ProcessId = $($launch.pid)"
        if (-not $current -or $current.CreationDate -ne $original.CreationDate) { break }
        $children=@(Get-CimInstance Win32_Process -Filter "ParentProcessId = $($launch.pid)" | Where-Object { $_.Name -eq 'python.exe' -and $_.CommandLine -like '*--job *' })
        if ($children.Count -gt 4) { throw 'Unexpected worker count' }
        foreach($child in $children) {
            $key=[string]$child.ProcessId
            $process=Get-Process -Id $child.ProcessId
            if (-not $workers.ContainsKey($key)) { $workers[$key]=@{created=$child.CreationDate;original=[string]$process.PriorityClass} }
            if ($workers[$key].created -ne $child.CreationDate) { throw 'Worker identity changed' }
            if ($process.PriorityClass -ne 'Normal') {
                $process.PriorityClass='Normal'
                @{pid=$child.ProcessId;at=[DateTime]::UtcNow.ToString('o');priority='Normal'} | ConvertTo-Json -Compress | Write-Output
            }
        }
        Start-Sleep -Seconds 20
    }
    $receipt.state='complete'
} catch { $receipt.state='failed';$receipt.error=$_.Exception.Message }
finally {
    foreach($key in $workers.Keys) {
        $live=Get-CimInstance Win32_Process -Filter "ProcessId = $key"
        if ($live -and $live.CreationDate -eq $workers[$key].created) { (Get-Process -Id ([int]$key)).PriorityClass=$workers[$key].original }
    }
    $receipt.finished=[DateTime]::UtcNow.ToString('o')
    $receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $out 'complete.json') -Encoding utf8
}

