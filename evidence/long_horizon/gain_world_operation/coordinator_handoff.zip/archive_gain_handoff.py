from pathlib import Path
import hashlib,json,zipfile
def sha(raw):return hashlib.sha256(raw).hexdigest()
def enc(value):return json.dumps(value,sort_keys=True,separators=(',',':')).encode()
local=Path(__file__).resolve().parent;base=local.parents[2]
handoff=local/'gain_coordinator_handoff_20261101'
receipt=json.loads((handoff/'receipt.json').read_bytes())
assert receipt['state']=='complete'
before=json.loads((handoff/'state_before.json').read_bytes());after=json.loads((handoff/'state_after.json').read_bytes())
assert before['manifest_sha256']==after['manifest_sha256']==receipt['manifest_sha256']
assert before['pid']==20924 and after['pid']==receipt['new_coordinator']
assert set(before['active'].values())==set(receipt['retained_worker_pids'])
assert set(before['active'].values()) < set(after['active'].values())
assert len(after['active'])==8 and not after['failures']
old=json.loads((local/'gain_world_finish/manifest.json').read_bytes())
new=json.loads((local/'gain_world_finish_eight_workers/manifest.json').read_bytes())
assert old.pop('parent_pid')==20924 and new.pop('parent_pid')==after['pid'] and old==new
queue=base/'reflex-persona-preview-runtime/results/gain_development_20261031/manifest.json'
assert sha(queue.read_bytes())==receipt['manifest_sha256']
for name,value in old['files'].items():assert sha(Path(name).read_bytes())==value
output=base/'reflex-persona-core/evidence/long_horizon/gain_world_operation'
archive=output/'coordinator_handoff.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as packed:
    for name in ('receipt.json','state_before.json','state_after.json','finisher_before.json'):
        packed.write(handoff/name,name)
    packed.write(local/'handoff_gain_coordinator.ps1','handoff_gain_coordinator.ps1')
    packed.write(local/'gain_world_finish/manifest.json','old_finisher_manifest.json')
    packed.write(local/'gain_world_finish_eight_workers/manifest.json','new_finisher_manifest.json')
    packed.write(Path(__file__),Path(__file__).name)
proof=dict(complete=True,adoption=False,scientific_cohort_complete=False,
    scientific_manifest_unchanged=True,all_four_original_worker_processes_retained=True,
    duplicate_workers=False,worker_limit_before=4,worker_limit_after=8,
    scientific_code_and_registration_unchanged=True,finisher_stages_unchanged=True,
    archived_sha256=sha(archive.read_bytes()),
    limit='An operational handoff, not a completed world or measured total-time speedup. Both old controlling PIDs are retired; workers were not terminated or replayed.')
(output/'coordinator_handoff.json').write_bytes(enc(proof))
print(json.dumps(proof),flush=True)
