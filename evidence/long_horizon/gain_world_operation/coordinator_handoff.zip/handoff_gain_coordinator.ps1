$ErrorActionPreference='Stop'
$taskBase='C:/Users/iwakura/Documents/Project(Gemini)/Colabo/github-preview'
$taskLocal=Join-Path $taskBase 'reflex-persona-consistent-reading/results/local_linux_recovery_20261029'
$taskQueue=Join-Path $taskBase 'reflex-persona-preview-runtime/results/gain_development_20261031'
$taskPython='C:/Users/iwakura/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$taskRecordRoot=Join-Path $taskLocal 'gain_coordinator_handoff_20261101'
$taskOldFinish=Join-Path $taskLocal 'gain_world_finish'
$taskNewFinish=Join-Path $taskLocal 'gain_world_finish_eight_workers'
$taskManifestPath=Join-Path $taskQueue 'manifest.json'
$taskDriver=Join-Path $taskQueue 'driver.py'
$taskFinishScript=Join-Path $taskLocal 'finish_purpose_study_v2.py'
if((Test-Path -LiteralPath $taskRecordRoot) -or (Test-Path -LiteralPath $taskNewFinish)){throw 'Inspect existing handoff; never repeat blindly'}
$taskQueueHash=(Get-FileHash -LiteralPath $taskManifestPath -Algorithm SHA256).Hash.ToLowerInvariant()
if($taskQueueHash -ne '49c252d35358f55de32c0bb269323e757a1a2133e43002051a717c3a1334a496'){throw 'Different scientific manifest'}
$taskOldStatus=Get-Content -LiteralPath (Join-Path $taskOldFinish 'status.json') -Raw | ConvertFrom-Json
if($taskOldStatus.state -ne 'waiting_for_original_coordinator' -or $taskOldStatus.pid -ne 27136 -or $taskOldStatus.steps.Count -ne 0 -or $null -ne $taskOldStatus.child_pid){throw 'Finisher has advanced; do not interrupt it'}
$taskState=Get-Content -LiteralPath (Join-Path $taskQueue 'state.json') -Raw | ConvertFrom-Json
if($taskState.pid -ne 20924 -or $taskState.complete -or $taskState.failures.PSObject.Properties.Count -gt 0){throw 'Different/failed/completed coordinator state'}
$taskParent=Get-CimInstance Win32_Process -Filter 'ProcessId=20924'
$taskFinisher=Get-CimInstance Win32_Process -Filter 'ProcessId=27136'
if($taskParent.Name -ne 'python.exe' -or $taskParent.CommandLine -notlike '*gain_development_20261031*--workers 4'){throw 'Unexpected coordinator identity'}
if($taskFinisher.Name -ne 'python.exe' -or $taskFinisher.CommandLine -notlike '*finish_purpose_study_v2.py*gain_world_finish*'){throw 'Unexpected finisher identity'}
$taskActive=@($taskState.active.PSObject.Properties | ForEach-Object { [int]$_.Value })
if($taskActive.Count -ne 4){throw 'Expected four original workers; review changed queue before handoff'}
$taskWorkers=@($taskActive | ForEach-Object { Get-CimInstance Win32_Process -Filter ('ProcessId='+$_) })
if(@($taskWorkers | Where-Object { $_.ParentProcessId -ne 20924 -or $_.Name -ne 'python.exe' -or $_.CommandLine -notlike '*gain_development_20261031*--job*' }).Count){throw 'Unexpected worker identity'}
$taskOldManifest=Get-Content -LiteralPath (Join-Path $taskOldFinish 'manifest.json') -Raw | ConvertFrom-Json
foreach($taskFile in $taskOldManifest.files.PSObject.Properties){
 if((Get-FileHash -LiteralPath $taskFile.Name -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskFile.Value){throw ('Bound file changed: '+$taskFile.Name)}
}
New-Item -ItemType Directory -Path $taskRecordRoot | Out-Null
New-Item -ItemType Directory -Path $taskNewFinish | Out-Null
Copy-Item -LiteralPath (Join-Path $taskQueue 'state.json') -Destination (Join-Path $taskRecordRoot 'state_before.json')
Copy-Item -LiteralPath (Join-Path $taskOldFinish 'status.json') -Destination (Join-Path $taskRecordRoot 'finisher_before.json')
$taskReceipt=[ordered]@{state='prepared';created=[DateTime]::UtcNow.ToString('o');manifest_sha256=$taskQueueHash;old_coordinator=20924;old_finisher=27136;retained_workers=@($taskWorkers | Select-Object ProcessId,ParentProcessId,CommandLine,CreationDate);source_unchanged=$true;histories_unchanged=$true;worker_limit_before=4;worker_limit_after=8}
$taskReceipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $taskRecordRoot 'receipt.json') -Encoding utf8
# Stop only the waiting control processes. The calculation workers stay alive.
Stop-Process -Id 27136
Wait-Process -Id 27136 -Timeout 10 -ErrorAction SilentlyContinue
Stop-Process -Id 20924
Wait-Process -Id 20924 -Timeout 10 -ErrorAction SilentlyContinue
foreach($taskWorker in $taskWorkers){if((Get-CimInstance Win32_Process -Filter ('ProcessId='+$taskWorker.ProcessId)).CreationDate -ne $taskWorker.CreationDate){throw 'Original worker disappeared before restart'}}
$env:NPY_DISABLE_CPU_FEATURES='AVX512F,AVX512CD,AVX512_SKX,AVX512_CLX,AVX512_CNL,AVX512_ICL'
$env:OPENBLAS_CORETYPE='Haswell'
$env:OPENBLAS_NUM_THREADS='1'
$env:OMP_NUM_THREADS='1'
$env:MKL_NUM_THREADS='1'
$taskArguments='-u "'+$taskDriver+'" --manifest "'+$taskManifestPath+'" --workers 8'
$taskNewParent=Start-Process -FilePath $taskPython -ArgumentList $taskArguments -WorkingDirectory (Join-Path $taskBase 'reflex-persona-preview-runtime') -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $taskRecordRoot 'coordinator.stdout.log') -RedirectStandardError (Join-Path $taskRecordRoot 'coordinator.stderr.log')
$taskNewParent.PriorityClass='BelowNormal'
$taskReceipt.new_coordinator=$taskNewParent.Id
$taskReceipt.state='coordinator_started'
$taskReceipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $taskRecordRoot 'receipt.json') -Encoding utf8
$taskDeadline=[DateTime]::UtcNow.AddSeconds(45)
do {
 Start-Sleep -Milliseconds 300
 $taskNewParent.Refresh();if($taskNewParent.HasExited){throw 'Replacement coordinator failed; original workers retained'}
 $taskAfter=Get-Content -LiteralPath (Join-Path $taskQueue 'state.json') -Raw | ConvertFrom-Json
} until($taskAfter.pid -eq $taskNewParent.Id -or [DateTime]::UtcNow -ge $taskDeadline)
if($taskAfter.pid -ne $taskNewParent.Id -or $taskAfter.manifest_sha256 -ne $taskQueueHash -or $taskAfter.failures.PSObject.Properties.Count -gt 0){throw 'New coordinator did not establish the unchanged queue'}
$taskAfterActive=@($taskAfter.active.PSObject.Properties | ForEach-Object { [int]$_.Value })
if($taskAfterActive.Count -ne 8 -or @($taskActive | Where-Object { $_ -notin $taskAfterActive }).Count){throw 'Original workers not adopted exactly once'}
foreach($taskWorker in $taskWorkers){if((Get-CimInstance Win32_Process -Filter ('ProcessId='+$taskWorker.ProcessId)).CreationDate -ne $taskWorker.CreationDate){throw 'Worker identity changed'}}
Copy-Item -LiteralPath (Join-Path $taskQueue 'state.json') -Destination (Join-Path $taskRecordRoot 'state_after.json')
$taskOldManifest.parent_pid=$taskNewParent.Id
$taskOldManifest | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath (Join-Path $taskNewFinish 'manifest.json') -Encoding utf8
$taskArguments='-u "'+$taskFinishScript+'" --root "'+$taskNewFinish+'"'
$taskNewFinisher=Start-Process -FilePath $taskPython -ArgumentList $taskArguments -WorkingDirectory (Join-Path $taskBase 'reflex-persona-core') -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $taskNewFinish 'execution.stdout.log') -RedirectStandardError (Join-Path $taskNewFinish 'execution.stderr.log')
$taskNewFinisher.PriorityClass='BelowNormal'
$taskReceipt.new_finisher=$taskNewFinisher.Id
$taskReceipt.state='finisher_started'
$taskReceipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $taskRecordRoot 'receipt.json') -Encoding utf8
Start-Sleep -Seconds 1
$taskNewFinisher.Refresh();if($taskNewFinisher.HasExited){throw 'Replacement finisher failed; inspect while the scientific queue continues'}
$taskNewStatus=Get-Content -LiteralPath (Join-Path $taskNewFinish 'status.json') -Raw | ConvertFrom-Json
if($taskNewStatus.pid -ne $taskNewFinisher.Id -or $taskNewStatus.state -ne 'waiting_for_original_coordinator'){throw 'Unexpected new finisher state'}
$taskReceipt.state='complete';$taskReceipt.completed=[DateTime]::UtcNow.ToString('o');$taskReceipt.retained_worker_pids=$taskActive;$taskReceipt.active_worker_pids=$taskAfterActive
$taskReceipt.finisher_manifest_sha256=(Get-FileHash -LiteralPath (Join-Path $taskNewFinish 'manifest.json') -Algorithm SHA256).Hash.ToLowerInvariant()
$taskReceipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $taskRecordRoot 'receipt.json') -Encoding utf8
[pscustomobject]@{state=$taskReceipt.state;coordinator=$taskNewParent.Id;finisher=$taskNewFinisher.Id;original_workers_retained=$taskActive;workers=$taskAfterActive.Count} | ConvertTo-Json
