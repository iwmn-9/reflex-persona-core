"""Gated operational bridge for G; no independent world starts here.

Reuse unchanged whole-study/all-loss/personality/forty-condition gates. Bind
the qualified prepared-context runtime instead of the older O runtime.
"""
import argparse
import json
from pathlib import Path
import subprocess
import zipfile
from prepare_reserved_purpose_confirmation import read,encoded,sha,prepare

FROZEN='71bf6b2f3e40724a7bb33be14dc3bd3311ee18f8'
RUNTIME_PROOF='68c72dae536c82e88c308a5276a916deeec76f9d1c1e49dc98b24881ced97f8c'

def qualify_prepared_runtime(source,runtime,development):
    if sha((runtime/'verification.json').read_bytes())!=RUNTIME_PROOF:
        raise ValueError('the reviewed prepared-context runtime proof is required')
    qualified=read(runtime/'verification.json')
    if (not qualified['complete'] or qualified['adoption'] or not qualified['exact_known_h32_forecast']
            or qualified['exact_matrix_cases']!=7 or qualified['tests']['remaining_failures']
            or qualified['tests']['unique_methods_passed']!=53):
        raise ValueError('complete unchanged runtime qualification required')
    for name,checksum in qualified['files'].items():
        if sha((runtime/name).read_bytes())!=checksum:raise ValueError('runtime artifact changed')
    with zipfile.ZipFile(runtime/'verification_data.zip') as packed:
        baseline=json.loads(packed.read('prepared_context_exact_root.json'))
    if baseline['source_sha256']!=qualified['source_sha256']:
        raise ValueError('qualified source map mismatch')
    registration=read(development/'registration.json')
    sources=registration['sources']
    if len(sources)!=600 or sha(encoded(sources))!='9296505d89131f26e8ad06bfefbf6687a2fa79e0aed40952a945ca1f8767b208':
        raise ValueError('unchanged600-file gain-world scientific registration required')
    if any(sha((source/n).read_bytes())!=h for n,h in sources.items()):
        raise ValueError('a development scientific source changed')
    if any(sha((source/n).read_bytes())!=h for n,h in baseline['sources'].items()):
        raise ValueError('worker differs from qualified runtime')
    commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
    if commit!=FROZEN or read(development/'verification.json')['source_ref']!=FROZEN:
        raise ValueError('retain the same frozen gain-world worker and actual study')
    return commit,sources

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('source','development','losses','review','runtime','output'):
        parser.add_argument('--'+name,required=True)
    prepare(**vars(parser.parse_args()),candidate='transfer_purpose_gain',
            runtime_qualifier=qualify_prepared_runtime)
