"""Audit one finished original pair while other registered worlds continue.

This never registers a shorter study, changes a gate, reads a running worker's
checkpoint, or declares cohort success. All ten pairs still require final audit.
"""
import argparse
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import sys

def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(path):return json.loads(path.read_bytes())
def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--queue',required=True);p.add_argument('--case',required=True);p.add_argument('--output',required=True)
    p.add_argument('--candidate',choices=('transfer_purpose','transfer_purpose_gain'),default='transfer_purpose')
    a=p.parse_args();queue=Path(a.queue).resolve();output=Path(a.output).resolve()
    if output.exists():raise FileExistsError('completed pair receipts are immutable')
    manifest=read(queue/'manifest.json');state=read(queue/'state.json')
    assert state['manifest_sha256']==sha((queue/'manifest.json').read_bytes())
    jobs=[(i,j) for i,j in enumerate(manifest['jobs']) if j['spec']['id']==a.case]
    assert len(jobs)==2 and {j['arm'] for i,j in jobs}=={'stable',a.candidate}
    active_ids={int(i) for i in state['active']}
    for index,job in jobs:
        assert index not in active_ids,'do not open a running checkpoint'
        progress=state['progress'][index]
        assert progress['complete'] and progress['state']=='complete'
    worker=Path(jobs[0][1]['source']);plan_path=Path(jobs[0][1]['plan']);plan=read(plan_path)
    assert plan['candidate_arm']==a.candidate and plan['reference_arm']=='stable'
    assert all(j['source']==str(worker) and j['plan']==str(plan_path) for i,j in jobs)
    os.environ.update(jobs[0][1]['arithmetic'])
    os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    sys.path.insert(0,str(worker))
    from tools.run_adverse_recovery import verify_registration
    from tools.adverse_segment import audit
    from tools.analyze_adverse_results import account_pair
    registration=verify_registration(plan_path);spec=jobs[0][1]['spec'];results={};receipts={};files={}
    for index,job in jobs:
        assert job['registration']==registration and job['spec']==spec
        directory=Path(job['output']);checks=audit(directory,spec,job['arm'],registration)
        assert checks['complete'] and checks['actual_steps']==spec['turns']==128
        result=read(directory/'result.json');results[job['arm']]=result
        receipts[job['arm']]=checks
        for name in ('checkpoint.json','result.json','status.json'):
            path=directory/name;files[str(path)]=sha(path.read_bytes())
    reference,candidate=results['stable'],results[a.candidate]
    assert reference['runtime']==candidate['runtime']
    assert [r['response'] for r in reference['trace']]==[r['response'] for r in candidate['trace']]
    review=account_pair(spec,reference,candidate)
    negative=[k for k in ('score','conditional','reference_choice') if review['differences'].get(k,0)<-1e-12]
    # Root selection/probing is gated on the complete cohort by the published
    # protocol. Early accounting never bypasses that gate.
    protocol_path=plan_path.parent/'loss_diagnosis_protocol.json'
    protocols={'transfer_purpose':'bf95a1d3a3015904b43c2794c13a822cca636fcc1b8eaf77986f349f2caf2f18',
        'transfer_purpose_gain':'042885e08b43a0a1eaf166b3c7acb3ac0643418edd7e388a9a713ddd9b2957df'}
    assert sha(protocol_path.read_bytes())==protocols[a.candidate]
    assert read(protocol_path)['source_registration']==registration
    assert registration==verify_registration(plan_path)
    assert all(sha(Path(n).read_bytes())==h for n,h in files.items())
    output.mkdir(parents=True)
    (output/'analysis.json').write_bytes(encoded(review))
    receipt=dict(version='completed-pair-in-original-study-1',created=datetime.now(timezone.utc).isoformat(),
        pair_complete=True,cohort_complete=False,cohort_gate_evaluated=False,adoption=False,
        reference_arm='stable',candidate_arm=a.candidate,
        case=a.case,spec=spec,registration=registration,source_ref=manifest['source_ref'],receipts=receipts,
        source_files=files,analysis_sha256=sha((output/'analysis.json').read_bytes()),
        protocol_sha256=sha(protocol_path.read_bytes()),negative_axes=negative,
        diagnostic_roots='not selected: complete-cohort archive and protocol prerequisites required',
        limits='One complete 256-step pair from the original ten-pair registration. No cohort/family passage; all ten, all losses, persona review and reserved forty remain required.')
    (output/'verification.json').write_bytes(encoded(receipt))
    print(json.dumps({k:receipt[k] for k in ('case','pair_complete','cohort_gate_evaluated','adoption','negative_axes','diagnostic_roots')}))
