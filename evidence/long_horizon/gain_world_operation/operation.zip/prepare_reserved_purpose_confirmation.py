"""Prepare, never launch, the already reserved forty conditions after review.

This is an operational bridge to the qualified exact runtime. It cannot pass a
partial/failed development cohort, omit an adverse case or adopt the candidate.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import zipfile


def read(p):return json.loads(Path(p).read_bytes())
def encoded(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(raw):return hashlib.sha256(raw).hexdigest()


def archive_proof(folder):
    proof=read(folder/'verification.json')
    if proof.get('complete') is not True:raise ValueError('complete archive required')
    if not proof.get('artifacts'):raise ValueError('retained audit artifacts required')
    if not all(sha((folder/n).read_bytes())==h for n,h in proof['artifacts'].items()):
        raise ValueError('archive checksum mismatch')
    return proof


def development_gate(folder, candidate='transfer_purpose'):
    if candidate not in ('transfer_purpose','transfer_purpose_gain'):
        raise ValueError('explicit reviewed research candidate required')
    proof=archive_proof(folder);summary=read(folder/'summary.json');plan=read(folder/'plan.json')
    if (proof.get('pairs'),proof.get('executions'),proof.get('actual_steps'))!=(10,20,2560):
        raise ValueError('ten original pairs and all2560 actual steps required')
    if proof.get('development_gate_passed') is not True or summary.get('development_gate_passed') is not True:
        raise ValueError('original development criteria did not pass')
    if plan['candidate_arm']!=candidate or plan['reference_arm']!='stable':
        raise ValueError('this bridge requires the same unchanged declared candidate')
    if (not summary['complete'] or summary['pairs_complete']!=10 or len(summary['pairs'])!=10
            or {r['id'] for r in summary['pairs']}!={s['id'] for s in plan['specs']}):
        raise ValueError('every original development condition required')
    if (set(summary['families'])!={'auction','combat','gambling','resources'}
            or any(v < -1e-12 for family in summary['families'].values() for v in family.values())
            or not any(r['id'] in plan['concordant_adverse'] and r['score_delta']>1e-12
                       and r['conditional_delta']>1e-12 for r in summary['pairs'])):
        raise ValueError('unchanged family and concordant-improvement gates required')
    return proof,plan


def qualify_exact_runtime(source, runtime, development):
    qualified=archive_proof(runtime)
    if not qualified['regression']['passed'] or not qualified['exact_h32_forecast']['identical']:
        raise ValueError('qualified exact runtime required')
    with zipfile.ZipFile(runtime/'qualification.zip') as packed:
        sources=json.loads(packed.read('exact_runtime_copy_removal_regression_20261031/source.json'))
    if sha(encoded(sources))!=qualified['source_sha256'] or not all(sha((source/n).read_bytes())==h for n,h in sources.items()):
        raise ValueError('worker differs from the exact runtime qualification')
    commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
    if commit!='41ed387f1ae96ea9ecc449f3c1f93714c0cf41a3':
        raise ValueError('the currently qualified immutable runtime commit is required')
    return commit,sources


def prepare(source, development, losses, review, runtime, output, *,
            candidate='transfer_purpose', runtime_qualifier=qualify_exact_runtime):
    source,development,losses,runtime,output=map(lambda p:Path(p).resolve(),(source,development,losses,runtime,output))
    review_path=Path(review).resolve()
    if output.exists():raise FileExistsError('never replace an existing confirmation registration')
    proof,parent=development_gate(development,candidate)
    diagnostic=archive_proof(losses);root_plan=read(losses/'plan.json');human_review=read(review_path)
    if (diagnostic['whole_study_verification_sha256']!=sha((development/'verification.json').read_bytes())
            or diagnostic['registration']!=proof['registration'] or diagnostic['source_ref']!=proof['source_ref']):
        raise ValueError('diagnostics must belong to this complete original study')
    adverse={r['id'] for r in read(development/'outcome_review.json')['rows']
             if any(r['differences'].get(k,0)<-1e-12 for k in ('score','conditional','reference_choice'))}
    roots={(j['id'],j['tick']) for j in root_plan['jobs']}
    if ({r['id'] for r in root_plan['losses']}!=adverse
            or diagnostic['evaluations']!=6*len(roots)
            or diagnostic['exact_original_forecast_controls']!=len(roots)):
        raise ValueError('all adverse cases and all registered bank/count diagnostics required')
    if (human_review.get('complete') is not True
            or human_review.get('conclusion')!='proceed_to_reserved_confirmation'
            or human_review.get('development_verification_sha256')!=sha((development/'verification.json').read_bytes())
            or human_review.get('diagnostic_verification_sha256')!=sha((losses/'verification.json').read_bytes())
            or set(human_review.get('reviewed_loss_ids',[]))!=adverse
            or human_review.get('personality_review_complete') is not True
            or human_review.get('known_adoption_blocker') is not False
            or not human_review.get('rationale')):
        raise ValueError('explicit evidence-bound all-loss and personality review required; no automatic passage')
    commit,sources=runtime_qualifier(source,runtime,development)
    if subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=source,text=True).strip():
        raise ValueError('clean fixed worker required')
    os.environ.update(parent['arithmetic'])
    os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    sys.path.insert(0,str(source))
    import numpy as np
    from tools.review_adverse_confirmation import reserved_specs
    from tools.archive_adverse_confirmation import validate_plan
    from tools.run_adverse_recovery import verify_registration
    version='purpose-tail-reserved40-1' if candidate=='transfer_purpose' else 'gain-tail-reserved40-1'
    plan=dict(version=version,specs=reserved_specs(),
        arms=['original16','stable',candidate],reference_arm='stable',candidate_arm=candidate,
        arithmetic=parent['arithmetic'],concordant_adverse=[],
        model_seeds={arm:[701,702,703] for arm in ('original16','stable',candidate)},
        criteria=parent['independent_confirmation'],adoption=False,
        development_registration=proof['registration'],development_source_ref=proof['source_ref'],
        runtime_source_ref=commit,runtime_qualification_sha256=sha((runtime/'verification.json').read_bytes()),
        scientific_scope='Unchanged candidate and both original controls; qualified runtime only. Forty conditions are ten worlds crossed with four personas, not forty IID worlds.',
        prerequisite_review_sha256=sha(review_path.read_bytes()))
    validate_plan(plan)
    driver=Path(__file__).resolve().parents[2]/'tools/local_adverse_queue.py'
    checkpoint_io=driver.with_name('local_checkpoint_io.py')
    driver_bytes=driver.read_bytes();io_bytes=checkpoint_io.read_bytes()
    output.mkdir(parents=True)
    (output/'plan.json').write_bytes(encoded(plan))
    (output/'registration.json').write_bytes(encoded(dict(plan_sha256=sha(encoded(plan)),sources=sources)))
    registration=verify_registration(output/'plan.json')
    study='purpose_confirmation' if candidate=='transfer_purpose' else 'gain_confirmation'
    jobs=[dict(study=study,source=str(source),plan=str(output/'plan.json'),
        registration=registration,spec=spec,arm=arm,arithmetic=plan['arithmetic'],
        output=str(output/'confirmation/latest'/f"adverse-{spec['id']}-{arm}"))
        for spec in plan['specs'] for arm in plan['arms']]
    assert len(jobs)==120 and len({j['output'] for j in jobs})==120
    manifest=dict(version=1,created=datetime.now(timezone.utc).isoformat(),source_ref=commit,
        runtime=dict(python=sys.version,numpy=np.__version__,system=platform.system(),machine=platform.machine()),
        driver_sha256=sha(driver_bytes),io_sha256=sha(io_bytes),jobs=jobs,adoption=False,
        development_verification_sha256=sha((development/'verification.json').read_bytes()),
        diagnostic_verification_sha256=sha((losses/'verification.json').read_bytes()),
        all_loss_persona_review_sha256=sha(review_path.read_bytes()))
    for name,raw in [('driver.py',driver_bytes),('local_checkpoint_io.py',io_bytes),
                     ('review.json',review_path.read_bytes()),('manifest.json',encoded(manifest))]:
        (output/name).write_bytes(raw)
    print(json.dumps(dict(prepared=True,launched=False,conditions=40,executions=120,
        source=commit,manifest_sha256=sha(encoded(manifest)),adoption=False)))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ('source','development','losses','review','runtime','output'):p.add_argument('--'+name,required=True)
    prepare(**vars(p.parse_args()))
