"""Account every stored choice without rerunning or selecting diagnostic roots."""
import argparse
import hashlib
import json
from pathlib import Path


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def account(folder):
    receipt = read(folder / 'verification.json')
    assert receipt['pair_complete'] and not receipt['cohort_gate_evaluated']
    assert all(sha(Path(n).read_bytes()) == h for n, h in receipt['source_files'].items())
    arms = {}
    for name in receipt['source_files']:
        if Path(name).name != 'result.json':
            continue
        result = read(Path(name))
        assert result['complete']
        tr = result['trace']
        rows = []
        for row in tr:
            values = row['purpose_by_plan']
            selected = row['selected_plan']
            assert values[selected] == row['selected_purpose']
            gap = max(values.values()) - values[selected]
            assert gap >= 0
            rows.append(dict(tick=row['tick'], action=row['action'],
                policy=row['selected_policy'], selected_purpose=values[selected],
                best_modeled_purpose=max(values.values()), modeled_purpose_sacrifice=gap))
        phases = []
        for start in range(0, receipt['spec']['turns'], 32):
            local = rows[start:start+32]
            phases.append(dict(start=start, end=start+len(local), choices=len(local),
                nonmaximal_choices=sum(r['modeled_purpose_sacrifice'] > 1e-12 for r in local),
                mean_modeled_sacrifice=sum(r['modeled_purpose_sacrifice'] for r in local)/len(local),
                max_modeled_sacrifice=max(r['modeled_purpose_sacrifice'] for r in local)))
        arms[result['configuration']['arm']] = dict(rows=rows, phases=phases)
    assert set(arms) == {'stable', receipt.get('candidate_arm', 'transfer_purpose')}
    result = dict(case=receipt['case'], arms=arms, adoption=False, cohort_gate_evaluated=False,
        receipt_sha256=sha((folder/'verification.json').read_bytes()),
        limits=['Every recorded actual choice included; no probe roots selected.',
                'Modeled sacrifice is the chosen versus maximal stored purpose value, not a measured cost of personality.',
                'Choosing maximal modeled purpose does not prove accurate forecasts or adequate continuation coverage.'])
    with (folder/'selection_accounting.json').open('x', encoding='utf-8') as f:
        json.dump(result, f, sort_keys=True, indent=2)
    return dict(case=receipt['case'], phases={k:v['phases'] for k,v in arms.items()})


if __name__ == '__main__':
    p=argparse.ArgumentParser(); p.add_argument('--pair', required=True); a=p.parse_args()
    print(json.dumps(account(Path(a.pair))))
