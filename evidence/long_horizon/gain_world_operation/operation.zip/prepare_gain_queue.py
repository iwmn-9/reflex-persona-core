"""Freeze a local execution queue for registered gain-tail development only.

No simulation is launched. Existing queues and evidence are never replaced.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

V=Path(__file__).resolve().parent
U=V.parents[1]
def read(p):return json.loads(Path(p).read_bytes())
def encoded(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def prepare(worker,commit,output):
    worker,output=Path(worker).resolve(),Path(output).resolve()
    if output.exists():raise FileExistsError('inspect and retain the existing queue')
    if subprocess.check_output(['git','rev-parse','HEAD'],cwd=worker,text=True).strip()!=commit:
        raise ValueError('exact registered worker commit required')
    if subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=worker,text=True).strip():
        raise ValueError('clean frozen worker required')
    plan_path=worker/'evidence/long_horizon/adverse_gain_tail/plan.json'
    plan=read(plan_path)
    if (plan['version']!='adverse-gain-tail-1' or plan['arms']!=['stable','transfer_purpose_gain']
            or len(plan['specs'])!=10 or any(s['turns']!=128 for s in plan['specs'])):
        raise ValueError('complete registered ten-world gain-tail plan required')
    if not plan.get('prerequisites'):raise ValueError('reviewed prerequisites required')
    for name,expected in plan['prerequisites'].items():
        if sha(name)!=expected:raise ValueError('prerequisite evidence changed: '+name)
    registration_file=read(plan_path.parent/'registration.json')
    protocol=read(plan_path.parent/'loss_diagnosis_protocol.json')
    source_sha=hashlib.sha256(encoded(registration_file['sources'])).hexdigest()
    if protocol['source_registration']!=dict(plan_sha256=sha(plan_path),source_sha256=source_sha):
        raise ValueError('all-loss diagnosis protocol must bind this exact plan/source')
    os.environ.update(plan['arithmetic'])
    os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    sys.path.insert(0,str(worker))
    from tools.run_adverse_recovery import verify_registration
    import numpy as np
    registration=verify_registration(plan_path)
    driver=U/'tools/local_adverse_queue.py';io=U/'tools/local_checkpoint_io.py'
    jobs=[dict(study='gain',source=str(worker),plan=str(plan_path),registration=registration,
        spec=s,arm=a,arithmetic=plan['arithmetic'],output=str(output/'gain/latest'/f"adverse-{s['id']}-{a}"))
        for s in plan['specs'] for a in plan['arms']]
    if len(jobs)!=20 or len({j['output'] for j in jobs})!=20:raise ValueError('twenty unique executions required')
    manifest=dict(version=1,created=datetime.now(timezone.utc).isoformat(),source_ref=commit,
        runtime=dict(python=sys.version,numpy=np.__version__,system=platform.system(),machine=platform.machine()),
        driver_sha256=sha(driver),io_sha256=sha(io),jobs=jobs,adoption=False,
        independent_confirmation='not started',
        scope='Fresh original ten-world gain-tail development. Existing original study and its diagnostics remain required.',
        plan_sha256=sha(plan_path),protocol_sha256=sha(plan_path.parent/'loss_diagnosis_protocol.json'))
    output.mkdir(parents=True)
    (output/'driver.py').write_bytes(driver.read_bytes())
    (output/'local_checkpoint_io.py').write_bytes(io.read_bytes())
    (output/'manifest.json').write_bytes(encoded(manifest))
    return dict(prepared=True,launched=False,adoption=False,executions=20,actual_steps=2560,
        manifest=str(output/'manifest.json'),sha256=sha(output/'manifest.json'),source_ref=commit)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('worker','commit','output'):parser.add_argument('--'+name,required=True)
    print(json.dumps(prepare(**vars(parser.parse_args()))))
