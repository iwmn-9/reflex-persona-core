"""Retain operational source/proofs without collecting a live scientific trace."""
from pathlib import Path
import hashlib
import json
import zipfile

V=Path(__file__).parent;B=V.parents[2]
H=B/'reflex-persona-preview-runtime';R=B/'reflex-persona-core'
out=R/'evidence/long_horizon/gain_world_operation';out.mkdir(parents=True,exist_ok=False)
files={n:V/n for n in ('prepare_gain_development.py','prepare_gain_queue.py',
    'finish_purpose_study_v2.py','create_gain_finisher.py','prepare_reserved_purpose_confirmation.py',
    'prepare_reserved_gain_confirmation.py','reserved_gain_bridge_check.json',
    'audit_completed_purpose_pair.py','account_completed_selection.py','account_forecast_execution.py',
    'audit_pair_bridge_regression/bridge_check.json','gain_world_finish/manifest.json',
    'archive_gain_operation.py')}
files['execution/manifest.json']=H/'results/gain_development_20261031/manifest.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with zipfile.ZipFile(out/'operation.zip','x',zipfile.ZIP_DEFLATED) as packed:
    for name,p in files.items():packed.write(p,name)
receipt=dict(complete=True,scope='Operational preparation only; actual long-world results remain incomplete.',adoption=False,
    scientific_source='71bf6b2f3e40724a7bb33be14dc3bd3311ee18f8',scientific_files=600,
    plan_sha256='c4998de07a4bf0facb47a0a9531540567eb2aceba482205ea7e0ed5c148abb9f',
    manifest_sha256=sha(files['execution/manifest.json']),finisher_manifest_sha256=sha(files['gain_world_finish/manifest.json']),
    completed_checks=['Positive creation of the original ten-world plan and twenty-job queue from the actual complete10-pair mechanism proof.',
        'Four live workers started; cheap monitor confirmed CPU progress and no initial failures.',
        'Unchanged generic one-shot pipeline bound to this distinct coordinator and its registered all-loss protocol.',
        'Six refusal checks for future reserved confirmation; positive confirmation is not yet permitted or exercised.',
        'Existing completed Q pair accounting remained exactly equal after making the offline collector usable for the declared G arm.'],
    files={n:sha(p) for n,p in files.items()},archive_sha256=sha(out/'operation.zip'))
(out/'verification.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n',encoding='utf-8')
(out/'README.md').write_text('''# 新候補のローカル実行への接続

600 Pythonファイルを固定した `71bf6b2` で、元の10条件・新規対照を含む20実行を開始した。長期結果の合格を示す記録ではない。科学計画と全条件の正本は同じコミットの `evidence/long_horizon/adverse_gain_tail`。

`operation.zip` は作成・実行接続・全完走後の監査・全悪化診断・将来の独立確認の準備コードと固定manifestを保持する。終了後の依存処理は一回限りで、現在の親プロセス終了と20実行の完全な保存を待つ。完走前の局面選定、別の条件でのやり直し、自動採用、独立確認の自動着手は行わない。先行する目的評価接続の研究とは別の入力・出力を使う。

将来の独立確認には、全10条件の合格、全悪化の登録済み診断、人格を含む根拠付きレビューが必要。反復計算の完了数を合格へ読み替えない。未完了・不合格の資料や、機構診断だけで進む要求を拒否する確認が通った。実際に条件を満たす資料はまだないため、成功側の独立確認準備は未実施である。

起動済み処理をこのZIPから重複起動しない。現在のPID・進捗・復旧順はリポジトリの `results/long_horizon_resume_status.json` を参照する。実行中のcheckpointは監視で開かず、保存後に出る進捗通知を使う。固定ファイルや処理中のソースは変更しない。
''',encoding='utf-8')
print(json.dumps(dict(retained=True,adoption=False,output=str(out))))
