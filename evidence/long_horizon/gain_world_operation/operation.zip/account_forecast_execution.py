"""Every complete factual window: noise, belief error, and remaining plan gap.

The path-conditional accounts are not expected values of an unexecuted policy.
They never supply hidden truth to an actor, select diagnostic roots, or replace
the registered full-cohort gates.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys


def read(p):return json.loads(p.read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()


def account(source,folder):
    receipt=read(folder/'verification.json')
    assert receipt['pair_complete'] and not receipt['cohort_gate_evaluated']
    assert all(sha(Path(n).read_bytes())==h for n,h in receipt['source_files'].items())
    sys.path.insert(0,str(source))
    from tools.run_adverse_recovery import game_for
    game=game_for(receipt['spec']);arms={}
    for name in receipt['source_files']:
        if Path(name).name!='result.json':continue
        result=read(Path(name));trace=result['trace'];assert result['complete']
        horizon=result['configuration']['horizon'];rows=[];increments=[]
        for row in trace:
            current=game.goal(row['before']).value
            changes={z:game.goal(game.transition(row['before'],row['action'],z)[0]).value-current
                for z in row['truth']}
            truth=sum(p*changes[z] for z,p in row['truth'].items())
            belief=sum(p*changes[z] for z,p in row['response_prediction'].items())
            assert abs(truth-row['conditional_increment'])<1e-12
            assert row['predicted_actions'][0]==row['action']
            increments.append((truth,belief))
        for index,row in enumerate(trace):
            end=min(index+horizon,len(trace));origin=game.goal(row['before']).value
            actual=game.goal(trace[end-1]['after']).value
            conditional=origin+sum(t for t,b in increments[index:end])
            belief=origin+sum(b for t,b in increments[index:end])
            forecast=row['selected_purpose']
            components=dict(realized_innovation=actual-conditional,
                factual_belief_error=conditional-belief,planning_to_execution_gap=belief-forecast)
            assert abs(sum(components.values())-(actual-forecast))<1e-12
            predicted=row['predicted_actions'];remaining=min(len(predicted),end-index)
            agreement=sum(predicted[k]==trace[index+k]['action'] for k in range(1,remaining))
            rows.append(dict(tick=index,end=end,forecast=forecast,actual=actual,
                true_path_conditional=conditional,belief_path_conditional=belief,
                actual_minus_forecast=actual-forecast,**components,
                first_sample_future_action_agreement=agreement,compared_future_actions=max(0,remaining-1)))
        phases=[]
        for start in range(0,len(trace),32):
            local=rows[start:start+32]
            metrics=('actual_minus_forecast','realized_innovation','factual_belief_error','planning_to_execution_gap')
            phases.append(dict(start=start,end=start+len(local),windows=len(local),
                means={key:sum(r[key] for r in local)/len(local) for key in metrics},
                absolute_means={key:sum(abs(r[key]) for r in local)/len(local) for key in metrics},
                actual_below_forecast=sum(r['actual_minus_forecast']<-1e-12 for r in local),
                first_sample_future_action_agreement=sum(r['first_sample_future_action_agreement'] for r in local),
                compared_future_actions=sum(r['compared_future_actions'] for r in local)))
        arms[result['configuration']['arm']]=dict(rows=rows,phases=phases)
    proof=dict(case=receipt['case'],complete_pair=True,adoption=False,cohort_gate_evaluated=False,
        arms=arms,source_receipt_sha256=sha((folder/'verification.json').read_bytes()),
        script_sha256=sha(Path(__file__).read_bytes()),
        limitations=['Overlapping factual windows are correlated, not independent trials.',
            'Conditional-increment sums follow actually executed states/actions, not the expectation of a frozen unexecuted policy.',
            'The planning-to-execution gap also contains changed future beliefs/states/actions, sample noise and continuation approximation.',
            'Only the first saved modeled sample supplies action agreement; it is not agreement of the full forecast distribution.',
            'Hidden truth is evaluation-only. No selected probe roots, new science trials or adoption decision.'])
    with (folder/'forecast_execution_accounting.json').open('x',encoding='utf8') as stream:
        json.dump(proof,stream,sort_keys=True,indent=2)
    print(json.dumps(dict(case=proof['case'],phases={k:v['phases'] for k,v in arms.items()})))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--pair',required=True);a=p.parse_args()
    account(Path(a.source).resolve(),Path(a.pair).resolve())
