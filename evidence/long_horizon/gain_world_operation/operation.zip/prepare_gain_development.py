"""Prepare original ten-world development only after the full mechanism audit.

Never launches execution, replaces a prior study, or authorizes the reserved
forty. Runtime qualification and scientific mechanism passage are separate.
"""
import argparse
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile


def read(p):return json.loads(Path(p).read_bytes())
def encoded(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def mechanism_gate(folder):
    folder=Path(folder)
    if not (folder/'verification.json').is_file():raise ValueError('complete mechanism archive required')
    proof=read(folder/'verification.json')
    if (proof.get('complete') is not True or proof.get('kind')!='gain'
            or (proof.get('pairs'),proof.get('executions'),proof.get('actual_steps'))!=(10,20,2560)
            or proof.get('mechanism_gate_passed') is not True
            or not proof.get('every_step_restored') or not proof.get('fixed_personas_and_exact_learners')):
        raise ValueError('all ten mechanism pairs, exact owners and unchanged passage criteria required')
    for name,value in proof['artifacts'].items():
        if sha(folder/name)!=value:raise ValueError('audited mechanism artifact changed')
    summary=read(folder/'summary.json');plan=read(folder/'plan.json')
    if (not summary['complete'] or not summary['nonnegative_every_pair'] or not summary['strict_gain']
            or len(summary['pairs'])!=10 or {r['id'] for r in summary['pairs']}!={s['id'] for s in plan['specs']}
            or summary['actual_steps']!=2560 or summary['plan_sha256']!=sha(folder/'plan.json')):
        raise ValueError('complete unchanged mechanism screen required')
    if any(r['delta']<-1e-12 for r in summary['pairs']) or not any(r['delta']>1e-12 for r in summary['pairs']):
        raise ValueError('mechanism score criteria failed')
    return proof


def prepare(source,mechanism,parent,runtime,connection,protocol,resolver,driver,probe,collector):
    source,mechanism,parent,runtime,connection,protocol,resolver,driver,probe,collector=map(lambda p:Path(p).resolve(),
        (source,mechanism,parent,runtime,connection,protocol,resolver,driver,probe,collector))
    mp=mechanism_gate(mechanism)
    proof=read(runtime/'verification.json')
    if (not proof['complete'] or proof['adoption'] or not proof['exact_known_h32_forecast']
            or proof['exact_matrix_cases']!=7 or proof['tests']['remaining_failures']
            or proof['tests']['unique_methods_passed']!=53):
        raise ValueError('qualified prepared-context runtime required')
    for name,value in proof['files'].items():
        if sha(runtime/name)!=value:raise ValueError('runtime qualification artifact changed')
    with zipfile.ZipFile(runtime/'verification_data.zip') as data:
        baseline=json.loads(data.read('prepared_context_exact_root.json'))
    if baseline['source_sha256']!=proof['source_sha256'] or any(sha(source/n)!=v for n,v in baseline['sources'].items()):
        raise ValueError('source differs from qualified runtime')
    linked=read(connection)
    if (not linked['complete'] or not linked['passed'] or linked['actual_steps']!=24
            or {r['family'] for r in linked['rows']}!={'auction','combat','gambling','resources'}
            or any(not r['exact_continuous_vs_resume'] or not r['wrong_arm_and_registration_rejected'] for r in linked['rows'])
            or any(sha(source/n)!=v for n,v in linked['sources'].items())):
        raise ValueError('exact candidate runner and resumption connection required')
    if subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=source,text=True).strip():
        raise ValueError('clean scientific source required')
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
    if head!=subprocess.check_output(['git','rev-parse','3cf4fa4'],cwd=source,text=True).strip():
        raise ValueError('the reviewed prepared-context runtime base is required')
    original=read(parent);rule=read(protocol)
    if original['candidate_arm']!='transfer_purpose' or original['reference_arm']!='stable' or len(original['specs'])!=10:
        raise ValueError('original purpose-tail ten-world plan required')
    if (sha(resolver)!=rule['resolver']['sha256'] or sha(driver)!=rule['operational_driver_sha256']
            or sha(probe)!=rule['diagnostic_source_sha256'] or sha(collector)!=rule['collector_sha256']):
        raise ValueError('unchanged all-loss diagnostic protocol tools required')
    destination=source/'evidence/long_horizon/adverse_gain_tail'
    if destination.exists():raise FileExistsError('never replace a registered development study')
    plan=dict(original,version='adverse-gain-tail-1',candidate='H32 public-goal completion proposal with the same learning owner',
        arms=['stable','transfer_purpose_gain'],candidate_arm='transfer_purpose_gain',reference_arm='stable',
        model_seeds={'stable':[701,702,703],'transfer_purpose_gain':[701,702,703]},
        predecessor_plan_sha256=sha(parent),runtime_base=head,
        purpose='Fresh original ten-world paired development. Neither complete mechanism tests nor partial preceding worlds permit adoption.',
        change='Preserve old reflex/full-retry proposals. Add one proposal returning to the same learning owner after modeled public goal exceeds the root value. Same H32, H2 recovery, posterior learner, factual rules, actual RNG and persona. Qualified runtime only removes duplicate computations.',
        prerequisites={str(mechanism/'verification.json'):sha(mechanism/'verification.json'),
            str(runtime/'verification.json'):sha(runtime/'verification.json'),str(connection):sha(connection)},
        limitations=['Deterministic preparation improvements are not stochastic world-wide evidence.',
            'A public goal increase need not mean all preparation is complete; passive income may trigger it.',
            'Unknown world responses and approximate future replanning remain potential errors.',
            'The original purpose-tail cohort and its complete loss diagnostics remain required and are never replaced.',
            'All original numerical development and independent confirmation conditions are retained.'])
    assert plan['specs']==original['specs'] and plan['criteria']==original['criteria']
    assert plan['independent_confirmation']==original['independent_confirmation']
    paths=sorted(p for folder in ('reflex','tools','tests') for p in (source/folder).glob('*.py'))
    hashes={p.relative_to(source).as_posix():sha(p) for p in paths}
    registration=dict(version='frozen-adverse-gain-tail-1',plan_sha256=hashlib.sha256(encoded(plan)).hexdigest(),
        stable_commit=original['stable_commit'],sources=hashes)
    registered_rule=dict(rule,version='gain-tail-losses-1',at=datetime.now(timezone.utc).isoformat(),
        applicability='All adverse original-ten gain-tail development results before any world execution.',
        predecessor_protocol_sha256=sha(protocol),source_registration=dict(plan_sha256=registration['plan_sha256'],
            source_sha256=hashlib.sha256(encoded(hashes)).hexdigest()))
    destination.mkdir(parents=True)
    for name,value in [('plan.json',plan),('registration.json',registration),('loss_diagnosis_protocol.json',registered_rule)]:
        (destination/name).write_bytes(encoded(value))
    with zipfile.ZipFile(destination/'source.zip','x',zipfile.ZIP_DEFLATED) as packed:
        for name,value in hashes.items():
            assert sha(source/name)==value;packed.writestr(name,(source/name).read_bytes())
        for name in ('plan.json','registration.json','loss_diagnosis_protocol.json'):
            packed.writestr('evidence/long_horizon/adverse_gain_tail/'+name,(destination/name).read_bytes())
    return dict(prepared=True,started=False,adoption=False,conditions=10,executions=20,
        actual_steps=2560,files=len(hashes),plan_sha256=registration['plan_sha256'],output=str(destination),
        mechanism_sha256=sha(mechanism/'verification.json'),runtime_sha256=sha(runtime/'verification.json'))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('source','mechanism','parent','runtime','connection','protocol','resolver','driver','probe','collector'):
        parser.add_argument('--'+name,required=True)
    print(json.dumps(prepare(**vars(parser.parse_args()))))
