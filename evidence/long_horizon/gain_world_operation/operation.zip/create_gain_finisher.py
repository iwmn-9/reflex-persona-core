"""Bind the existing one-shot audit pipeline to the separately registered G run."""
from pathlib import Path
import hashlib
import json

V=Path(__file__).parent;B=V.parents[2]
H=B/'reflex-persona-preview-runtime';U=B/'reflex-persona-consistent-reading';R=B/'reflex-persona-core'
queue=H/'results/gain_development_20261031';evidence=H/'evidence/long_horizon/adverse_gain_tail'
destination=V/'gain_world_finish';roots=V/'gain_world_roots'
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
state=read(queue/'state.json');registered=read(queue/'manifest.json')
assert state['pid']==20924 and state['manifest_sha256']==sha(queue/'manifest.json')
assert not state['failures'] and len(registered['jobs'])==20
assert registered['source_ref']=='71bf6b2f3e40724a7bb33be14dc3bd3311ee18f8'
rule=read(evidence/'loss_diagnosis_protocol.json')
driver=U/'tools/run_registered_loss_roots.py';probe=U/'tools/probe_registered_owner.py'
collector=U/'tools/archive_registered_loss_roots.py';resolver=R/'evidence/long_horizon/adverse_sample_budget/loss_root_resolver.py'
assert sha(driver)==rule['operational_driver_sha256'] and sha(probe)==rule['diagnostic_source_sha256']
assert sha(collector)==rule['collector_sha256'] and sha(resolver)==rule['resolver']['sha256']
files=[V/'finish_purpose_study_v2.py',queue/'manifest.json',evidence/'plan.json',evidence/'registration.json',
       evidence/'loss_diagnosis_protocol.json',H/'tools/archive_adverse_study.py',R/'tools/prepare_registered_loss_roots.py',
       resolver,driver,probe,collector]
stages=[dict(kind='study',args=[str(H/'tools/archive_adverse_study.py'),'--root',str(queue/'gain'),
            '--plan',str(evidence/'plan.json'),'--source-ref',registered['source_ref'],'--output',str(evidence/'completed_local')],
            proof=str(evidence/'completed_local/verification.json')),
    dict(kind='prepare',args=[str(R/'tools/prepare_registered_loss_roots.py'),'--study',str(evidence/'completed_local'),
            '--worker',str(H),'--source-plan','evidence/long_horizon/adverse_gain_tail/plan.json',
            '--resolver',str(resolver),'--driver',str(driver),'--probe',str(probe),'--output',str(roots)],
            proof=str(roots/'prepared.json')),
    dict(kind='diagnose',args=[str(roots/'driver.py'),'--root',str(roots),'--workers','4'],
            proof=str(roots/'verification.json')),
    dict(kind='archive',args=[str(collector),'--execution',str(roots),'--study',str(evidence/'completed_local'),
            '--root-plan',str(roots/'plan.json'),'--prepared-manifest',str(roots/'manifest.json'),
            '--resolver',str(resolver),'--output',str(evidence/'roots_complete')],
            proof=str(evidence/'roots_complete/verification.json'))]
manifest=dict(arithmetic=read(evidence/'plan.json')['arithmetic'],cwd=str(R),files={str(p):sha(p) for p in files},
    source_ref=registered['source_ref'],parent_pid=20924,queue_state=str(queue/'state.json'),
    queue_manifest_sha256=sha(queue/'manifest.json'),stages=stages,
    classification='One-shot gain-world complete audit and all predeclared losses. Original purpose run remains separate. No adoption or reserved confirmation.')
destination.mkdir(parents=True,exist_ok=False)
(destination/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(prepared=True,launched=False,manifest=str(destination/'manifest.json'),sha256=sha(destination/'manifest.json'))))
