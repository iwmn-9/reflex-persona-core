from pathlib import Path
import json,sys,hashlib
from prepare_reserved_purpose_confirmation import interleave_job_families,encoded
v=Path(__file__).parent;b=v.parents[2]
sys.path.insert(0,str(b/'reflex-persona-preview-runtime'))
from tools.review_adverse_confirmation import reserved_specs
specs=reserved_specs();arms=('original16','stable','transfer_purpose_gain')
jobs=[dict(spec=spec,arm=arm,source='fixed-source',registration='fixed-registration',
           output=spec['id']+'/'+arm) for spec in specs for arm in arms]
new=interleave_job_families(jobs)
assert len(new)==120 and len({j['output'] for j in new})==120
assert sorted(map(encoded,new))==sorted(map(encoded,jobs))
assert len({j['spec']['game'] for j in new[:12]})==4
assert all([x['arm'] for x in new[n:n+3]]==list(arms) for n in range(0,120,3))
assert interleave_job_families([])==[]
result=dict(complete=True,scientific_conditions_changed=False,exact_jobs=120,conditions=40,
    first_four_pairs=[j['spec']['game'] for j in new[:12:3]],
    all_controls_retained=True,no_existing_queue_changed=True,reserved_started=False,
    selection_uses_outcomes=False,
    preparer_sha256=hashlib.sha256((v/'prepare_reserved_purpose_confirmation.py').read_bytes()).hexdigest(),
    note='Same total work and acceptance gates; next confirmation exposes different families earlier. No wall-time speedup or early adoption claim.')
(v/'confirmation_order_check.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
