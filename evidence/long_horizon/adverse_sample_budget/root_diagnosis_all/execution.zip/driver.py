"""Finite, low-priority execution of the already declared remaining roots."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone


def read(p):
    return json.loads(Path(p).read_bytes())


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(p, value):
    p = Path(p)
    temporary = p.with_suffix('.new')
    temporary.write_text(json.dumps(value, sort_keys=True, allow_nan=False))
    temporary.replace(p)


root = Path('/home/ubuntu/recovery/sample8_loss_roots')
root.mkdir(exist_ok=True)
manifest = read(root / 'manifest.json')
assert sha(__file__) == manifest['driver_sha256']
plan = read(root / 'plan.json')
assert sha(root / 'plan.json') == manifest['plan_sha256']
probe = root / 'probe_frozen_sample_budget.py'
assert sha(probe) == manifest['probe_sha256']
assert plan['candidate'] == 'sample8' and plan['complete_archive'] and not plan['adoption']
assert plan['source_ref'] == manifest['source_ref']
worker = Path('/home/ubuntu/recovery/sample8/source')
input_root = Path('/home/ubuntu/recovery/sample8/latest')
source_plan = worker / 'evidence/long_horizon/adverse_sample_budget/plan.json'
os.environ.update(read(source_plan)['arithmetic'])
os.environ.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
sys.path.insert(0, str(worker))
from tools.run_adverse_recovery import verify_registration

registration = verify_registration(source_plan)
assert registration == plan['registration']
jobs = [job for job in plan['jobs'] if not job['reuse']]
assert len(jobs) == plan['pending_evaluations']
status = dict(complete=False, adoption=False, pid=os.getpid(), evaluations_required=len(jobs),
              evaluations_complete=0, root_plan_sha256=manifest['plan_sha256'],
              source_registration=registration, priority=os.getpriority(os.PRIO_PROCESS, 0))

def validate(job, result, original):
    saved = original['trace'][job['tick']]
    assert result['id'] == job['id'] and result['tick'] == job['tick']
    assert result['seeds'] == list(range(job['start'], job['start'] + job['samples']))
    assert result['factual_owner'] == job['factual_owner'] == saved['before_owner']
    assert result['input_sha256'] == job['input_sha256']
    assert result['registration'] == registration and result['diagnostic_source_sha256'] == manifest['probe_sha256']
    if (job['start'], job['samples']) == (701, 8):
        assert result['exact_registered_forecast_reproduced']
        assert (result['action'], result['selected_purpose']) == (saved['action'], saved['selected_purpose'])


with (root / 'queue.lock').open('ab+') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    if (root / 'status.json').exists() and read(root / 'status.json').get('state') == 'failed':
        raise RuntimeError('inspect the recorded failure before restarting')
    rows = []
    try:
        for index, job in enumerate(jobs):
            source = input_root / ('adverse-' + job['id'] + '-sample8') / 'result.json'
            assert sha(source) == job['input_sha256']
            original = read(source)
            filename = f'root-{index:03}.json'
            output = root / filename
            status.update(state='running', job=job, evaluations_complete=len(rows), updated=datetime.now(timezone.utc).isoformat())
            save(root / 'status.json', status)
            if not output.exists():
                with (root / 'execution.stdout.log').open('ab') as out, (root / 'execution.stderr.log').open('ab') as err:
                    child = subprocess.Popen([sys.executable, str(probe), '--worker', str(worker), '--input', str(source),
                                    '--tick', str(job['tick']), '--start', str(job['start']), '--samples', str(job['samples']),
                                    '--output', str(output)], stdout=out, stderr=err)
                    status.update(child_pid=child.pid)
                    save(root / 'status.json', status)
                    code = child.wait()
                    if code:
                        raise subprocess.CalledProcessError(code, child.args)
            result = read(output)
            validate(job, result, original)
            rows.append(dict(job=job, file=filename, sha256=sha(output)))
        assert verify_registration(source_plan) == registration
        save(root / 'verification.json', dict(complete=True, adoption=False, evaluations=len(rows), rows=rows,
             root_plan_sha256=manifest['plan_sha256'], sources=manifest, exact_factual_roots=True,
             exact_original_forecast_controls=sum((j['start'], j['samples']) == (701, 8) for j in jobs)))
        status.update(state='complete', complete=True, evaluations_complete=len(rows), job=None, child_pid=None,
                      updated=datetime.now(timezone.utc).isoformat())
        save(root / 'status.json', status)
    except BaseException as error:
        status.update(state='failed', error=repr(error), complete=False, updated=datetime.now(timezone.utc).isoformat())
        save(root / 'status.json', status)
        raise
