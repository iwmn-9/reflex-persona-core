"""Research: carry an empirical response expert across segment boundaries.

The original segment model resets its unknown component after a possible
change. This extra expert learns from the retained prefix before each reveal;
it is available alongside the original supplied and fresh-segment models.
No game, action utility, true law or future observation is an input.
"""
from functools import lru_cache
import math
import numpy as np
from reflex.core import digest
from reflex.segmented_prediction import SegmentedEventLearner, segment_prediction, _normalize_logs, _segment_posterior


@lru_cache(maxsize=4096)
def augmented(sequence, libraries, alphabet):
    counts = [0] * alphabet
    rows = []
    for index, (outcome, models) in enumerate(zip(sequence, libraries)):
        rows.append((*models, tuple((n + .5) / (index + .5 * alphabet) for n in counts)))
        counts[outcome] += 1
    current = tuple((n + .5) / (len(sequence) + .5 * alphabet) for n in counts)
    return tuple(rows), current


@lru_cache(maxsize=4096)
def residual_augmented(sequence, libraries, alphabet):
    if not sequence:
        return (), (0.,) * alphabet
    rows, retained = residual_augmented(sequence[:-1], libraries[:-1], alphabet)
    prediction = tuple((n+.5) / (sum(retained)+.5*alphabet) for n in retained)
    rows = (*rows, (*libraries[-1], prediction))
    weights, _, evidence = _segment_posterior(sequence, rows, alphabet)
    # Both the empirical expert and the fresh unknown segment are unprovided
    # models. Infer responsibility AFTER reveal, then use it only next time.
    responsibility = float(_normalize_logs(evidence) @ weights[:, :, -2:].sum(axis=(1, 2)))
    counts = list(retained)
    counts[sequence[-1]] += responsibility
    return rows, tuple(counts)


class ReusableEventLearner(SegmentedEventLearner):
    def __init__(self, reuse='all', **kwargs):
        if reuse not in ('all', 'residual'):
            raise ValueError('declared research expert required')
        super().__init__(**kwargs)
        self.reuse = reuse
        self.identity = digest(['reusable-prequential-kt-v1', reuse, self.identity])

    def predict(self, memory, context, legal, models):
        self._check(memory)
        current = self._inputs(context, legal, models)
        predictions, weights = [], []
        for mask in self.masks:
            groups = {}
            for row in memory.history:
                key = (row.legal, tuple(row.context[i] for i in mask))
                groups.setdefault(key, []).append(row)
            target = (legal, tuple(context[i] for i in mask))
            target_p = None
            log_weight = -len(mask) * math.log(2)
            for key, rows in groups.items():
                labels = {v: i for i, v in enumerate(key[0])}
                sequence = tuple(labels[r.outcome] for r in rows)
                libraries = tuple(r.models for r in rows)
                if self.reuse == 'all':
                    augmented_rows, empirical = augmented(sequence, libraries, len(key[0]))
                else:
                    augmented_rows, counts = residual_augmented(sequence, libraries, len(key[0]))
                    empirical = tuple((n+.5) / (sum(counts)+.5*len(key[0])) for n in counts)
                supplied = current if key == target else rows[-1].models
                p, evidence, _ = segment_prediction(sequence, augmented_rows, (*supplied, empirical), len(key[0]))
                log_weight += evidence
                if key == target:
                    target_p = p
            if target_p is None:
                target_p = segment_prediction((), (), (*current, (1 / len(legal),) * len(legal)), len(legal))[0]
            predictions.append(target_p)
            weights.append(log_weight)
        p = _normalize_logs(weights) @ np.array(predictions)
        return dict(zip(legal, (float(v) for v in p / p.sum())))

    def persistent_continuation(self, *args, **kwargs):
        raise ValueError('reusable expert requires its declared posterior continuation')
