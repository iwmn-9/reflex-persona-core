"""Screen one predeclared reusable-expert design on retained prediction data."""
import argparse
import gzip
import json
import math
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools.reusable_prediction import ReusableEventLearner
from tools.owned_checkpoint import encoded, sha


def main(output):
    destination = Path(output)
    if destination.exists():
        raise FileExistsError('retain every previous screen')
    source = ROOT / 'evidence/long_horizon/adverse_recovery/prediction_probe/rows.json.gz'
    rows = json.loads(gzip.decompress(source.read_bytes()))
    labels = ('0', '1', '2')
    models = {str(i): {str(k): .8 if i == k else .1 for k in range(3)} for i in (0, 1)}
    out = []
    for row in rows:
        learner = ReusableEventLearner(owner='diagnostic', model_id='public-symbols-v1', names=tuple(models))
        memory = learner.start()
        metrics = dict(log_loss=0., expected_brier_excess=0.)
        trace = []
        for item in row['trace']:
            p = learner.predict(memory, (), labels, models)
            metrics['log_loss'] -= math.log(p[item['response']]) / len(row['trace'])
            metrics['expected_brier_excess'] += sum((p[z] - q)**2 for z, q in item['truth'].items()) / len(row['trace'])
            trace.append(dict(tick=item['tick'], prediction=p))
            memory = learner.observe(memory, (), labels, models, item['response'])
        base = row['metrics']['supplied-plus-unknown']
        out.append(dict(regime=row['regime'], seed=row['seed'], trace=trace, metrics=metrics,
                        differences={k: v-base[k] for k, v in metrics.items()}))
    summary = {regime: {key: sum(r['differences'][key] for r in out if r['regime'] == regime) / sum(r['regime'] == regime for r in out)
                for key in metrics} for regime in sorted({r['regime'] for r in out})}
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(encoded(dict(input_sha256=sha(source.read_bytes()), rows=out, summary=summary,
        adoption=False, sources={name: sha((ROOT/name).read_bytes()) for name in
            ('tools/reusable_prediction.py', 'tools/probe_reusable_prediction.py', 'reflex/segmented_prediction.py')})))
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True)
    main(parser.parse_args().output)
