"""Compare existing factual predictors on the same retained diagnostic streams.

No controller or outcome is tuned. This is a predictor screen, not adoption.
"""
import argparse
import gzip
import json
import math
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from reflex.adaptive_dynamics import EventLearner
from tools.owned_checkpoint import encoded,sha


def main(output):
    dest=Path(output)
    if dest.exists():raise FileExistsError('fresh diagnostic output required')
    source=ROOT/'evidence/long_horizon/adverse_recovery/prediction_probe/rows.json.gz'
    rows=json.loads(gzip.decompress(source.read_bytes()))
    labels=('0','1','2');models={str(i):{str(k):(.8 if i==k else .1) for k in range(3)} for i in (0,1)}
    output=[]
    for row in rows:
        learners={k:EventLearner(owner='diagnostic',model_id='public-symbols-v1',names=tuple(models),renewal=v)
                  for k,v in [('windows',False),('renewal',True)]}
        memory={k:l.start() for k,l in learners.items()}
        loss={k:dict(log_loss=0.,expected_brier_excess=0.) for k in learners};trace=[]
        for t in row['trace']:
            predictions={k:l.predict(memory[k],(),labels,models) for k,l in learners.items()}
            for k,l in learners.items():
                p=predictions[k]
                loss[k]['log_loss']-=math.log(p[t['response']])/len(row['trace'])
                loss[k]['expected_brier_excess']+=sum((p[z]-q)**2 for z,q in t['truth'].items())/len(row['trace'])
                memory[k]=l.observe(memory[k],(),labels,models,t['response'])
            trace.append(dict(tick=t['tick'],predictions=predictions))
        base=row['metrics']['supplied-plus-unknown']
        output.append(dict(regime=row['regime'],seed=row['seed'],trace=trace,
            differences={k:{m:v-base[m] for m,v in metrics.items()} for k,metrics in loss.items()}))
    summary={regime:{arm:{m:sum(x['differences'][arm][m] for x in output if x['regime']==regime)/
             sum(x['regime']==regime for x in output) for m in ('log_loss','expected_brier_excess')}
             for arm in ('windows','renewal')} for regime in sorted({x['regime'] for x in output})}
    result=dict(input_sha256=sha(source.read_bytes()),rows=output,summary=summary,adoption=False,
        sources={n:sha((ROOT/n).read_bytes()) for n in ('tools/probe_existing_predictors.py',
            'reflex/adaptive_dynamics.py','reflex/renewal_prediction.py')})
    dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(encoded(result))
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True)
    main(p.parse_args().output)
