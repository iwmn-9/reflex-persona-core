"""Research: carry an empirical response expert across segment boundaries.

The original segment model resets its unknown component after a possible
change. This extra expert learns from the retained prefix before each reveal;
it is available alongside the original supplied and fresh-segment models.
No game, action utility, true law or future observation is an input.
"""
from functools import lru_cache
import math
import numpy as np
from reflex.core import digest
from reflex.segmented_prediction import SegmentedEventLearner, segment_prediction, _normalize_logs, _segment_posterior, HAZARDS


def hierarchy_prior(nlib):
    # Preserve the original total prior of supplied versus unprovided models.
    # Split only the latter between fresh and reusable empirical prediction.
    return np.array([.5/(nlib-1)]*(nlib-1)+[.25,.25]) if nlib > 1 else np.array([.5,.5])


@lru_cache(maxsize=4096)
def hierarchical_posterior(sequence, libraries, alphabet):
    if len(sequence) == 1:
        weights = np.zeros((len(HAZARDS), 0, len(libraries[0])+1))
        counts = np.zeros((0, alphabet))
        logp = np.zeros(len(HAZARDS))
    else:
        weights, counts, logp = hierarchical_posterior(sequence[:-1], libraries[:-1], alphabet)
    z = sequence[-1]
    nlib = len(libraries[-1])
    likelihood = np.empty((len(counts), nlib+1))
    likelihood[:, :nlib] = np.array(libraries[-1])[:, z]
    likelihood[:, -1] = (counts[:, z]+.5)/(counts.sum(axis=1)+.5*alphabet)
    reset = hierarchy_prior(nlib)*np.array([row[z] for row in libraries[-1]]+[1/alphabet])
    h = np.array(HAZARDS)[:, None, None]
    masses = np.concatenate(((h if len(sequence)>1 else np.ones_like(h))*reset[None,None,:],
                             (1-h)*weights*likelihood[None,:,:]), axis=1)
    norm = masses.sum(axis=(1,2))
    weights = masses/norm[:,None,None]
    logp = logp+np.log(norm)
    counts = np.vstack((np.zeros((1,alphabet)), counts))
    counts[:,z] += 1
    for a in (weights, counts, logp):
        a.flags.writeable = False
    return weights, counts, logp


@lru_cache(maxsize=4096)
def hierarchical_prediction(sequence, libraries, current, alphabet):
    prior = hierarchy_prior(len(current))
    base = np.array((*current, (1/alphabet,)*alphabet))
    if not sequence:
        return tuple(prior@base), 0., tuple(1/len(HAZARDS) for _ in HAZARDS)
    weights, counts, evidence = hierarchical_posterior(sequence, libraries, alphabet)
    probabilities = []
    for hazard, weight in zip(HAZARDS, weights):
        p = hazard*(prior@base)
        p += (1-hazard)*(weight[:,:-1].sum(axis=0)@np.array(current))
        p += (1-hazard)*(weight[:,-1]@((counts+.5)/(counts.sum(axis=1)[:,None]+.5*alphabet)))
        probabilities.append(p)
    posterior = _normalize_logs(evidence)
    p = posterior@np.array(probabilities)
    logp = max(evidence)+math.log(sum(math.exp(v-max(evidence)) for v in evidence)/len(evidence))
    return tuple(p/p.sum()), logp, tuple(posterior)


@lru_cache(maxsize=4096)
def augmented(sequence, libraries, alphabet):
    counts = [0] * alphabet
    rows = []
    for index, (outcome, models) in enumerate(zip(sequence, libraries)):
        rows.append((*models, tuple((n + .5) / (index + .5 * alphabet) for n in counts)))
        counts[outcome] += 1
    current = tuple((n + .5) / (len(sequence) + .5 * alphabet) for n in counts)
    return tuple(rows), current


@lru_cache(maxsize=4096)
def residual_augmented(sequence, libraries, alphabet, hierarchical=False):
    if not sequence:
        return (), (0.,) * alphabet
    rows, retained = residual_augmented(sequence[:-1], libraries[:-1], alphabet, hierarchical)
    prediction = tuple((n+.5) / (sum(retained)+.5*alphabet) for n in retained)
    rows = (*rows, (*libraries[-1], prediction))
    weights, _, evidence = (hierarchical_posterior if hierarchical else _segment_posterior)(sequence, rows, alphabet)
    # Both the empirical expert and the fresh unknown segment are unprovided
    # models. Infer responsibility AFTER reveal, then use it only next time.
    responsibility = float(_normalize_logs(evidence) @ weights[:, :, -2:].sum(axis=(1, 2)))
    counts = list(retained)
    counts[sequence[-1]] += responsibility
    return rows, tuple(counts)


class ReusableEventLearner(SegmentedEventLearner):
    def __init__(self, reuse='all', **kwargs):
        if reuse not in ('all', 'residual', 'hierarchical'):
            raise ValueError('declared research expert required')
        super().__init__(**kwargs)
        self.reuse = reuse
        self.identity = digest(['reusable-prequential-kt-v1', reuse, self.identity])

    def predict(self, memory, context, legal, models):
        self._check(memory)
        current = self._inputs(context, legal, models)
        evaluate = hierarchical_prediction if self.reuse == 'hierarchical' else segment_prediction
        predictions, weights = [], []
        for mask in self.masks:
            groups = {}
            for row in memory.history:
                key = (row.legal, tuple(row.context[i] for i in mask))
                groups.setdefault(key, []).append(row)
            target = (legal, tuple(context[i] for i in mask))
            target_p = None
            log_weight = -len(mask) * math.log(2)
            for key, rows in groups.items():
                labels = {v: i for i, v in enumerate(key[0])}
                sequence = tuple(labels[r.outcome] for r in rows)
                libraries = tuple(r.models for r in rows)
                if self.reuse == 'all':
                    augmented_rows, empirical = augmented(sequence, libraries, len(key[0]))
                else:
                    augmented_rows, counts = residual_augmented(sequence, libraries, len(key[0]), self.reuse == 'hierarchical')
                    empirical = tuple((n+.5) / (sum(counts)+.5*len(key[0])) for n in counts)
                supplied = current if key == target else rows[-1].models
                p, evidence, _ = evaluate(sequence, augmented_rows, (*supplied, empirical), len(key[0]))
                log_weight += evidence
                if key == target:
                    target_p = p
            if target_p is None:
                target_p = evaluate((), (), (*current, (1 / len(legal),) * len(legal)), len(legal))[0]
            predictions.append(target_p)
            weights.append(log_weight)
        p = _normalize_logs(weights) @ np.array(predictions)
        return dict(zip(legal, (float(v) for v in p / p.sum())))

    def persistent_continuation(self, *args, **kwargs):
        raise ValueError('reusable expert requires its declared posterior continuation')
