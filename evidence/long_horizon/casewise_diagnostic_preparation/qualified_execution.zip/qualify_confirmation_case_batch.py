"""Offline end-to-end qualification using completed historical factual bytes.

No new world or diagnostic process may start. This is not prospective study
registration: a temporary offline fixture explicitly retains the old source.
"""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import tempfile
from unittest.mock import patch
import zipfile

os.environ.update(NPY_DISABLE_CPU_FEATURES='AVX512F,AVX512CD,AVX512_SKX,AVX512_CLX,AVX512_CNL,AVX512_ICL',
    OPENBLAS_CORETYPE='Haswell', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
import confirmation_case_batch as batch
import confirmation_loss_resolver as resolver
from confirmation_diagnostic_cache import encoded, sha, validated_files


if __name__ == '__main__':
    here = Path(__file__).resolve().parent
    archive = here.parents[1]/'evidence/long_horizon/consistent_horizon/completed_local'
    original = here/'consistent_loss_roots_20261031'
    original_manifest = batch.read(original/'manifest.json')
    root_plan = batch.read(original/'plan.json')
    root_proof = batch.read(original/'verification.json')
    assert root_proof['complete'] and root_proof['sources'] == original_manifest
    source = Path(original_manifest['worker'])
    plan_path = source/original_manifest['source_plan']
    plan = batch.read(plan_path)
    full = resolver.prepare(archive)
    original_by_job = {(r['job']['id'], r['job']['tick'], r['job']['start'], r['job']['samples']): r
                       for r in root_proof['rows']}
    rejected, receipts, cached, case_roots = [], [], [], []
    with tempfile.TemporaryDirectory(prefix='reflex-casewise-') as tmp:
        root = Path(tmp)
        with zipfile.ZipFile(archive/'checkpoints.zip') as packed:
            for name in packed.namelist():
                target = root/'facts'/name
                assert target.resolve().is_relative_to((root/'facts').resolve())
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(packed.read(name))
        jobs = [dict(source=str(source), plan=str(plan_path), registration=full['registration'],
                     spec=spec, arm=arm, output=str(root/'facts'/spec['id']/arm), arithmetic=plan['arithmetic'])
                for spec in plan['specs'] for arm in plan['arms']]
        manifest = dict(jobs=jobs, source_ref=full['source_ref'])
        (root/'manifest.json').write_bytes(encoded(manifest))
        files = {name: batch.bound_file(path) for name, path in dict(
            module=batch.__file__, resolver=resolver.__file__,
            cache=here/'confirmation_diagnostic_cache.py', monitor=batch.monitor.__file__,
            driver=original/'driver.py', probe=original/'probe_registered_owner.py',
            manifest=root/'manifest.json', plan=plan_path,
            source_registration=plan_path.parent/'registration.json').items()}
        protocol = dict(version='casewise-confirmation-execution-1',
            fixture='OFFLINE HISTORICAL QUALIFICATION ONLY; NOT A PROSPECTIVE REGISTRATION',
            registration=full['registration'], source_ref=full['source_ref'], files=files,
            powershell=shutil.which('pwsh'), recurring=False, cohort_complete=False, adoption=False)
        (root/'protocol.json').write_bytes(encoded(protocol))
        # These are immutable copied historical files. There is no worker that
        # could write them; exercise the active-writer guard separately below.
        with patch.object(batch.monitor, 'processes', return_value=[]):
            for spec in reversed(plan['specs']):
                target = root/'cases'/spec['id']
                prepared = batch.stage(root/'protocol.json', spec['id'], target)
                receipt = batch.read(target/'case.json')
                for index, job in enumerate(receipt['jobs']):
                    old = original_by_job[job['id'], job['tick'], job['start'], job['samples']]
                    data = (original/old['file']).read_bytes()
                    assert sha(data) == old['sha256']
                    (target/f'root-{index:03}.json').write_bytes(data)
                # Source verification uses git.check_output; reject only an
                # attempted diagnostic subprocess, not that read-only query.
                original_popen = batch.subprocess.Popen
                def no_probe(args, *a, **kw):
                    if len(args) > 1 and str(args[1]).endswith('probe_registered_owner.py'):
                        raise AssertionError('Qualification must not start a diagnostic')
                    return original_popen(args, *a, **kw)
                with patch.object(batch.subprocess, 'Popen', side_effect=no_probe):
                    status = batch.run(target, workers=2)
                assert status['state'] == 'complete_case_diagnostics'
                assert status['completed'] == len(receipt['jobs']) and not status['cohort_complete']
                rebuilt, entries = batch.cache_entries(target)
                assert rebuilt == receipt
                receipts.append(receipt)
                cached.extend(entries)
                case_roots.append(target)
        driver = batch.load_module(original/'driver.py', 'historical_validator')
        outputs, handoff = validated_files(archive, receipts, cached, original_manifest['probe_sha256'], driver.validate)
        assert len(outputs) == 72
        assert all(raw == (original/name).read_bytes() for name, raw in outputs.items())
        # Exercise the actual unchanged preparation, final driver and collector.
        # Their outputs are retrospective qualifications, not a second study.
        preparer = batch.load_module(here.parents[2]/'reflex-persona-core/tools/prepare_registered_loss_roots.py', 'original_preparer')
        final = root/'final'
        preparer.prepare(archive, source, original_manifest['source_plan'], resolver.__file__,
                         original/'driver.py', original/'probe_registered_owner.py', final)
        with patch.object(batch.monitor, 'processes', return_value=[]):
            installed = batch.install(archive, final, case_roots)
        assert (installed['verified_cached'], installed['remaining_required']) == (72, 0)
        final_driver = batch.load_module(final/'driver.py', 'unchanged_prepared_driver')
        with patch.object(batch.subprocess, 'Popen', side_effect=no_probe):
            final_driver.main(final, workers=2)
        collector = batch.load_module(here.parents[1]/'tools/archive_registered_loss_roots.py', 'original_collector')
        collected = collector.archive(final, archive, final/'plan.json', final/'manifest.json',
                                      resolver.__file__, root/'final_archive')
        assert collected['complete'] and collected['evaluations'] == 72
        assert collected['exact_original_forecast_controls'] == 12
        def reject(name, fn):
            try:
                fn()
            except (ValueError, AssertionError, FileExistsError, RuntimeError):
                rejected.append(name)
            else:
                raise AssertionError('Missing guard: '+name)
        target = root/'cases'/plan['specs'][0]['id']
        reject('existing case must not be overwritten', lambda: batch.write_case(target, protocol, encoded(protocol), receipts[-1], {}, {}))
        reject('previous execution requires acknowledgement', lambda: batch.run(target))
        with patch.object(batch.monitor, 'processes', return_value=[]), patch.object(batch.monitor, 'match_workers', return_value={0:[{'pid':123}]}):
            reject('active writer prevents case reads', lambda: batch.stage(root/'protocol.json', plan['specs'][0]['id'], root/'unsafe'))
        first = root/'cases'/receipts[0]['case']
        data = (first/'case.json').read_bytes()
        (first/'case.json').write_bytes(data+b' ')
        reject('changed prepared receipt', lambda: batch.case_data(first))
        (first/'case.json').write_bytes(data)
        path = next((root/'cases').rglob('root-000.json'))
        saved = path.read_bytes()
        changed = json.loads(saved)
        changed['factual_owner'] = 'not the original owner'
        path.write_bytes(encoded(changed))
        reject('changed cached owner', lambda: batch.cache_entries(path.parent))
        path.write_bytes(saved)
        reject('missing nonloss or loss case at final reconciliation', lambda: validated_files(archive, receipts[:-1], [], original_manifest['probe_sha256'], driver.validate))
        with patch.object(batch.monitor, 'processes', return_value=[]):
            reject('handoff after final driver started', lambda: batch.install(archive, final, case_roots))
    proof = dict(created=datetime.now(timezone.utc).isoformat(),
        completed_historical_cases=10, completed_historical_executions=20, actual_steps=2560,
        audited_prepared_cases=10, final_byte_exact_diagnostics=72,
        unchanged_final_preparer_driver_collector=True, exact_original_forecast_controls=12,
        reversed_case_order=True, new_worlds=0, new_diagnostics=0,
        runtime_measurement=False, prospective_registration=False, current_live_sources_changed=False,
        rejection_checks=rejected, adoption=False,
        source_proof_sha256=sha((archive/'verification.json').read_bytes()),
        diagnostic_proof_sha256=sha((original/'verification.json').read_bytes()),
        hashes={name:sha((here/name).read_bytes()) for name in ('confirmation_case_batch.py',
            'confirmation_loss_resolver.py','confirmation_diagnostic_cache.py','qualify_confirmation_case_batch.py')},
        limits=['Only offline historical execution plumbing is qualified; no quality or speedup claim.',
                'A future qualifying candidate still requires every development gate before independent40.',
                'Register before that future cohort starts. Never apply this execution order retroactively to Q/G/N.'])
    with (here/'confirmation_case_batch_qualification.json').open('x', encoding='utf8') as stream:
        json.dump(proof, stream, indent=2)
    print(json.dumps(proof))
