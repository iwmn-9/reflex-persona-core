"""Prospective finite case diagnostics; no watcher and no early acceptance.

Register this execution order BEFORE starting a future confirmation cohort.
Stage only a complete, inactive, audited case, including every original control.
Run a bounded batch in spare local CPU slots. Final full-archive reconciliation,
the original full driver and collector remain mandatory.
"""
import argparse
from contextlib import ExitStack
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import uuid

import confirmation_loss_resolver as resolver
from confirmation_diagnostic_cache import encoded, sha, validated_files
import snapshot_registered_queues as monitor


def read(path):
    return json.loads(Path(path).read_bytes())


def bound_file(path):
    path = Path(path).resolve()
    return dict(path=str(path), sha256=sha(path.read_bytes()))


def check_file(binding):
    path = Path(binding['path'])
    if sha(path.read_bytes()) != binding['sha256']:
        raise ValueError('Changed registered execution file: '+str(path))
    return path


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_source(manifest, plan_path):
    source = Path(manifest['jobs'][0]['source'])
    sys.path.insert(0, str(source))
    from tools.run_adverse_recovery import verify_registration
    bound = verify_registration(plan_path)
    if any(job['registration'] != bound or Path(job['source']) != source
           or Path(job['plan']) != plan_path for job in manifest['jobs']):
        raise ValueError('One unchanged scientific source and full registration required')
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
    if head != manifest['source_ref']:
        raise ValueError('Scientific source commit changed')
    return source, bound


def register(queue, driver, probe, powershell, output):
    queue, output = Path(queue).resolve(), Path(output).resolve()
    if output.exists():
        raise FileExistsError('Never replace a registered execution protocol')
    manifest_path = queue/'manifest.json'
    manifest = read(manifest_path)
    plan_path = Path(manifest['jobs'][0]['plan'])
    plan = read(plan_path)
    os.environ.update(plan['arithmetic'])
    source, registration = verify_source(manifest, plan_path)
    from tools.archive_adverse_confirmation import validate_plan
    validate_plan(plan)
    refs = resolver.references(plan)
    if len(plan['specs']) != 40 or set(refs) != {'original16', 'stable'}:
        raise ValueError('The full reserved forty and both original controls are required')
    expected = {(spec['id'], arm) for spec in plan['specs'] for arm in plan['arms']}
    actual = [(job['spec']['id'], job['arm']) for job in manifest['jobs']]
    if len(actual) != len(expected) or set(actual) != expected:
        raise ValueError('All 120 original executions exactly once required')
    review = read(queue/'review.json')
    if (sha((queue/'review.json').read_bytes()) != manifest['all_loss_persona_review_sha256']
            or not review['complete'] or review['conclusion'] != 'proceed_to_reserved_confirmation'
            or not review['personality_review_complete'] or review['known_adoption_blocker']):
        raise ValueError('Retain the prerequisite scientific review')
    # No job, even a completed one, may precede this execution-order registration.
    if monitor.match_workers(monitor.processes(powershell), manifest_path):
        raise ValueError('Register before world workers start')
    if any(Path(job['output']).exists() for job in manifest['jobs']):
        raise ValueError('A world output already exists; do not register retroactively')
    files = {name: bound_file(path) for name, path in dict(
        module=__file__, resolver=resolver.__file__,
        cache=Path(__file__).with_name('confirmation_diagnostic_cache.py'),
        monitor=monitor.__file__, driver=driver, probe=probe,
        manifest=manifest_path, plan=plan_path,
        source_registration=plan_path.parent/'registration.json').items()}
    protocol = dict(version='casewise-confirmation-execution-1',
        registered_at=datetime.now(timezone.utc).isoformat(),
        queue=str(queue), source_ref=manifest['source_ref'], registration=registration,
        files=files, powershell=str(Path(powershell).resolve()),
        order='Complete inactive cases may be diagnosed in any order, in spare local CPU slots.',
        roots='All negative score/conditional/reference_choice contrasts against both controls; first action divergence and worst 32-turn realized-gain phase.',
        banks=[dict(start=start, samples=count) for start in (701, 9101, 9201) for count in (3, 8)],
        final='Reconcile every case including nonlosses against the complete original archive; run unchanged full driver and collector before scientific review.',
        recurring=False, cohort_complete=False, adoption=False)
    with output.open('xb') as stream:
        stream.write(encoded(protocol))
    return protocol


def protocol_data(path):
    raw = Path(path).read_bytes()
    protocol = json.loads(raw)
    for binding in protocol['files'].values():
        check_file(binding)
    if (protocol['version'] != 'casewise-confirmation-execution-1'
            or protocol['adoption'] or protocol['cohort_complete'] or protocol['recurring']):
        raise ValueError('An explicitly prospective casewise protocol is required')
    manifest = read(protocol['files']['manifest']['path'])
    plan_path = Path(protocol['files']['plan']['path'])
    plan = read(plan_path)
    os.environ.update(plan['arithmetic'])
    source, registration = verify_source(manifest, plan_path)
    if registration != protocol['registration'] or manifest['source_ref'] != protocol['source_ref']:
        raise ValueError('Different scientific registration')
    return protocol, raw, manifest, plan, source


def write_case(output, protocol, protocol_raw, receipt, results, audits):
    """Atomic preparation from verified inputs. Does not execute a probe."""
    output = Path(output).resolve()
    if output.exists():
        raise FileExistsError('Retain the original prepared case')
    if receipt['registration'] != protocol['registration'] or receipt['source_ref'] != protocol['source_ref']:
        raise ValueError('Case source differs from protocol')
    if set(results) != set(receipt['source_results']) or set(audits) != set(results):
        raise ValueError('Every audited original arm required')
    for arm, raw in results.items():
        audit = audits[arm]
        if sha(raw) != receipt['source_results'][arm] or not audit['complete'] or audit['actual_steps'] != receipt['spec']['turns']:
            raise ValueError('Incomplete or changed case input')
    staging = output.parent/('.case-'+uuid.uuid4().hex[:10])
    staging.mkdir(parents=True)
    blobs = {'protocol.json': protocol_raw, 'case.json': encoded(receipt), 'audits.json': encoded(audits)}
    blobs.update({'inputs/'+arm+'.json': raw for arm, raw in results.items()})
    for name, raw in blobs.items():
        target = staging/name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    prepared = dict(protocol_sha256=sha(protocol_raw), files={n: sha(r) for n, r in blobs.items()},
        case=receipt['case'], evaluations_required=len(receipt['jobs']),
        complete_case=True, cohort_complete=False, adoption=False, executed=False)
    (staging/'prepared.json').write_bytes(encoded(prepared))
    staging.rename(output)
    return prepared


def stage(protocol_path, case, output):
    protocol, raw, manifest, plan, source = protocol_data(protocol_path)
    manifest_path = protocol['files']['manifest']['path']
    jobs = [(i, j) for i, j in enumerate(manifest['jobs']) if j['spec']['id'] == case]
    if len(jobs) != len(plan['arms']) or {j['arm'] for i, j in jobs} != set(plan['arms']):
        raise ValueError('Every original arm in this case required')
    active = monitor.match_workers(monitor.processes(protocol['powershell']), manifest_path)
    if any(i in active for i, j in jobs):
        raise ValueError('Do not open a running case history')
    from tools.adverse_segment import audit
    from tools.analyze_adverse_results import account_pair
    results, audits, bound_files = {}, {}, {}
    spec = jobs[0][1]['spec']
    for index, job in jobs:
        folder = Path(job['output'])
        audits[job['arm']] = audit(folder, spec, job['arm'], protocol['registration'])
        if not audits[job['arm']]['complete']:
            raise ValueError('Wait for every original case execution to finish')
        results[job['arm']] = (folder/'result.json').read_bytes()
        for name in ('checkpoint.json', 'result.json', 'status.json'):
            bound_files[str(folder/name)] = sha((folder/name).read_bytes())
    parsed = {arm: json.loads(data) for arm, data in results.items()}
    candidate = parsed[plan['candidate_arm']]
    outcomes = {}
    for ref in resolver.references(plan):
        control = parsed[ref]
        if control['runtime'] != candidate['runtime'] or [r['response'] for r in control['trace']] != [r['response'] for r in candidate['trace']]:
            raise ValueError('The actual runtime or observed world sequence differs')
        outcomes[ref] = account_pair(spec, control, candidate)
    receipt = resolver.resolve_case(plan, protocol['registration'], protocol['source_ref'], spec, results, outcomes)
    verify_source(manifest, Path(protocol['files']['plan']['path']))
    if any(sha(Path(path).read_bytes()) != checksum for path, checksum in bound_files.items()):
        raise ValueError('A factual case changed during preparation')
    active = monitor.match_workers(monitor.processes(protocol['powershell']), manifest_path)
    if any(i in active for i, j in jobs):
        raise ValueError('A case writer appeared during preparation')
    return write_case(output, protocol, raw, receipt, results, audits)


def case_data(root):
    root = Path(root).resolve()
    prepared = read(root/'prepared.json')
    for name, expected in prepared['files'].items():
        if sha((root/name).read_bytes()) != expected:
            raise ValueError('Prepared case changed: '+name)
    protocol, _, _, plan, source = protocol_data(root/'protocol.json')
    receipt = read(root/'case.json')
    results = {arm: (root/'inputs'/f'{arm}.json').read_bytes() for arm in plan['arms']}
    rebuilt = resolver.resolve_case(plan, protocol['registration'], protocol['source_ref'], receipt['spec'], results, receipt['outcomes'])
    if rebuilt != receipt:
        raise ValueError('Prepared diagnostic recipe differs')
    driver = load_module(protocol['files']['driver']['path'], 'unchanged_full_diagnostic_driver')
    return root, protocol, receipt, results, driver


def run(root, workers=1, acknowledge_interruption=None):
    if type(workers) is not int or not 1 <= workers <= 4:
        raise ValueError('Use one to four spare local CPU slots')
    root, protocol, receipt, results, driver = case_data(root)
    candidate = read(protocol['files']['plan']['path'])['candidate_arm']
    original = json.loads(results[candidate])
    status_path = root/'batch_status.json'
    with driver.exclusive(root/'batch.lock'):
        if status_path.exists() and sha(status_path.read_bytes()) != acknowledge_interruption:
            raise RuntimeError('Inspect prior batch children and acknowledge the exact status before resuming')
        status = dict(pid=os.getpid(), state='running', completed=0, required=len(receipt['jobs']),
                      cohort_complete=False, adoption=False, workers=workers)
        driver.save(status_path, status)
        def evaluate(index, job):
            output = root/f'root-{index:03}.json'
            if not output.exists():
                args = [sys.executable, protocol['files']['probe']['path'],
                    '--worker', read(protocol['files']['manifest']['path'])['jobs'][0]['source'],
                    '--plan', protocol['files']['plan']['path'], '--input', str(root/'inputs'/f'{candidate}.json'),
                    '--input-sha256', job['input_sha256'], '--tick', str(job['tick']),
                    '--start', str(job['start']), '--samples', str(job['samples']), '--output', str(output)]
                with (root/'execution.stdout.log').open('ab') as out, (root/'execution.stderr.log').open('ab') as err:
                    child = subprocess.Popen(args, stdout=out, stderr=err,
                        creationflags=(subprocess.CREATE_NO_WINDOW | subprocess.NORMAL_PRIORITY_CLASS) if os.name == 'nt' else 0)
                    print(json.dumps(dict(case=receipt['case'], job=index, child_pid=child.pid)), flush=True)
                    code = child.wait()
                if code:
                    raise subprocess.CalledProcessError(code, args)
            driver.validate(job, read(output), original, protocol['registration'], protocol['files']['probe']['sha256'])
            return dict(index=index, file=output.name, sha256=sha(output.read_bytes()))
        rows, pending, next_index = [], set(), 0
        pool = ThreadPoolExecutor(max_workers=workers)
        try:
            while next_index < len(receipt['jobs']) or pending:
                while next_index < len(receipt['jobs']) and len(pending) < workers:
                    pending.add(pool.submit(evaluate, next_index, receipt['jobs'][next_index]))
                    next_index += 1
                done, pending = wait(pending, timeout=1, return_when=FIRST_COMPLETED)
                for future in done:
                    rows.append(future.result())
                status['completed'] = len(rows)
                driver.save(status_path, status)
            case_data(root)  # Recheck frozen source, recipe and factual bytes.
            status.update(state='complete_case_diagnostics', rows=sorted(rows, key=lambda r: r['index']))
        except BaseException as error:
            status.update(state='failed', error=repr(error))
            for future in pending:
                future.cancel()
            raise
        finally:
            pool.shutdown(wait=True, cancel_futures=True)
            driver.save(status_path, status)
    return status


def cache_entries(root):
    """Read after the finite case batch exits; final handoff revalidates again."""
    root, protocol, receipt, results, driver = case_data(root)
    original = json.loads(results[read(protocol['files']['plan']['path'])['candidate_arm']])
    entries = []
    for index, job in enumerate(receipt['jobs']):
        path = root/f'root-{index:03}.json'
        if not path.exists():
            continue  # The final full driver must compute every missing entry.
        data = path.read_bytes()
        driver.validate(job, json.loads(data), original, protocol['registration'], protocol['files']['probe']['sha256'])
        entries.append(dict(bytes=data, origin=dict(result_sha256=sha(data),
            probe_sha256=protocol['files']['probe']['sha256'],
            recipe_sha256=protocol['files']['resolver']['sha256'], source_ref=protocol['source_ref'],
            registration=protocol['registration'], case_receipt_sha256=sha(encoded(receipt)),
            execution_protocol_sha256=sha((root/'protocol.json').read_bytes()))))
    return receipt, entries


def install(archive, execution, cases):
    """Install verified original bytes before the unchanged final driver starts."""
    execution = Path(execution).resolve()
    cases = [Path(path).resolve() for path in cases]
    if not cases or len(set(cases)) != len(cases):
        raise ValueError('Distinct prepared cases required')
    protocol, protocol_raw, _, _, _ = protocol_data(cases[0]/'protocol.json')
    driver = load_module(protocol['files']['driver']['path'], 'unchanged_final_diagnostic_driver')
    # An orphan probe can outlive a killed parent and its file lock. Reject
    # any such writer independently, using the exact registered output path.
    processes = monitor.processes(protocol['powershell'])
    for process in processes:
        args = monitor.argv(process['CommandLine']) if process.get('CommandLine') else []
        if '--output' in args:
            path = Path(args[args.index('--output')+1]).resolve()
            if any(path.is_relative_to(case) for case in cases):
                raise ValueError('A case probe still writes outputs')
    with ExitStack() as locks:
        locks.enter_context(driver.exclusive(execution/'queue.lock'))
        for case in sorted(cases):
            locks.enter_context(driver.exclusive(case/'batch.lock'))
        if (execution/'status.json').exists() or (execution/'casewise_handoff.json').exists():
            raise ValueError('Install once, before the final diagnostic driver starts')
        manifest = read(execution/'manifest.json')
        plan = resolver.prepare(archive)
        if (read(execution/'plan.json') != plan
                or sha((execution/'plan.json').read_bytes()) != manifest['plan_sha256']
                or manifest['source_ref'] != protocol['source_ref']
                or manifest['driver_sha256'] != protocol['files']['driver']['sha256']
                or manifest['probe_sha256'] != protocol['files']['probe']['sha256']
                or sha((execution/'driver.py').read_bytes()) != manifest['driver_sha256']
                or sha((execution/'probe_registered_owner.py').read_bytes()) != manifest['probe_sha256']
                or sha((execution/'resolver.py').read_bytes()) != protocol['files']['resolver']['sha256']):
            raise ValueError('The unchanged final preparation differs from this execution protocol')
        receipts, cached = [], []
        for case in cases:
            if (case/'protocol.json').read_bytes() != protocol_raw:
                raise ValueError('All cases must share the original prospective protocol')
            receipt, entries = cache_entries(case)
            receipts.append(receipt)
            cached.extend(entries)
        files, proof = validated_files(archive, receipts, cached, manifest['probe_sha256'], driver.validate)
        for name, data in files.items():
            target = execution/name
            if target.exists() and target.read_bytes() != data:
                raise ValueError('Never replace a different final diagnostic output')
        # Every reconciliation and byte check has passed before the first write.
        for name, data in files.items():
            target = execution/name
            if not target.exists():
                with target.open('xb') as stream:
                    stream.write(data)
        proof.update(protocol_sha256=sha(protocol_raw),
                     case_receipts=sorted(receipts, key=lambda r: r['case']))
        (execution/'casewise_protocol.json').write_bytes(protocol_raw)
        with (execution/'casewise_handoff.json').open('xb') as stream:
            stream.write(encoded(proof))
    return proof


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    reg = sub.add_parser('register')
    for key in ('queue', 'driver', 'probe', 'powershell', 'output'):
        reg.add_argument('--'+key, required=True)
    stage_parser = sub.add_parser('stage')
    for key in ('protocol-path', 'case', 'output'):
        stage_parser.add_argument('--'+key, required=True)
    execute = sub.add_parser('run')
    execute.add_argument('--root', required=True)
    execute.add_argument('--workers', type=int, default=1)
    execute.add_argument('--acknowledge-interruption')
    installer = sub.add_parser('install')
    installer.add_argument('--archive', required=True)
    installer.add_argument('--execution', required=True)
    installer.add_argument('--cases', nargs='+', required=True)
    args = vars(p.parse_args())
    command = args.pop('command')
    result = {'register': register, 'stage': stage, 'run': run, 'install': install}[command](**args)
    print(json.dumps(result), flush=True)
