"""Self-contained future confirmation loss recipe, for both original controls.

Complete cases may be resolved in any order. Final acceptance still resolves
again from the COMPLETE frozen archive. All adverse contrasts remain explicit;
only identical diagnostic computations (same candidate history/root/bank) are
shared. This changes neither NPC behavior nor scientific acceptance criteria.
Current live studies do not use this prospective operational module.
"""
import gzip
import hashlib
import io
import json
from pathlib import Path
import zipfile


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def references(plan):
    candidate=plan['candidate_arm']
    arms=plan['arms']
    if len(arms)!=len(set(arms)) or candidate not in arms or len(arms)<2:
        raise ValueError('One candidate and distinct controls required')
    return tuple(arm for arm in arms if arm!=candidate)


def resolve_case(plan,registration,source_ref,spec,raw_results,outcomes):
    refs=references(plan);candidate=plan['candidate_arm'];cid=spec['id']
    if (spec not in plan['specs'] or set(raw_results)!=set(plan['arms'])
            or set(outcomes)!=set(refs)):
        raise ValueError('Every registered arm and comparison in the full case required')
    results={}
    for arm,raw in raw_results.items():
        result=json.loads(raw);cfg=result['configuration']
        if (not result['complete'] or result['replayed_actual_steps']!=spec['turns']
                or cfg['spec']!=spec or cfg['arm']!=arm or cfg['registration']!=registration
                or [row['tick'] for row in result['trace']]!=list(range(spec['turns']))):
            raise ValueError('Complete registered factual history required')
        results[arm]=result
    losses=[];unique={};logical=0
    for ref in refs:
        outcome=outcomes[ref]
        if outcome['id']!=cid:
            raise ValueError('Comparison belongs to another case')
        delta=outcome['differences']
        negative={key:delta[key] for key in ('score','conditional','reference_choice')
                  if key in delta and delta[key]<-1e-12}
        if not negative:
            continue
        left,right=results[ref]['trace'],results[candidate]['trace']
        divergence=next((a['tick'] for a,b in zip(left,right) if a['action']!=b['action']),None)
        phase=min(outcome['phases'],key=lambda p:(p['differences']['score_gain'],p['start']))
        roots={phase['start']:['worst_32_turn_realized_gain_phase']}
        if divergence is not None:
            roots.setdefault(divergence,[]).append('first_action_divergence')
        loss=dict(id=cid,losses=negative,roots=[])
        if len(refs)>1:
            loss['reference']=ref
            loss['losses']={ref+':'+key:value for key,value in negative.items()}
        for tick,reasons in sorted(roots.items()):
            if type(tick) is not int or not 0<=tick<spec['turns']:
                raise ValueError('Root must belong to the actual completed history')
            owner=right[tick]['before_owner']
            if len(refs)>1:
                reasons=[ref+':'+reason for reason in reasons]
            loss['roots'].append(dict(tick=tick,reasons=reasons,factual_owner=owner))
            for start in (701,9101,9201):
                for samples in (3,8):
                    job=dict(id=cid,tick=tick,start=start,samples=samples,factual_owner=owner,
                        input_sha256=sha(raw_results[candidate]),reuse=False,
                        input_archive_member=f'{cid}/{candidate}/result.json')
                    key=(tick,start,samples)
                    if key in unique and unique[key]!=job:
                        raise ValueError('Nominally identical diagnostics have different inputs')
                    unique[key]=job;logical+=1
        losses.append(loss)
    return dict(case=cid,spec=spec,registration=registration,source_ref=source_ref,
        source_results={arm:sha(raw) for arm,raw in raw_results.items()},outcomes=outcomes,
        losses=losses,jobs=[unique[key] for key in sorted(unique)],
        logical_contrast_evaluations=logical,complete_case=True,cohort_complete=False,adoption=False)


def join_cases(plan,registration,source_ref,receipts):
    table={row['case']:row for row in receipts}
    if (len(table)!=len(receipts) or set(table)!={spec['id'] for spec in plan['specs']}):
        raise ValueError('All original cases, including nonlosses, exactly once required')
    losses=[];jobs=[];logical=0
    for spec in plan['specs']:
        receipt=table[spec['id']]
        if (receipt['spec']!=spec or receipt['registration']!=registration or receipt['source_ref']!=source_ref
                or not receipt['complete_case'] or receipt['cohort_complete'] or receipt['adoption']):
            raise ValueError('Changed case identity or unsupported completion claim')
        losses.extend(receipt['losses']);jobs.extend(receipt['jobs'])
        logical+=receipt['logical_contrast_evaluations']
    return losses,jobs,logical


def prepare(archive,previous=None):
    if previous is not None:
        raise ValueError('No substituted prior diagnosis; validate cache only after final reconciliation')
    archive=Path(archive);proof=json.loads((archive/'verification.json').read_bytes())
    if proof['complete'] is not True:
        raise ValueError('Complete original audited archive required')
    blobs={}
    for name in ('plan.json','outcome_review.json','runs.jsonl.gz','checkpoints.zip'):
        raw=(archive/name).read_bytes()
        if sha(raw)!=proof['artifacts'][name]:
            raise ValueError('Audited artifact changed: '+name)
        blobs[name]=raw
    plan=json.loads(blobs['plan.json']);refs=references(plan)
    review=json.loads(blobs['outcome_review.json'])
    if review['complete'] is not True:
        raise ValueError('Complete outcome review required')
    if 'comparisons' in review:
        comparisons=review['comparisons']
        if set(comparisons)!=set(refs):
            raise ValueError('Every original control comparison required')
    elif len(refs)==1 and plan['reference_arm']==refs[0]:
        comparisons={refs[0]:review}
    else:
        raise ValueError('Missing comparisons in multi-control confirmation')
    rows=[json.loads(line) for line in gzip.decompress(blobs['runs.jsonl.gz']).splitlines()]
    records={(row['spec']['id'],row['arm']):row for row in rows}
    expected={(spec['id'],arm) for spec in plan['specs'] for arm in plan['arms']}
    if len(records)!=len(rows) or set(records)!=expected:
        raise ValueError('All registered executions exactly once required')
    if (proof['pairs']!=len(plan['specs']) or proof['executions']!=len(rows)
            or proof['actual_steps']!=sum(len(row['result']['trace']) for row in rows)):
        raise ValueError('Whole study completion counts differ')
    maps={}
    for ref,comparison in comparisons.items():
        table={row['id']:row for row in comparison['rows']}
        if (not comparison['complete'] or len(table)!=len(comparison['rows'])
                or set(table)!={spec['id'] for spec in plan['specs']}):
            raise ValueError('Every case under every original control required')
        maps[ref]=table
    receipts=[]
    with zipfile.ZipFile(io.BytesIO(blobs['checkpoints.zip'])) as packed:
        for spec in plan['specs']:
            cid=spec['id'];raw_results={}
            for arm in plan['arms']:
                row=records[cid,arm];raw=packed.read(f'{cid}/{arm}/result.json')
                if row['spec']!=spec or json.loads(raw)!=row['result']:
                    raise ValueError('Runs and checkpoint archive differ')
                if any(sha(raw)!=comparison['source_results'][f'adverse-{cid}-{arm}']
                       for comparison in comparisons.values()):
                    raise ValueError('Comparison used different factual result bytes')
                raw_results[arm]=raw
            receipts.append(resolve_case(plan,proof['registration'],proof['source_ref'],spec,
                raw_results,{ref:maps[ref][cid] for ref in refs}))
    losses,jobs,logical=join_cases(plan,proof['registration'],proof['source_ref'],receipts)
    return dict(complete_archive=True,adoption=False,candidate=plan['candidate_arm'],
        source_ref=proof['source_ref'],registration=proof['registration'],
        archive=str(archive.resolve()),inputs={name:sha(raw) for name,raw in blobs.items()},
        prior_diagnosis=None,losses=losses,jobs=jobs,required_evaluations=len(jobs),
        reused_evaluations=0,pending_evaluations=len(jobs),logical_contrast_evaluations=logical,
        references=list(refs),resolver_sha256=sha(Path(__file__).read_bytes()),
        scope='All original control losses retained. Only byte-identical candidate/root/model-bank computations are shared; no source, persona, world, root or acceptance reduction.')


def reconcile(archive,receipts):
    full=prepare(archive,None)
    archive=Path(archive);plan=json.loads((archive/'plan.json').read_bytes())
    review=json.loads((archive/'outcome_review.json').read_bytes())
    refs=references(plan)
    comparisons=review.get('comparisons',{refs[0]:review})
    outcomes={ref:{row['id']:row for row in comparison['rows']}
              for ref,comparison in comparisons.items()}
    losses,jobs,logical=join_cases(plan,full['registration'],full['source_ref'],receipts)
    if losses!=full['losses'] or jobs!=full['jobs'] or logical!=full['logical_contrast_evaluations']:
        raise ValueError('Casewise roots differ from complete-archive authority')
    table={row['case']:row for row in receipts}
    with zipfile.ZipFile(archive/'checkpoints.zip') as packed:
        for spec in plan['specs']:
            cid=spec['id']
            raw={arm:packed.read(f'{cid}/{arm}/result.json') for arm in plan['arms']}
            rebuilt=resolve_case(plan,full['registration'],full['source_ref'],spec,raw,
                {ref:outcomes[ref][cid] for ref in refs})
            if rebuilt!=table[cid]:
                raise ValueError('Casewise receipt does not match complete archived bytes/outcomes')
    return full
