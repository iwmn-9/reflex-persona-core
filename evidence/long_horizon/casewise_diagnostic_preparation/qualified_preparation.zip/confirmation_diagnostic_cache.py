"""Pure final handoff for the prospective all-control diagnostic recipe.

Validate everything before returning any output bytes. Never write to a live
queue, launch science, alter the full root plan, or count cached work twice.
The caller starts the unchanged full driver after installing these exact bytes;
that driver and its collector still revalidate every required result.
"""
import hashlib
import json
from pathlib import Path
import zipfile
import confirmation_loss_resolver as resolver


def encoded(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def validated_files(archive,case_receipts,cached,probe_sha256,validate):
    full=resolver.reconcile(archive,case_receipts)
    jobs=full['jobs'];receipts={row['case']:row for row in case_receipts}
    wanted={(job['id'],job['tick'],tuple(range(job['start'],job['start']+job['samples']))):(index,job)
            for index,job in enumerate(jobs)}
    if len(wanted)!=len(jobs):
        raise ValueError('Duplicate final physical computation')
    recipe_sha256=sha(Path(resolver.__file__).read_bytes())
    files={};rows=[];seen=set()
    with zipfile.ZipFile(Path(archive)/'checkpoints.zip') as packed:
        for entry in cached:
            data,origin=entry['bytes'],entry['origin'];result=json.loads(data)
            key=(result['id'],result['tick'],tuple(result['seeds']))
            if key not in wanted or key in seen:
                raise ValueError('Unregistered or duplicate cached diagnosis')
            seen.add(key);index,job=wanted[key]
            if (origin['result_sha256']!=sha(data) or origin['probe_sha256']!=probe_sha256
                    or origin['recipe_sha256']!=recipe_sha256
                    or origin['source_ref']!=full['source_ref']
                    or origin['registration']!=full['registration']
                    or origin['case_receipt_sha256']!=sha(encoded(receipts[job['id']]))):
                raise ValueError('Cached diagnostic provenance differs')
            original_bytes=packed.read(job['input_archive_member'])
            if sha(original_bytes)!=job['input_sha256']:
                raise ValueError('Candidate factual history changed')
            validate(job,result,json.loads(original_bytes),full['registration'],probe_sha256)
            name=f'root-{index:03}.json';files[name]=data
            rows.append(dict(file=name,job=job,sha256=sha(data),origin=origin))
    return files,dict(required=len(jobs),verified_cached=len(files),remaining_required=len(jobs)-len(files),
        logical_contrast_evaluations=full['logical_contrast_evaluations'],
        full_plan_sha256=sha(encoded(full)),rows=sorted(rows,key=lambda row:row['file']),
        complete=False,adoption=False,new_worlds=0,new_diagnostic_runs=0,
        limits='This is a validated handoff, not completed diagnosis. Every remaining computation and all original final driver/collector checks are mandatory.')
