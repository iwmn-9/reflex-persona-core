"""Actual completed diagnostic bytes through the prospective final handoff."""
import copy
from datetime import datetime,timezone
import importlib.util
import json
from pathlib import Path
import zipfile
import confirmation_loss_resolver as resolver
from confirmation_diagnostic_cache import encoded,sha,validated_files


if __name__=='__main__':
    here=Path(__file__).resolve().parent;base=here.parents[2]
    archive=base/'reflex-persona-consistent-reading/evidence/long_horizon/consistent_horizon/completed_local'
    execution=here/'consistent_loss_roots_20261031'
    manifest=json.loads((execution/'manifest.json').read_bytes())
    proof=json.loads((execution/'verification.json').read_bytes())
    assert proof['complete'] and proof['sources']==manifest
    assert sha((execution/'driver.py').read_bytes())==manifest['driver_sha256']
    assert sha((execution/'probe_registered_owner.py').read_bytes())==manifest['probe_sha256']
    spec=importlib.util.spec_from_file_location('unchanged_driver',execution/'driver.py')
    driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
    full=resolver.prepare(archive,None)
    assert full['jobs']==json.loads((execution/'plan.json').read_bytes())['jobs']
    plan=json.loads((archive/'plan.json').read_bytes())
    review=json.loads((archive/'outcome_review.json').read_bytes())
    outcomes={row['id']:row for row in review['rows']};receipts=[]
    with zipfile.ZipFile(archive/'checkpoints.zip') as packed:
        for case in reversed(plan['specs']):
            raw={arm:packed.read(f"{case['id']}/{arm}/result.json") for arm in plan['arms']}
            receipts.append(resolver.resolve_case(plan,full['registration'],full['source_ref'],case,raw,
                {plan['reference_arm']:outcomes[case['id']]}))
    by_id={row['case']:row for row in receipts};cached=[]
    for record in proof['rows']:
        data=(execution/record['file']).read_bytes();assert sha(data)==record['sha256']
        row=json.loads(data)
        cached.append(dict(bytes=data,origin=dict(result_sha256=sha(data),probe_sha256=manifest['probe_sha256'],
            recipe_sha256=sha(Path(resolver.__file__).read_bytes()),source_ref=full['source_ref'],
            registration=full['registration'],case_receipt_sha256=sha(encoded(by_id[row['id']])),
            fixture='Retrospective original completed diagnosis, not a precomputed future trial')))
    def handoff(entries,case_rows=receipts):
        return validated_files(archive,case_rows,entries,manifest['probe_sha256'],driver.validate)
    files,result=handoff(list(reversed(cached)))
    assert len(files)==72 and all(data==(execution/name).read_bytes() for name,data in files.items())
    _,half=handoff(cached[::2]);_,empty=handoff([])
    assert (half['verified_cached'],half['remaining_required'],empty['remaining_required'])==(36,36,72)
    rejected=[]
    def reject(name,call):
        try:call()
        except (ValueError,AssertionError):rejected.append(name)
        else:raise AssertionError('Missing rejection: '+name)
    reject('duplicate cached diagnosis',lambda:handoff(cached+[cached[0]]))
    reject('incomplete case universe',lambda:handoff([],receipts[:-1]))
    for key in ('recipe_sha256','probe_sha256','source_ref','case_receipt_sha256','result_sha256','registration'):
        bad=copy.deepcopy(cached[:1]);bad[0]['origin'][key]='changed'
        reject('changed '+key,lambda bad=bad:handoff(bad))
    bad=copy.deepcopy(cached[:1]);row=json.loads(bad[0]['bytes']);row['factual_owner']='changed'
    bad[0]['bytes']=encoded(row);bad[0]['origin']['result_sha256']=sha(bad[0]['bytes'])
    reject('changed factual owner with matching outer hash',lambda:handoff(bad))
    record=dict(created=datetime.now(timezone.utc).isoformat(),actual_prior_diagnostic_bytes_exact=72,
        partial_cache=dict(verified=36,still_required=36),empty_cache_still_required=72,
        rejection_checks=rejected,current_live_studies_changed=False,new_scientific_executions=0,
        future_scheduler_implemented=False,future_protocol_registered=False,adoption=False,
        hashes={name:sha((here/name).read_bytes()) for name in ('confirmation_loss_resolver.py',
            'confirmation_diagnostic_cache.py','qualify_confirmation_diagnostic_cache.py')},
        source_proof_sha256=sha((execution/'verification.json').read_bytes()),
        limits=['Actual historical diagnostic outputs only; not new outcome evidence or measured acceleration.',
                'A future casewise execution protocol must be fixed before starting its new world study.',
                'The final full driver and collector still verify every required physical diagnostic and every adverse control contrast.'])
    with (here/'confirmation_diagnostic_cache_qualification.json').open('x',encoding='utf8') as stream:
        json.dump(record,stream,indent=2)
    print(json.dumps(dict(exact=72,partial_remaining=36,rejections=len(rejected))))
