"""Actual one-control archive parity plus synthetic multi-control contracts."""
import copy
from datetime import datetime,timezone
import gzip
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import zipfile
import confirmation_loss_resolver as candidate


def encoded(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def module(path):
    spec=importlib.util.spec_from_file_location('original_resolver',path)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result)
    return result


def synthetic(root,*,stable_loss=True,omit_reference=False,partial=False):
    """Only structural test fixtures; not simulated NPC or scientific results."""
    spec=dict(id='fixture',turns=8)
    plan=dict(specs=[spec],arms=['original16','stable','candidate'],
              reference_arm='stable',candidate_arm='candidate')
    registration=dict(plan_sha256='synthetic',source_sha256='synthetic')
    actions={'original16':['a']*8,'stable':['a','b','a','a','a','a','a','a'],
             'candidate':['a','b','a','b','a','a','a','a']}
    raw={};records=[]
    for arm in plan['arms']:
        result=dict(complete=not partial,replayed_actual_steps=8,
            configuration=dict(spec=spec,arm=arm,registration=registration),
            trace=[dict(tick=tick,action=action,before_owner=f'fixture-owner-{tick}')
                   for tick,action in enumerate(actions[arm])])
        raw[arm]=encoded(result);records.append(dict(spec=spec,arm=arm,result=result))
    hashes={f'adv erse-fixture-{arm}'.replace('adv erse','adverse'):candidate.sha(data) for arm,data in raw.items()}
    comparisons={}
    for ref in ('original16','stable'):
        if ref=='original16' and omit_reference:continue
        loss=not(ref=='stable' and not stable_loss)
        outcome=dict(id='fixture',differences=dict(score=-1. if loss else 1.,conditional=0.,reference_choice=0.),
            phases=[dict(start=0,differences=dict(score_gain=0.)),dict(start=4,differences=dict(score_gain=-1.))])
        comparisons[ref]=dict(complete=True,rows=[outcome],source_results=hashes)
    zipped=io.BytesIO()
    with zipfile.ZipFile(zipped,'w') as packed:
        for arm,data in raw.items():packed.writestr(f'fixture/{arm}/result.json',data)
    blobs={'plan.json':encoded(plan),'outcome_review.json':encoded(dict(complete=True,comparisons=comparisons)),
           'runs.jsonl.gz':gzip.compress(b'\n'.join(encoded(row) for row in records)),
           'checkpoints.zip':zipped.getvalue()}
    proof=dict(complete=True,pairs=1,executions=3,actual_steps=24,source_ref='synthetic-only',
               registration=registration,artifacts={name:candidate.sha(data) for name,data in blobs.items()})
    root.mkdir()
    for name,data in blobs.items():(root/name).write_bytes(data)
    (root/'verification.json').write_bytes(encoded(proof))
    return plan,registration,raw,{ref:comparison['rows'][0] for ref,comparison in comparisons.items()}


if __name__=='__main__':
    here=Path(__file__).resolve().parent;base=here.parents[2]
    archive=base/'reflex-persona-consistent-reading/evidence/long_horizon/consistent_horizon/completed_local'
    original=base/'reflex-persona-core/evidence/long_horizon/adverse_sample_budget/loss_root_resolver.py'
    assert candidate.sha(original.read_bytes())=='16e0b551c75e1105bf3a7173d17e8869a765b2a075d31392d5763cf41f670c3a'
    expected=module(original).prepare(archive,None);actual=candidate.prepare(archive,None)
    assert actual['jobs']==expected['jobs'] and actual['losses']==expected['losses']
    assert len(actual['jobs'])==72
    plan=json.loads((archive/'plan.json').read_bytes())
    review=json.loads((archive/'outcome_review.json').read_bytes())
    outcomes={row['id']:row for row in review['rows']};receipts=[]
    with zipfile.ZipFile(archive/'checkpoints.zip') as packed:
        for spec in reversed(plan['specs']):
            raw={arm:packed.read(f"{spec['id']}/{arm}/result.json") for arm in plan['arms']}
            receipts.append(candidate.resolve_case(plan,actual['registration'],actual['source_ref'],spec,raw,
                {plan['reference_arm']:outcomes[spec['id']]}))
    assert candidate.reconcile(archive,receipts)==actual
    rejected=[]
    def reject(name,call):
        try:call()
        except ValueError:rejected.append(name)
        else:raise AssertionError('Missing rejection: '+name)
    reject('missing case',lambda:candidate.reconcile(archive,receipts[:-1]))
    reject('duplicate case',lambda:candidate.reconcile(archive,receipts+[receipts[0]]))
    bad=copy.deepcopy(receipts);bad[0]['source_results'][plan['candidate_arm']]='different'
    reject('changed case bytes',lambda:candidate.reconcile(archive,bad))
    with tempfile.TemporaryDirectory() as directory:
        root=Path(directory)
        p,reg,raw,outcomes=synthetic(root/'both')
        combined=candidate.prepare(root/'both',None)
        assert len(combined['losses'])==2 and combined['logical_contrast_evaluations']==24
        assert len(combined['jobs'])==18 and {job['tick'] for job in combined['jobs']}=={1,3,4}
        assert {row['reference'] for row in combined['losses']}=={'original16','stable'}
        receipt=candidate.resolve_case(p,reg,'synthetic-only',p['specs'][0],raw,outcomes)
        assert candidate.reconcile(root/'both',[receipt])==combined
        synthetic(root/'only_original',stable_loss=False)
        one=candidate.prepare(root/'only_original',None)
        assert len(one['losses'])==1 and one['losses'][0]['reference']=='original16' and len(one['jobs'])==12
        synthetic(root/'missing',omit_reference=True)
        reject('missing original16 comparison',lambda:candidate.prepare(root/'missing',None))
        synthetic(root/'partial',partial=True)
        reject('partial case',lambda:candidate.prepare(root/'partial',None))
        altered=copy.deepcopy(receipt);altered['jobs'].pop()
        reject('omitted shared diagnostic',lambda:candidate.reconcile(root/'both',[altered]))
    record=dict(created=datetime.now(timezone.utc).isoformat(),old_actual_cases=10,old_actual_steps=2560,
        exact_old_losses=6,exact_old_diagnostic_jobs=72,reversed_completion_order_exact=True,
        synthetic_multi_control=dict(logical_contrast_evaluations=24,unique_computations=18,
            both_adverse_controls_retained=True,original16_only_loss_retained=True),
        rejection_checks=rejected,new_worlds=0,new_diagnostic_runs=0,current_live_sources_changed=False,
        actual_reserved40_started=False,adoption=False,future_scheduler_implemented=False,
        hashes={str(original):candidate.sha(original.read_bytes()),
                str(archive/'verification.json'):candidate.sha((archive/'verification.json').read_bytes()),
                'confirmation_loss_resolver.py':candidate.sha((here/'confirmation_loss_resolver.py').read_bytes()),
                Path(__file__).name:candidate.sha(Path(__file__).read_bytes())},
        limits=['Historical one-control selection replay and synthetic multi-control validation only.',
                'No real-world speedup or new judgment quality is claimed.',
                'The future scheduler must register this recipe before its world study and still reconcile every diagnosis against the full original archive.'])
    with (here/'confirmation_loss_resolver_qualification.json').open('x',encoding='utf8') as stream:
        json.dump(record,stream,indent=2)
    print(json.dumps(dict(old_jobs_exact=72,synthetic_shared=18,synthetic_logical=24,rejections=len(rejected))))
