from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]

def save(value):
    temporary=HERE/'state.new';temporary.write_text(json.dumps(value,sort_keys=True),encoding='utf8')
    temporary.replace(HERE/'state.json')

def main():
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    assert head.startswith('09def09')
    files=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().strip('\0').split('\0')
    hashes={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in files}
    (HERE/'sources.json').write_text(json.dumps(hashes,sort_keys=True),encoding='utf8')
    state=dict(complete=False,state='running',pid=os.getpid(),source=head,source_files=len(hashes),
               started=datetime.datetime.now(datetime.timezone.utc).isoformat(),adoption=False)
    save(state);start=time.monotonic()
    with (HERE/'tests.stdout.log').open('xb') as out,(HERE/'tests.stderr.log').open('xb') as err:
        child=subprocess.Popen([sys.executable,'-u','-m','unittest','discover','-s','tests','-v'],cwd=ROOT,
            stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        state['child_pid']=child.pid;save(state)
        code=child.wait()
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==head
    assert all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in hashes.items())
    state.update(complete=True,state='passed' if code==0 else 'failed',exit_code=code,
                 elapsed_seconds=time.monotonic()-start,source_unchanged=True,
                 finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save(state)

if __name__=='__main__':
    try:main()
    except BaseException as error:
        previous=json.loads((HERE/'state.json').read_bytes()) if (HERE/'state.json').exists() else {}
        previous.update(complete=False,state='failed',error=repr(error));save(previous);raise
