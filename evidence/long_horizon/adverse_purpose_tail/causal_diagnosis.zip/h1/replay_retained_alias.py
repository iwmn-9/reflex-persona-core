"""Exact replay of one retained hypothetical path before a detached H1 check."""
import copy
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path('/home/ubuntu/recovery/transfer_loss_roots_20261030')
m = json.loads((ROOT / 'manifest.json').read_bytes())
worker = Path(m['worker']); plan = json.loads((worker / m['source_plan']).read_bytes())
os.environ.update(plan['arithmetic'])
os.environ.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
sys.path.insert(0, str(worker))
import numpy as np
from reflex.core import digest, character_key
from reflex.closed_loop import owned_rollout
from reflex.decision_loop import DecisionLoop
from reflex.model_observer import resolve_feedback
from tools.run_adverse_recovery import actor_for, game_for, verify_registration
from tools.run_owned_value import cumulative_basis, law, sample


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    output = ROOT / 'retained_alias_h1.json'
    assert not output.exists()
    diagnostic = json.loads((ROOT / 'future_aliases.json').read_bytes())
    probe = json.loads((ROOT / 'root-030.json').read_bytes())
    job = json.loads((ROOT / 'plan.json').read_bytes())['jobs'][30]
    source = ROOT / 'inputs' / job['input_archive_member']
    assert sha(source) == job['input_sha256']
    original = json.loads(source.read_bytes())
    assert verify_registration(worker / m['source_plan']) == probe['registration']
    spec = original['configuration']['spec']; game = game_for(spec)
    world = game.start(); own = actor_for(game, game.context(world), 'transfer')
    rng = np.random.default_rng(spec['seed'])
    for row in original['trace'][:job['tick']]:
        assert world == row['before'] and digest(own.record()) == row['before_owner']
        result = DecisionLoop.decide_batch([(own, game.request(game.context(world, own.state)))], False,
                                           _counterfactual_roots=(row['action'],))[0]
        assert sample(law(world['tick'], spec['turns'], spec['regime']), rng.random()) == row['response']
        after, flow = game.transition(world, row['action'], row['response'])
        resolve_feedback(own, result['ticket'], game.feedback(world, after, row['action'], result['context'], flow))
        assert after == row['after'] and digest(own.record()) == row['owner']
        world = after
    assert digest(own.record()) == probe['factual_owner']
    axes = character_key(game.context(world))
    options = dict(observe=game.context, events=game.events, terminal=game.terminal,
        assess=lambda w: game.goal(w).record(), record=lambda w: w, request_for=game.request,
        feedback=game.feedback, model_id=game.model_id, target=game.target,
        world_model='posterior', cumulative_preference=cumulative_basis(game, True))
    model = owned_rollout(own, **options, tail_steps=31, seeds=(701,702,703),
                         purpose_estimator='conditional', tail_recovery=2)
    # First existing reflex continuation whose actual first action is the
    # priority root's alternative. This path was identified in the prior receipt.
    proposal = 'candidate-003-reflex'
    retained = diagnostic['modeled'][proposal][0]
    response = model.owner_transitions(copy.deepcopy(world), retained['actions'][0], own,
                                     copy.deepcopy(probe['selection_inputs']['base_context']))[0]
    seed = 701
    for offset, action in enumerate(retained['actions'][:6]):
        request = game.request(game.context(world, own.state))
        context = own._prepare(request)['effective']; model_owner = copy.deepcopy(own)
        result = DecisionLoop.decide_batch([(own, request)], False, _counterfactual_roots=(action,))[0]
        if offset == 0:
            after, flow = copy.deepcopy(response.state), copy.deepcopy(response.flow)
        else:
            outcomes = model.owner_transitions(copy.deepcopy(world), action, model_owner, copy.deepcopy(context))
            u = np.random.default_rng(np.random.SeedSequence([seed, context['tick']])).random()
            mass = 0.; selected = outcomes[-1]
            for outcome in outcomes:
                mass += outcome.probability
                if u < mass:
                    selected = outcome; break
            after, flow = copy.deepcopy(selected.state), copy.deepcopy(selected.flow)
        resolve_feedback(own, result['ticket'], game.feedback(world, after, action, result['context'], flow))
        world = after
    request = game.request(game.context(world, own.state))
    stamp = digest([own.record(), request.context])
    observations = [o for o in diagnostic['observations'] if o['owner_and_context'] == stamp]
    assert len(observations) == 1, ('retained hypothetical owner failed exact reconstruction', stamp)
    observed = observations[0]
    assert world == observed['public']
    baseline = DecisionLoop.decide_batch([(copy.deepcopy(own), copy.deepcopy(request))], False)[0]
    assert baseline['context'] == observed['original_context']
    assert baseline['decision']['action_id'] == observed['original_action']
    trial_owner = copy.deepcopy(own)
    controller = owned_rollout(trial_owner, **options, tail_steps=0, tree_steps=1)
    trial = DecisionLoop.decide_batch([(trial_owner, copy.deepcopy(request))], False,
        controller.planner(trial_owner, copy.deepcopy(request), copy.deepcopy(world)))[0]
    assert character_key(trial['context']) == axes
    probabilities = own.predictor.predict(copy.deepcopy(baseline['context']))
    result = dict(adoption=False, exact_factual_prefix=96, exact_hypothetical_prefix=6,
        original_probe_sha256=sha(ROOT/'root-030.json'), observation_sha256=sha(ROOT/'future_aliases.json'),
        source_sha256=sha(__file__), factual_source_sha256=sha(source),
        registration=probe['registration'], owner_and_context=stamp, hypothetical_owner=own.record(),
        public=world, baseline_action=baseline['decision']['action_id'],
        detached_h1_action=trial['decision']['action_id'], detached_h1=trial.get('deliberation'),
        original_context=baseline['context'], probabilities=probabilities,
        public_goal_distributions={key:[dict(p=probabilities[event.symbol],goal=game.goal(event.public).record())
            for event in game.events(copy.deepcopy(world),key)] for key in game.keys(world)},
        scope='Exact hypothetical-owner reconstruction followed by existing H1 planning on a detached copy. '
              'No original forecast, factual trajectory, personality or acceptance criterion changed.')
    output.write_text(json.dumps(result, sort_keys=True, allow_nan=False), encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('exact_factual_prefix','exact_hypothetical_prefix','baseline_action','detached_h1_action')}))


if __name__ == '__main__':
    main()
