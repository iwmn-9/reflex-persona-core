"""Prepare fresh local paired worlds from the frozen, prerequisite-gated plan."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

V = Path(__file__).resolve().parent
U = V.parents[1]

def encoded(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main(worker, commit, output):
    worker,output=Path(worker).resolve(),Path(output).resolve()
    if output.exists():
        raise FileExistsError('inspect existing queue; never replace a registered execution')
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=worker,text=True).strip()==commit
    assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=worker,text=True).strip()
    plan_path=worker/'evidence/long_horizon/adverse_purpose_tail/plan.json'
    plan=json.loads(plan_path.read_bytes())
    assert plan['arms']==['stable','transfer_purpose'] and len(plan['specs'])==10
    for name,expected in plan['prerequisites'].items():
        assert sha((worker/name).read_bytes())==expected
    preparation=json.loads((plan_path.parent/'preparation_complete/verification.json').read_bytes())
    assert preparation['complete'] and preparation['preparation_no_loss']
    assert (preparation['executions'],preparation['actual_steps'])==(24,3072)
    persona=json.loads((plan_path.parent/'persona_contract.json').read_bytes())
    assert persona['complete'] and persona['passed'] and persona['subcases']==4
    assert all(sha((worker/n).read_bytes())==h for n,h in persona['source_files'].items())
    assert sha((plan_path.parent/persona['log']).read_bytes())==persona['log_sha256']
    os.environ.update(plan['arithmetic'])
    os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    sys.path.insert(0,str(worker))
    from tools.run_adverse_recovery import verify_registration
    import numpy as np
    registration=verify_registration(plan_path)
    driver=U/'tools/local_adverse_queue.py'
    io=U/'tools/local_checkpoint_io.py'
    jobs=[dict(study='purpose',source=str(worker),plan=str(plan_path),registration=registration,
        spec=spec,arm=arm,arithmetic=plan['arithmetic'],
        output=str(output/'purpose/latest'/f"adverse-{spec['id']}-{arm}"))
        for spec in plan['specs'] for arm in plan['arms']]
    assert len(jobs)==20 and len({j['output'] for j in jobs})==20
    manifest=dict(version=1,created=datetime.now(timezone.utc).isoformat(),source_ref=commit,
        runtime=dict(python=sys.version,numpy=np.__version__,system=platform.system(),machine=platform.machine()),
        driver_sha256=sha(driver.read_bytes()),io_sha256=sha(io.read_bytes()),jobs=jobs,
        adoption=False,independent_confirmation='not started',
        scope='Fresh original ten paired development conditions, unchanged persona, actual world seeds and gates. No GitHub Actions.')
    output.mkdir(parents=True)
    (output/'driver.py').write_bytes(driver.read_bytes())
    (output/'local_checkpoint_io.py').write_bytes(io.read_bytes())
    (output/'manifest.json').write_bytes(encoded(manifest))
    print(json.dumps(dict(manifest=str(output/'manifest.json'),sha256=sha(encoded(manifest)),
        source_ref=commit,executions=20,launched=False,adoption=False)))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ('worker','commit','output'):
        parser.add_argument('--'+key,required=True)
    main(**vars(parser.parse_args()))
