"""All-turn deterministic diagnostic, using existing public-rule reference.

No factual execution or root probe; no latent truth is sent to an NPC. The
reference freezes the recorded current prediction, so it is deliberately NOT
the learning actor, nor evidence of optimal play under its personality.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys


def read(path):return json.loads(path.read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()


def account(source, folder):
    receipt = read(folder/'verification.json')
    assert receipt['pair_complete'] and not receipt['cohort_gate_evaluated']
    assert all(sha(Path(n).read_bytes())==h for n,h in receipt['source_files'].items())
    spec=receipt['spec']; assert spec['game']=='auction'
    sys.path.insert(0,str(source))
    from tools.diagnose_auction_continuity import reference
    from tools.run_adverse_recovery import game_for
    game=game_for(spec); arms={}
    for name in receipt['source_files']:
        if Path(name).name!='result.json':continue
        result=read(Path(name)); rows=[]
        for r in result['trace']:
            t=r['tick']; end=min(t+result['configuration']['horizon'],spec['turns'])
            probabilities=tuple(r['response_prediction'][str(k)] for k in range(3))
            q=reference(end,spec['seed']%2,lambda _,p=probabilities:p)
            raw=q(t,int(r['before']['cash']))
            # reference denominator follows its terminal tick; retain the game's
            # registered 128-turn score units and the already acquired score.
            baseline=(r['before']['score']-r['before']['rival'])/(8*spec['turns'])
            values={k:baseline+value*end/spec['turns'] for k,value in raw.items()}
            assert set(values)==set(game.keys(r['before']))
            single=reference(t+1,spec['seed']%2,lambda _,p=probabilities:p)(t,int(r['before']['cash']))
            for key,value in single.items():
                direct=sum(prob*game.public_value(game.transition(r['before'],key,str(z))[0]) for z,prob in enumerate(probabilities))
                assert abs(direct-(baseline+value*(t+1)/spec['turns'])) < 1e-12
            best=max(values.values())
            choices=[key for key,value in values.items() if best-value<=1e-12]
            plans=r['purpose_by_plan']; selected=r['selected_plan']
            assert plans[selected]==r['selected_purpose']
            rows.append(dict(tick=t,action=r['action'],cash=r['before']['cash'],
                frozen_belief_best_actions=choices,frozen_belief_values=values,
                frozen_belief_opportunity_loss=best-values[r['action']],
                selected_stored_purpose=plans[selected],best_stored_purpose=max(plans.values()),
                modeled_purpose_sacrifice=max(plans.values())-plans[selected]))
        phases=[]
        for start in range(0,spec['turns'],32):
            rr=rows[start:start+32]
            phases.append(dict(start=start,end=start+len(rr),
                exact_current_belief_suboptimal_choices=sum(r['frozen_belief_opportunity_loss']>1e-12 for r in rr),
                frozen_belief_loss_sum=sum(r['frozen_belief_opportunity_loss'] for r in rr),
                maximal_stored_purpose_but_suboptimal_reference=sum(r['modeled_purpose_sacrifice']<=1e-12 and r['frozen_belief_opportunity_loss']>1e-12 for r in rr),
                mean_reference_minus_selected_forecast=sum(max(r['frozen_belief_values'].values())-r['selected_stored_purpose'] for r in rr)/len(rr)))
        arms[result['configuration']['arm']]=dict(rows=rows,phases=phases)
    assert set(arms)=={'stable','transfer_purpose'}
    out=dict(case=spec['id'],adoption=False,cohort_gate_evaluated=False,arms=arms,
        source_receipt_sha256=sha((folder/'verification.json').read_bytes()),
        reference_source_sha256=sha((source/'tools/diagnose_auction_continuity.py').read_bytes()),
        one_step_rule_equivalence='Every action at every factual state checked against public transitions to 1e-12.',
        limits=['Every turn of both complete arms retained. No diagnostic roots selected or sampled.',
            'Reference freezes the observed current response prediction for the same declared horizon.',
            'Reference ignores personality and future belief learning; its gap is not a personality error or a proof that rollout alone is wrong.',
            'Sum of overlapping-window gaps is a diagnostic statistic, not achievable long-term score gain.',
            'Stored full forecast differences may arise from sample variance, future belief updates, different purposes or continuation coverage.'])
    with (folder/'belief_reference_accounting.json').open('x',encoding='utf-8') as f:json.dump(out,f,sort_keys=True,indent=2)
    return dict(case=spec['id'],phases={k:v['phases'] for k,v in arms.items()})


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--pair',required=True);a=p.parse_args()
    print(json.dumps(account(Path(a.source).resolve(),Path(a.pair).resolve())))
