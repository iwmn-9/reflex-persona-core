"""Evaluator-only accounting of every phase in an already audited complete pair.

The perfect-information reference is never supplied to an NPC. This reads no
running history, selects no probe roots, and makes no cohort adoption decision.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

def read(p):return json.loads(p.read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--pair',required=True);a=p.parse_args()
    folder=Path(a.pair);receipt=read(folder/'verification.json');review=read(folder/'analysis.json')
    assert receipt['pair_complete'] and not receipt['cohort_gate_evaluated']
    assert sha((folder/'analysis.json').read_bytes())==receipt['analysis_sha256']
    assert all(sha(Path(n).read_bytes())==h for n,h in receipt['source_files'].items())
    spec=receipt['spec'];assert spec['game']=='auction'
    sys.path.insert(0,str(Path(a.source).resolve()))
    from tools.diagnose_auction_continuity import reference
    from tools.run_owned_value import law
    q=reference(spec['turns'],spec['seed']%2,lambda t:tuple(law(t,spec['turns'],spec['regime']).values()))
    arms={}
    for name in receipt['source_files']:
        if Path(name).name!='result.json':continue
        result=read(Path(name));arm=result['configuration']['arm'];tr=result['trace'];phases=[];total=0.
        for start in range(0,128,32):
            rows=tr[start:start+32];loss=[]
            for row in rows:
                values=q(row['tick'],int(row['before']['cash']))
                loss.append(max(values.values())-values[row['action']])
            total+=sum(loss)
            phases.append(dict(start=start,end=start+32,oracle_purpose_opportunity_loss=sum(loss),
                prediction_brier_excess=sum(sum((r['response_prediction'][k]-v)**2 for k,v in r['truth'].items()) for r in rows)/len(rows),
                mean_cash_before=sum(r['before']['cash'] for r in rows)/len(rows),
                cash_at_start=rows[0]['before']['cash'],cash_at_end=rows[-1]['after']['cash'],
                actions=dict(Counter(r['action'] for r in rows))))
        expected=review['accounts']['reference' if arm=='stable' else 'candidate']['bellman']['purpose_opportunity_loss']
        assert abs(total-expected)<1e-12
        arms[arm]=phases
    assert set(arms)=={'stable','transfer_purpose'}
    differences=[dict(start=x['start'],end=x['end'],
        oracle_choice_gain=x['oracle_purpose_opportunity_loss']-y['oracle_purpose_opportunity_loss'],
        prediction_brier_delta=y['prediction_brier_excess']-x['prediction_brier_excess'],
        mean_cash_delta=y['mean_cash_before']-x['mean_cash_before']) for x,y in zip(arms['stable'],arms['transfer_purpose'])]
    result=dict(case=spec['id'],adoption=False,cohort_gate_evaluated=False,source_receipt_sha256=sha((folder/'verification.json').read_bytes()),
        phases=arms,differences=differences,
        scope='Every 32-turn phase of one completed original pair. Oracle includes hidden future laws and personality sacrifice; diagnostic accounting only, never NPC input or a replacement gate.')
    output=folder/'phase_accounting.json'
    with output.open('x',encoding='utf-8') as f:json.dump(result,f,sort_keys=True,indent=2)
    print(json.dumps(dict(case=spec['id'],differences=differences)))
