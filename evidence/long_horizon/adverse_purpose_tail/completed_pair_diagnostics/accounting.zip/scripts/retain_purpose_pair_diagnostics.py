import hashlib
import json
from pathlib import Path
import zipfile

V=Path(__file__).parent;B=V.parents[2];Q=B/'reflex-persona-purpose-tail'
out=Q/'evidence/long_horizon/adverse_purpose_tail/completed_pair_diagnostics';out.mkdir(exist_ok=False)
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
cases=['auction-2-10061202-shift-return','auction-3-10061202-shift-return'];summary=[]
with zipfile.ZipFile(out/'accounting.zip','x',zipfile.ZIP_DEFLATED) as packed:
    for case in cases:
        folder=V/'purpose_completed_pairs'/case;receipt=read(folder/'verification.json')
        assert receipt['pair_complete'] and not receipt['cohort_gate_evaluated']
        assert all(sha(Path(n))==h for n,h in receipt['source_files'].items())
        for name in receipt['source_files']:
            p=Path(name);packed.writestr(case+'/inputs/'+p.parent.name+'/'+p.name,p.read_bytes())
        for p in folder.glob('*.json'):packed.writestr(case+'/'+p.name,p.read_bytes())
        account=read(folder/'forecast_execution_accounting.json')
        assert account['source_receipt_sha256']==sha(folder/'verification.json')
        summary.append(dict(case=case,phases={k:v['phases'] for k,v in account['arms'].items()}))
    for name in ('audit_completed_purpose_pair.py','account_completed_auction_phases.py','account_completed_selection.py',
        'account_completed_belief_reference.py','account_forecast_execution.py','retain_purpose_pair_diagnostics.py'):
        packed.writestr('scripts/'+name,(V/name).read_bytes())
(out/'summary.json').write_text(json.dumps(dict(complete_pairs=2,actual_steps=512,cohort_complete=False,
    cohort_gate_evaluated=False,adoption=False,rows=summary),sort_keys=True,indent=2)+'\n',encoding='utf8')
proof=dict(complete_pair_audit=True,complete_pairs=2,actual_steps=512,all_factual_windows=512,
    source_ref='243c42aef2c9da21ccf4e21e4093aa73f8c0f4d7',cohort_gate_evaluated=False,adoption=False,
    forecast_calls=0,selected_probe_roots=0,files={p.name:sha(p) for p in out.iterdir()},
    limits='These are the currently completed pairs, not a selected success set or a completed cohort. Retain full adverse-case diagnostics after all20 executions.')
(out/'verification.json').write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof))
