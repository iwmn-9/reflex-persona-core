"""Audit and package the immutable, completed exact-deadline diagnostic."""
import gzip
import hashlib
import io
import json
import subprocess
import sys
import zipfile
from pathlib import Path

R = Path(__file__).resolve().parents[1]
root = R / 'results/preparation_window_diagnostic'
BASE = 'd6a02361d99095aa350ef6f825008f40bbb8a1ba'
sys.path.insert(0, str(root / '_source'))
from tools.preparation_world import DelayedYield
from tools.owned_checkpoint import encoded, sha
from reflex.core import character_key, digest

def read(p):
    return json.loads(p.read_bytes())

manifest = read(root / 'source_snapshot.json')
registration = read(root / 'registration.json')
summary = read(root / 'summary.json')
assert summary['complete'] and summary['identical_pre_shock_prefixes'] == 6
archive = subprocess.check_output(
    ['git', 'archive', '--format=zip', BASE, *sorted({p.split('/')[0] for p in manifest})], cwd=R)
with zipfile.ZipFile(io.BytesIO(archive)) as z:
    for name, expected in manifest.items():
        assert sha(z.read(name)) == expected == sha((root / '_source' / name).read_bytes())

records = []
comparisons = []
for spec in registration['cases']:
    for mode in registration['modes']:
        p = root / f"delay-{spec['delay']}-shock-{int(spec['shock'])}" / mode
        row = read(p / 'result.json')
        envelope = read(p / 'checkpoint.json')
        saved = envelope['payload']
        assert sha(encoded(saved)) == envelope['sha256']
        assert saved['trace'] == row['trace'] and saved['world'] == row['final']
        assert saved['contract']['configuration'] == row['configuration']
        assert all(row['configuration'][k] == v for k, v in dict(spec, mode=mode).items())
        assert row['configuration']['driver_sha256'] == manifest['tools/run_preparation_window.py']
        assert row['configuration']['adapter_sha256'] == manifest['tools/preparation_world.py']
        assert row['complete'] and row['turns'] == len(row['trace']) == row['physical_replay'] == 128
        assert saved['checks'] == row['checks'] == dict(fixed_axes=128, owner_parity=128, clock=128)
        assert row['trace'][-1]['owner'] == digest(saved['owner'])
        game = DelayedYield(spec['delay'], turns=128)
        world = game.start()
        person = character_key(game.context(world))
        clock_owner = digest([game.context(world)['scope'], game.context(world)['objective']])
        matches = 0
        mismatches = []
        compared = 0
        for i, step in enumerate(row['trace']):
            assert step['tick'] == i and step['before'] == world
            assert character_key(game.context(world)) == person
            assert step['clock'] == dict(owner=clock_owner, horizon=16, used=i+1, last_tick=i)
            assert step['horizon'] == (16-i % 16 if mode == 'fixed-window' else 16)
            if i:
                assert row['trace'][i-1]['owner'] == step['before_owner']
            world, _ = game.transition(world, step['action'], '0')
            if spec['shock'] and world['tick'] == 64:
                world['payout'] = 2.
            assert world == step['after']
            # A shock revealed after decision 63 can invalidate subsequent
            # predictions; never demand clairvoyance across that boundary.
            stop = min(i + step['horizon'], 128)
            if spec['shock'] and i < 64:
                stop = min(stop, 64)
            predicted = step['modeled_actions'][:stop-i]
            actual = [s['action'] for s in row['trace'][i:stop]]
            assert len(predicted) == len(actual)
            assert predicted[0] == actual[0]
            matches += predicted == actual
            compared += len(actual)
            if predicted != actual:
                mismatches.append(dict(tick=i, predicted=predicted, actual=actual))
        assert world == row['final'] and game.terminal(world)
        assert row['score'] == game.goal(world).value
        if mode == 'fixed-window':
            assert not mismatches, (spec, mismatches[:1])
        comparisons.append(dict(**spec, mode=mode, exact_suffix_roots=matches,
            roots=128, compared_action_entries=compared, mismatch_roots=len(mismatches),
            first_mismatches=mismatches[:2]))
        records.append(dict(case=spec, mode=mode, result={k:v for k,v in row.items() if k != 'trace'},
            checkpoint=envelope, result_sha256=sha((p/'result.json').read_bytes()),
            checkpoint_sha256=sha((p/'checkpoint.json').read_bytes())))

for delay in (3, 7, 11):
    for mode in registration['modes']:
        pair = [r for r in records if r['case']['delay'] == delay and r['mode'] == mode]
        assert len(pair) == 2
        for a, b in zip(*(r['checkpoint']['payload']['trace'][:64] for r in pair)):
            assert all(a[k] == b[k] for k in ('before', 'action', 'before_owner', 'clock', 'horizon'))
assert len(records) == 12
out = R / 'evidence/long_horizon/exact_deadline'
assert not out.exists(), 'Do not overwrite published immutable evidence'
out.mkdir()
with zipfile.ZipFile(out/'source.zip', 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for name in ('registration.json', 'source_snapshot.json'):
        z.writestr(name, (root/name).read_bytes())
    z.writestr('audit.py', Path(__file__).read_bytes())
with gzip.open(out/'runs.jsonl.gz', 'wb') as f:
    for record in records:
        f.write(encoded(record)+b'\n')
(out/'summary.json').write_bytes(encoded(summary)+b'\n')
proof = dict(complete=True, base_commit=BASE, source_manifest_matches_commit=True,
    completed_runs=12, actual_decisions=1536, physical_replay=1536,
    fixed_axes_checks_at_execution=1536, owner_feedback_parity_checks_at_execution=1536,
    clock_checks=1536, blind_predecision_prefixes=6, suffix_comparisons=comparisons,
    limitations=[
        'Deterministic delayed-yield mechanism and one personality; not independent game-family confirmation.',
        'Only final owner record is saved, so this audit checks historical hashes/continuity and execution-time parity checks, not independent reconstruction of every historical owner.',
        'Unexpected payout shock at64 aligns with a16-turn window boundary; arbitrary late opportunities are not tested.',
        '152/144 fixed-window cash at delay11 exceeds138/136 rolling exact-tree cash, but earlier registered short-future-policy runs reached156/144. This is not superiority over all baselines.',
        'Modeled-action suffix matches demonstrate time consistency on these deterministic trajectories, not generally correct forecasts.'],
    artifacts={name:sha((out/name).read_bytes()) for name in ('source.zip', 'runs.jsonl.gz', 'summary.json')})
(out/'verification.json').write_bytes(encoded(proof)+b'\n')
(R/'results/long_horizon_diagnostics/exact_deadline_audit.json').write_bytes(encoded(proof)+b'\n')
print(json.dumps(dict(complete=True, runs=12, decisions=1536,
    comparison=[{k:v for k,v in c.items() if k != 'first_mismatches'} for c in comparisons])))
