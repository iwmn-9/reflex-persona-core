"""Counterexample to treating a changed first action as intelligence evidence."""
import json
from pathlib import Path
import sys

root=Path(__file__).resolve().parent
source=Path(sys.argv[1]) if len(sys.argv)>1 else root.parents[2]/'reflex-persona-gain-continuation'
sys.path.insert(0,str(source))
from tools.preparation_world import PreparationChain
game=PreparationChain(11,payout=24.,turns=128)
paths={'income_first':['x']*3+['y']*121+['x']*4,
       'preparation_first':['y']*8+['x']*3+['y']*113+['x']*4}
rows={}
for name,actions in paths.items():
    world=game.start()
    for key in actions:world,_=game.transition(world,key,'0')
    assert len(actions)==128 and game.terminal(world) and world['stage']==0
    rows[name]=dict(first=actions[0],actions=actions,final=world,score=game.goal(world).value)
assert rows['income_first']['final']==rows['preparation_first']['final']
# Against earning one per turn, a completed 11-step cycle adds 24-2*11.
# Twelve complete cycles require132 steps;11 is the attainable upper bound.
bound=8+128+(24-2*11)*(128//11)
assert rows['income_first']['final']['cash']==bound==158
out=dict(complete=True,source='62d9971',paths=rows,upper_bound_cash=bound,
    conclusion='Both initial actions admit a legal optimal128-step continuation. First-action change alone is not judgment improvement.',
    limits='Evaluator-constructed deterministic paths. No NPC policy, learning or new long-run success is claimed.')
output=Path(sys.argv[2]) if len(sys.argv)>2 else root/'preparation_first_action_tie.json'
output.write_text(json.dumps(out,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps(dict(complete=True,initial_actions={k:r['first'] for k,r in rows.items()},
    final_cash=bound,score=rows['income_first']['score'])))
