"""Retain completed smoke histories; no rerun and no quality/adoption claim."""
from pathlib import Path
import hashlib
import json
import zipfile

V=Path(__file__).parent;B=V.parents[2]
source=B/'reflex-persona-preview-runtime';raw=V/'gain_driver_connection'
destination=B/'reflex-persona-gain-continuation/evidence/gain_retry/runner_connection'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
proof=json.loads((raw/'verification.json').read_bytes())
assert proof['complete'] and proof['passed'] and proof['actual_steps']==24
assert all(sha(source/n)==h for n,h in proof['sources'].items())
assert sha(V/'check_gain_driver_connection.py')==proof['script_sha256']
for row in proof['rows']:
    for mode,audit in row['audits'].items():
        assert audit['complete'] and audit['actual_steps']==3
        assert sha(raw/row['family']/mode/'checkpoint.json')==audit['checkpoint_sha256']
destination.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(destination/'histories.zip','x',zipfile.ZIP_DEFLATED) as packed:
    for p in sorted(raw.rglob('*.json')):packed.write(p,p.relative_to(raw).as_posix())
    for name in ('check_gain_driver_connection.py','gain_driver_connection.log','archive_gain_connection.py'):
        packed.write(V/name,name)
(destination/'verification.json').write_bytes((raw/'verification.json').read_bytes())
(destination/'README.md').write_text('''# 候補の実行・中断復帰の接続確認

対象は `research/reuse-prepared-context` の `3cf4fa4`。予測はH32・標本3本だが、実世界は4分野それぞれ3手だけの接続確認であり、長期の判断品質や独立確認ではない。

各分野で連続実行と、1手で中断して保存から再開する実行を比較した。行動列、実世界、実際に学んだ本人、世界乱数、設定、保存復元の検査数は完全一致した。異なる腕・登録情報からの再開は拒否し、完了済み履歴の再読込で学習を重複させなかった。8実行・24手、125.704637秒。検証前後で実装ファイルのハッシュは一致した。

`histories.zip` に全実履歴・保存状態・実行スクリプトと出力を保持する。ソース正本と計算結果同一性の検証は同じコミットの `evidence/prepared_context_runtime` を参照する。現在の本研究20実行や機構診断を置き換えず、本採用も許可しない。
''',encoding='utf-8')
receipt=dict(complete=True,adoption=False,source_commit='3cf4fa4',actual_steps=24,
    artifacts={p.name:sha(p) for p in destination.iterdir()})
(destination/'archive.json').write_text(json.dumps(receipt,sort_keys=True,indent=2),encoding='utf-8')
print(json.dumps(dict(complete=True,actual_steps=24,output=str(destination))))
