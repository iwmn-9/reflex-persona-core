"""Complete runner/resume connection, deliberately not long-quality evidence."""
import json
from pathlib import Path
import sys
import time

V=Path(__file__).parent;B=V.parents[2];source=B/'reflex-persona-preview-runtime'
sys.path.insert(0,str(source))
from tools.run_adverse_recovery import run
from tools.adverse_segment import audit
from tools.owned_checkpoint import encoded,sha

out=V/'gain_driver_connection';out.mkdir(exist_ok=False)
sources={str(p.relative_to(source)):sha(p.read_bytes()) for folder in ('reflex','tools') for p in (source/folder).rglob('*.py')}
registration=dict(plan_sha256='runner-connection-smoke-only',source_sha256=sha(encoded(sources)))
rows=[];started=time.perf_counter()
for family in ('auction','combat','gambling','resources'):
    spec=dict(id='gain-connection-'+family,mechanism='world',game=family,profile=1,seed=601,regime='outside',turns=3)
    full=out/family/'full';split=out/family/'split';arm='transfer_purpose_gain'
    expected=run(full,spec,arm,registration=registration)
    assert expected['configuration']['horizon']==32 and expected['configuration']['seeds']==[701,702,703]
    assert run(split,spec,arm,max_decisions=1,registration=registration) is None
    assert not audit(split,spec,arm,registration)['complete'] and not (split/'result.json').exists()
    for kwargs in (dict(arm='stable',registration=registration),
            dict(arm=arm,registration=dict(registration,plan_sha256='changed'))):
        try:run(split,spec,**kwargs)
        except ValueError:pass
        else:raise AssertionError('mismatched checkpoint accepted')
    actual=run(split,spec,arm,registration=registration)
    for key in ('trace','final','final_owner','final_rng','checks','configuration'):
        assert expected[key]==actual[key],(family,key)
    assert actual['replayed_actual_steps']==3 and actual['checks']==dict(fixed_axes=3,owner_parity=3,restored=3)
    assert run(split,spec,arm,registration=registration)['trace']==actual['trace']
    checks={mode:audit(folder,spec,arm,registration) for mode,folder in (('full',full),('split',split))}
    assert all(a['complete'] for a in checks.values())
    rows.append(dict(family=family,exact_continuous_vs_resume=True,wrong_arm_and_registration_rejected=True,audits=checks))
assert all(sha((source/n).read_bytes())==h for n,h in sources.items())
proof=dict(complete=True,passed=True,adoption=False,actual_steps=24,rows=rows,sources=sources,
    seconds=time.perf_counter()-started,script_sha256=sha(Path(__file__).read_bytes()),
    note='H32 and three samples on three-turn smoke worlds. Full actual feedback, save/restore, resumption and exact trace/RNG/owner parity; not long-world or independent quality evidence.')
(out/'verification.json').write_bytes(encoded(proof))
print(json.dumps(dict(complete=True,families=4,actual_steps=24,seconds=proof['seconds'])))
