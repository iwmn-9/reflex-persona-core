"""Offline accounting of complete pairs only; all ten remain required."""
import importlib.util
import json
from pathlib import Path

V=Path(__file__).parent;B=V.parents[2];G=B/'reflex-persona-gain-continuation'
execution=G/'results/gain_retry_known_20261031';out=V/'gain_choice_accounting';out.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('account',V/'account_preparation_choices.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=m.read(execution/'plan.json');rows=[]
for case in plan['specs']:
    if not all((execution/case['id']/arm/'audit.json').exists() for arm in plan['arms']):continue
    output=out/(case['id']+'.json')
    if not output.exists():m.account(G,execution,case['id'],output)
    proof=m.read(output);assert proof['plan_sha256']==m.sha((execution/'plan.json').read_bytes())
    rows.append(dict(case=case['id'],sha256=m.sha(output.read_bytes()),
        arms={k:{n:v for n,v in a.items() if n!='rows'} for k,a in proof['arms'].items()}))
summary=dict(complete=len(rows)==len(plan['specs']),registered=len(plan['specs']),completed=len(rows),
    adoption=False,rows=rows,scope='Current completed deterministic mechanism pairs only; not the main cohort or independent confirmation.')
(out/'summary.json').write_text(json.dumps(summary,sort_keys=True,indent=2))
print(json.dumps(dict(completed=len(rows),required=len(plan['specs']))))
