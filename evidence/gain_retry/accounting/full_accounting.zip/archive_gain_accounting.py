"""Retain all ten completed pairs' exact finite-state loss accounting."""
import hashlib
import json
from pathlib import Path
import zipfile

V=Path(__file__).parent;B=V.parents[2]
folder=B/'reflex-persona-gain-continuation/evidence/gain_retry'
raw=V/'gain_choice_accounting';out=folder/'accounting'
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
proof=read(folder/'complete/verification.json')
plan=read(folder/'complete/plan.json');summary=read(raw/'summary.json')
if not proof['complete'] or proof['actual_steps']!=2560 or proof['pairs']!=10:
    raise ValueError('full mechanism audit required')
if not summary['complete'] or summary['completed']!=summary['registered'] or summary['registered']!=10:
    raise ValueError('every registered pair must be accounted for')
if {r['case'] for r in summary['rows']}!={s['id'] for s in plan['specs']}:
    raise ValueError('all original mechanism conditions required')
paths=[]
for row in summary['rows']:
    path=raw/(row['case']+'.json');detail=read(path)
    assert sha(path)==row['sha256'] and detail['complete_pair'] and not detail['adoption']
    assert detail['plan_sha256']==sha(folder/'complete/plan.json')
    assert detail['evaluator_sha256']==sha(V/'account_preparation_choices.py')
    assert all(len(a['rows'])==128 for a in detail['arms'].values())
    paths.append(path)
out.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(out/'full_accounting.zip','x',zipfile.ZIP_DEFLATED) as packed:
    for p in paths+[V/'account_preparation_choices.py',V/'account_completed_gain_cases.py',Path(__file__)]:
        packed.write(p,p.name)
summary.update(actual_steps=2560,proof_sha256=sha(folder/'complete/verification.json'),
    artifacts={'full_accounting.zip':sha(out/'full_accounting.zip')},
    limitations=detail['limitations'])
(out/'summary.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(complete=True,conditions=10,actual_steps=2560,adoption=False)))
