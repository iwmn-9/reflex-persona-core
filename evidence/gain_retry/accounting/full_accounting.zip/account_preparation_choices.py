"""Evaluator-only exact finite-state accounting of complete mechanism traces.

No policy is called or changed. The scheduled-change reference has information
the NPC cannot have; the frozen-public reference assumes current payout lasts.
Neither defines the correct choice for an intrinsically different persona.
"""
import argparse
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import sys
import time


def read(path):return json.loads(path.read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()


def account(source, execution, case, output):
    source,execution,output=map(Path,(source,execution,output))
    if output.exists():raise FileExistsError('retain existing complete accounting')
    plan=read(execution/'plan.json');spec=next(s for s in plan['specs'] if s['id']==case)
    if spec['mechanism']!='chain':raise ValueError('explicit diagnostic transition family required')
    if not all(sha((source/n).read_bytes())==h for n,h in plan['sources'].items()):
        raise ValueError('registered source changed')
    # Read only finished arms, never an active checkpoint.
    results={}
    for arm in plan['arms']:
        folder=execution/case/arm
        proof=read(folder/'audit.json');result=read(folder/'result.json')
        if not proof['complete'] or not result['complete'] or proof['actual_steps']!=spec['turns']:
            raise ValueError('only already audited complete pairs')
        if sha((folder/'result.json').read_bytes())!=proof['files']['result.json']:
            raise ValueError('completed trace changed')
        results[arm]=result
    import os
    os.environ.update(plan['arithmetic'])
    sys.path.insert(0,str(source))
    from tools.run_continuation_portfolio import game_for
    game=game_for(spec);origin=game.start();schedule=dict(spec['changes']);visited=0

    def state(tick,stage,cash,payout):
        return dict(origin,tick=tick,stage=stage,cash=cash,payout=payout)

    def packed(world):return tuple(world[n] for n in ('tick','stage','cash','payout'))

    def after(world,key,known_future):
        next_world,_=game.transition(world,key,'0')
        if known_future and next_world['tick'] in schedule:
            next_world['payout']=schedule[next_world['tick']]
        return next_world

    @lru_cache(None)
    def optimum(tick,stage,cash,payout,known_future):
        nonlocal visited
        visited+=1;world=state(tick,stage,cash,payout)
        if game.terminal(world):return game.goal(world).value
        return max(optimum(*packed(after(world,key,known_future)),known_future)
                   for key in game.keys(world))

    def values(world,known_future):
        return {key:optimum(*packed(after(world,key,known_future)),known_future)
                for key in game.keys(world)}

    start=time.monotonic();arms={}
    for arm,result in results.items():
        rows=[]
        for row in result['trace']:
            world=row['before'];compact=state(*packed(world))
            # Check the projection on every recorded state and all its actions.
            if game.keys(world)!=game.keys(compact) or game.goal(world)!=game.goal(compact):
                raise ValueError('reference state omitted an objective or legality dependency')
            for key in game.keys(world):
                a,fa=game.transition(world,key,'0');b,fb=game.transition(compact,key,'0')
                if a!=b or fa!=fb:raise ValueError('reference state omitted a transition dependency')
            actual=after(world,row['action'],True)
            if actual!=row['after']:raise ValueError('recorded physical transition mismatch')
            true=values(world,True);public=values(world,False)
            rows.append(dict(tick=world['tick'],action=row['action'],
                scheduled_values=true,frozen_public_values=public,
                scheduled_regret=max(true.values())-true[row['action']],
                frozen_public_regret=max(public.values())-public[row['action']]))
        regret=sum(r['scheduled_regret'] for r in rows)
        expected=optimum(*packed(origin),True)-result['score']
        if abs(regret-expected)>1e-12:raise ValueError('finite-path accounting must telescope to exact final loss')
        arms[arm]=dict(score=result['score'],scheduled_optimum=optimum(*packed(origin),True),
            scheduled_regret=regret,frozen_public_regret=sum(r['frozen_public_regret'] for r in rows),
            public_suboptimal_choices=sum(r['frozen_public_regret']>1e-12 for r in rows),
            rows=rows)
    result=dict(case=case,complete_pair=True,adoption=False,arms=arms,states=visited,
        seconds=time.monotonic()-start,plan_sha256=sha((execution/'plan.json').read_bytes()),
        evaluator_sha256=sha(Path(__file__).read_bytes()),
        limitations=['Evaluation-only enumerated preparation world, not an NPC rule or a cross-game claim.',
            'Scheduled optimum is omniscient. Frozen-public optimum omits future learning and intrinsic preferences.',
            'Factual actions remain from the original audited runs; this does not rerun their modeled forecasts.'])
    output.write_text(json.dumps(result,sort_keys=True,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps(dict(case=case,states=visited,seconds=result['seconds'],
        arms={k:{n:x for n,x in a.items() if n!='rows'} for k,a in arms.items()})))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ('source','execution','case','output'):p.add_argument('--'+name,required=True)
    account(**vars(p.parse_args()))
