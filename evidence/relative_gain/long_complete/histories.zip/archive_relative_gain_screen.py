"""Collect only a complete fixed relative-gain long-play mechanism study."""
from pathlib import Path
import hashlib,json,zipfile

def sha(data):return hashlib.sha256(data).hexdigest()
def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

local=Path(__file__).resolve().parent
root=local.parents[2]/'reflex-persona-relative-gain'
execution=root/'results/relative_gain_screen_20261101'
state=json.loads((execution/'status.json').read_bytes())
assert state['complete'] and state['state']=='complete' and state['executions_complete']==28 and not state['failures'], 'full28 executions required'
plan=json.loads((execution/'plan.json').read_bytes());summary=json.loads((execution/'summary.json').read_bytes())
assert len(plan['specs'])==14 and len({s['id'] for s in plan['specs']})==14
assert plan['references']==['origin','ordinary'] and summary['complete'] and not summary['adoption']
assert sha((execution/'plan.json').read_bytes())==summary['plan_sha256']
assert all(sha((root/n).read_bytes())==h for n,h in plan['sources'].items())
result_pairs=[];files={}
for spec in plan['specs']:
    arms={}
    for reference in plan['references']:
        folder=execution/spec['id']/reference
        audit=json.loads((folder/'audit.json').read_bytes())
        result=json.loads((folder/'result.json').read_bytes())
        envelope=json.loads((folder/'checkpoint.json').read_bytes());payload=envelope['payload']
        assert sha(encoded(payload))==envelope['sha256']
        assert audit['complete'] and audit['actual_steps']==audit['restored']==spec['turns']==128
        assert audit['owner_world_rng_persona_replayed'] and audit['source_runtime']==plan['runtime']
        assert all(sha((folder/n).read_bytes())==h for n,h in audit['files'].items())
        assert result['complete'] and result['configuration']==payload['contract']['configuration']
        config=result['configuration']
        assert config['spec']==spec and config['retry_gain_reference']==reference
        assert config['plan_sha256']==summary['plan_sha256'] and config['seeds']==[701]
        assert config['horizon']==spec.get('horizon',8) and config['retry_until_gain'] is True
        assert result['trace']==payload['trace'] and len(result['trace'])==128
        assert result['final']==payload['world'] and result['score']==audit['score']
        assert payload['owner']['last_tick']==127 and payload['world']['tick']==128
        assert all(result['checks'][k]==128 for k in ('fixed_axes','owner_parity','restored'))
        arms[reference]=audit
        for path in folder.glob('*.json'):files[path.relative_to(execution).as_posix()]=sha(path.read_bytes())
    result_pairs.append(dict(id=spec['id'],delta=arms['ordinary']['score']-arms['origin']['score'],arms=arms))
assert result_pairs==summary['pairs'] and summary['actual_steps']==3584
passed=all(p['delta']>=-1e-12 for p in result_pairs) and all(p['delta']>1e-12 for p in result_pairs if p['id'].startswith('background-') and p['id'].endswith('-profitable'))
assert passed==summary['gate_passed']==state['gate_passed']
recovery=None
if (execution/'recovery_checkpoint.json').exists():
    raw=(execution/'recovery_checkpoint.json').read_bytes()
    incident=json.loads((execution/'recovery_incident.json').read_bytes())
    assert sha(raw)==incident['files']['checkpoint.json']
    packet=json.loads(raw);before=packet['payload'];assert sha(encoded(before))==packet['sha256']
    retained=before['trace'];assert len(retained)==incident['preserved_steps']==97
    after=json.loads((execution/incident['affected_case']/incident['affected_arm']/'checkpoint.json').read_bytes())['payload']
    assert after['contract']==before['contract'] and after['trace'][:len(retained)]==retained
    owner_digest=sha(json.dumps(before['owner'],ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
    assert after['trace'][96]['after']==before['world'] and after['trace'][96]['owner']==owner_digest
    recovery=dict(original_steps=97,remaining_steps=31,prefix_exact=True,original_checkpoint_sha256=sha(raw),
        cause=incident['cause'],source_and_plan_unchanged=True)
target=root/'evidence/relative_gain/long_complete'
assert not target.exists()
target.mkdir()
with zipfile.ZipFile(target/'histories.zip','x',zipfile.ZIP_DEFLATED) as packed:
    for name in files:packed.write(execution/name,name)
    for name in ('plan.json','summary.json','status.json','stdout.log','stderr.log','launch.json'):
        packed.write(execution/name,name)
    for pattern in ('recovery*.json','recovery*.log','*.before_recovery.json'):
        for path in execution.glob(pattern):packed.write(path,path.name)
    packed.write(Path(__file__),Path(__file__).name)
with zipfile.ZipFile(target/'source.zip','x',zipfile.ZIP_DEFLATED) as packed:
    for name in plan['sources']:packed.write(root/name,name)
receipt=dict(complete=True,gate_passed=passed,adoption=False,independent_confirmation=False,
    conditions=14,executions=28,actual_steps=3584,every_step_restored=3584,
    fixed_persona=True,owner_world_rng_histories_replayed=True,
    source_files=len(plan['sources']),source_sha256=sha(encoded(plan['sources'])),
    plan_sha256=summary['plan_sha256'],
    improvements=[p['id'] for p in result_pairs if p['delta']>1e-12],
    losses=[p['id'] for p in result_pairs if p['delta'] < -1e-12],
    artifacts={name:sha((target/name).read_bytes()) for name in ('histories.zip','source.zip')},
    limitation='Complete deterministic mechanism screen only. Stochastic four-family worlds, all losses/persona reviews and reserved40 remain required.')
if recovery is not None:receipt['recovery']=recovery
(target/'verification.json').write_bytes(encoded(receipt))
(target/'summary.json').write_bytes((execution/'summary.json').read_bytes())
print(json.dumps(receipt))
