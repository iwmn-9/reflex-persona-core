"""Audit completed bounded diagnoses without turning them into adoption."""
from pathlib import Path
import hashlib, json, sys, zipfile

local=Path(__file__).resolve().parent
root=local.parents[2]/'reflex-persona-relative-gain'
sys.path.insert(0,str(root))
from reflex.core import digest,character_key
from reflex.decision_loop import DecisionLoop
from reflex.model_observer import resolve_feedback
from tools.background_preparation import BackgroundChain

def sha(data):return hashlib.sha256(data).hexdigest()
def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()

first=local/'background_gain_diagnosis';second=local/'relative_background_diagnosis'
plans=[json.loads((folder/'plan.json').read_bytes()) for folder in (first,second)]
summaries=[json.loads((folder/'summary.json').read_bytes()) for folder in (first,second)]
assert all(s['complete'] and s['steps']==96 and not s['adoption'] for s in summaries)
assert all(sha((root/n).read_bytes())==h for n,h in plans[1]['sources'].items())
proofs=[];rows={}
for folder,plan in zip((first,second),plans):
    assert sha((folder/'plan.json').read_bytes())==json.loads((folder/'summary.json').read_bytes())['plan_sha256']
    for path in folder.glob('background-*.json'):
        saved=json.loads(path.read_bytes());case=saved['case'];game=BackgroundChain(case['background'])
        world=game.start();actor=game.actor(game.context(world),learning='segmented');axes=character_key(game.context(world))
        for row in saved['trace']:
            assert row['before']==world and row['owner_before']==digest(actor.record())
            context=game.context(world,actor.state)
            result=DecisionLoop.decide_batch([(actor,game.request(context))],False,_counterfactual_roots=(row['action'],))[0]
            after,flow=game.transition(world,row['action'],'0')
            resolve_feedback(actor,result['ticket'],game.feedback(world,after,row['action'],context,flow))
            assert after==row['after'] and digest(actor.record())==row['owner']
            assert character_key(result['context'])==axes
            world=after
        assert game.terminal(world) and world==saved['final'] and saved['steps']==saved['restores']==len(saved['trace'])==24
        assert abs(saved['optimal_cash']-world['cash']-sum(r['avoidable_loss'] for r in saved['trace']))<1e-12
        proofs.append(dict(file=folder.name+'/'+path.name,sha256=sha(path.read_bytes()),actual_steps=24,
            owner_world_persona_replayed=True,every_step_restored=saved['restores']))
        rows[(folder.name,case['background'],case.get('reference',case['gain']))]=saved
for background in (0.,1.125):
    assert rows[(first.name,background,True)]['trace']==rows[(second.name,background,'origin')]['trace']
evidence=root/'evidence/relative_gain';evidence.mkdir(exist_ok=True)
archive=evidence/'boundary.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as packed:
    for folder in (first,second):
        for path in sorted(folder.glob('*.json')):packed.write(path,folder.name+'/'+path.name)
    for script in ('diagnose_background_gain.py','diagnose_relative_background.py','archive_relative_boundary.py'):
        packed.write(local/script,'scripts/'+script)
    for name in plans[1]['sources']:packed.write(root/name,'source/'+name)
    packed.writestr('audits.json',encoded(proofs))
receipt=dict(complete=True,adoption=False,scientific_cohort=False,
    source=plans[1]['source'],source_sha256=plans[1]['source_sha256'],source_files=len(plans[1]['sources']),
    archive_sha256=sha(archive.read_bytes()),actual_executions=8,actual_steps=192,every_step_restored=192,
    distinct_environment_conditions=2,exact_original_control_histories=True,
    comparisons=[dict(background=d,original_cash=rows[(second.name,d,'origin')]['final']['cash'],
        relative_cash=rows[(second.name,d,'ordinary')]['final']['cash'],
        public_score_optimal_cash=rows[(second.name,d,'ordinary')]['optimal_cash'],
        remaining_public_score_loss=rows[(second.name,d,'ordinary')]['avoidable_loss']) for d in (0.,1.125)],
    limitations=['Known deterministic 24-turn mechanism diagnosis; not the registered world or independent cohort.',
        'The exact cash optimum is a diagnostic reference, not a substitute for personality preferences.',
        'The revised reference remains opt-in Python research; stable/Rust/default origin behavior unchanged.'])
(evidence/'boundary.json').write_bytes(encoded(receipt))
print(json.dumps(receipt))
