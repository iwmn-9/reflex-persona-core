"""Isolated positive background-flow boundary; never a cohort adoption gate."""
from pathlib import Path
from functools import lru_cache
from datetime import datetime, timezone
import copy, ctypes, hashlib, json, os, subprocess, sys, time

local = Path(__file__).resolve().parent
root = local.parents[2] / 'reflex-persona-relative-gain'
output = local / 'relative_background_diagnosis'
output.mkdir(exist_ok=False)
os.environ.update(NPY_DISABLE_CPU_FEATURES='AVX512F,AVX512CD,AVX512_SKX,AVX512_CLX,AVX512_CNL,AVX512_ICL',
    OPENBLAS_CORETYPE='Haswell', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
if os.name == 'nt':
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    k.GetCurrentProcess.restype = ctypes.c_void_p
    k.SetPriorityClass.argtypes = (ctypes.c_void_p, ctypes.c_uint)
    assert k.SetPriorityClass(k.GetCurrentProcess(), 0x4000)
sys.path.insert(0, str(root))
import numpy as np
from reflex.core import digest, character_key
from reflex.decision_loop import DecisionLoop
from reflex.examples import effect
from reflex._continuation_portfolio import portfolio_planner
from reflex.model_observer import resolve_feedback
from tools.preparation_world import PreparationChain
from tools.run_owned_value import cumulative_basis

def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()

def sha(data):
    return hashlib.sha256(data).hexdigest()

class BackgroundChain(PreparationChain):
    def __init__(self, background):
        super().__init__(5, payout=14., turns=24)
        self.background = background
        self.model_id = digest(['background-preparation-diagnosis-v1', self.model_id, background])

    def transition(self, world, key, symbol):
        after, _ = super().transition(world, key, symbol)
        after['cash'] += self.background
        gain = max(-1., min(1., (after['cash'] - world['cash']) / 12.))
        return after, effect(gain, needs={'growth':gain, 'safety':0.}, values={'achievement':gain})

@lru_cache(None)
def best_cash(remaining, eighths, stage, drift):
    if not remaining:
        return eighths
    choices = [best_cash(remaining - 1, eighths + 8 + drift, stage, drift)]
    if eighths >= 8:
        done = stage + 1 == 5
        choices.append(best_cash(remaining - 1, eighths - 8 + drift + (112 if done else 0),
            0 if done else stage + 1, drift))
    return max(choices)

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head.startswith('357cf13')
sources = {p.relative_to(root).as_posix():sha(p.read_bytes()) for folder in ('reflex','tools','tests')
    for p in (root/folder).rglob('*.py')}
plan = dict(source=head, sources=sources, source_sha256=sha(encoded(sources)), script_sha256=sha(Path(__file__).read_bytes()),
    cases=[dict(background=x, reference=r, gain=True) for x in (0.,1.125) for r in ('origin','ordinary')],
    turns=24, horizon=8, seeds=[701], delay=5, payout=14., profile=0,
    adoption=False, scope='Deterministic diagnostic only. Public-score exact optimum is an accounting reference, not a replacement for personality or registered long-world gates.')
(output/'plan.json').write_bytes(encoded(plan))
results=[]
for case in plan['cases']:
    game=BackgroundChain(case['background']);world=game.start();actor=game.actor(game.context(world),learning='segmented')
    axes=character_key(game.context(world));trace=[];started=time.perf_counter()
    while not game.terminal(world):
        context=game.context(world,actor.state);request=game.request(context);captured={}
        before=actor.record();detached=copy.deepcopy(actor)
        planner=portfolio_planner(actor,request,world,observe=game.context,events=game.events,terminal=game.terminal,
            assess=lambda w:game.goal(w).record(),request_for=game.request,feedback=game.feedback,
            model_id=game.model_id,target=game.target,horizon=8,seeds=(701,),world_model='posterior',
            cumulative_preference=cumulative_basis(game,True),include_retry=True,captured=captured,
            purpose_estimator='conditional',tail_recovery=2,coherent_cumulative_mean=True,
            tail_purpose_reflex=True,retry_until_gain=case['gain'],retry_gain_reference=case['reference'])
        result=DecisionLoop.decide_batch([(actor,request)],False,planner)[0]
        key=result['decision']['action_id'];after,flow=game.transition(world,key,'0')
        feedback=game.feedback(world,after,key,context,flow)
        resolve_feedback(actor,result['ticket'],feedback)
        factual=DecisionLoop.decide_batch([(detached,request)],False,_counterfactual_roots=(key,))[0]
        resolve_feedback(detached,factual['ticket'],feedback)
        assert actor.record()==detached.record() and character_key(result['context'])==axes
        record=json.loads(encoded(actor.record()))
        actor=DecisionLoop.from_record(context,record,predictor=actor.predictor)
        assert actor.record()==record
        drift=int(case['background']*8)
        optimal=best_cash(24-world['tick'],round(world['cash']*8),world['stage'],drift)/8
        chosen_optimal=best_cash(24-after['tick'],round(after['cash']*8),after['stage'],drift)/8
        selection=result['deliberation'];forecast=captured['forecast']
        proposal=forecast.audit['plans'][selection['selected_plan']]['proposal']
        trace.append(dict(before=world,after=after,action=key,owner_before=digest(before),owner=digest(record),
            optimal_cash_before=optimal,optimal_cash_after=chosen_optimal,avoidable_loss=optimal-chosen_optimal,
            selected_policy=proposal,selected_purpose=selection['selected_purpose'],
            modeled=captured['modeled'],decision=result['decision']))
        world=after
        (output/'status.json').write_bytes(encoded(dict(state='running',case=case,turn=world['tick'],complete=False,
            pid=os.getpid(),cases_complete=len(results),adoption=False)))
    row=dict(case=case,complete=True,steps=len(trace),restores=len(trace),fixed_persona=True,
        exact_factual_owner_replay=True,final=world,score=game.goal(world).value,
        optimal_cash=best_cash(24,64,0,int(case['background']*8))/8,
        avoidable_loss=sum(t['avoidable_loss'] for t in trace),seconds=time.perf_counter()-started)
    assert abs(row['optimal_cash']-world['cash']-row['avoidable_loss'])<1e-12
    name=f"background-{case['background']}-reference-{case['reference']}"
    (output/(name+'.json')).write_bytes(encoded(dict(**row,trace=trace)))
    results.append(row)
    print(json.dumps(row),flush=True)
assert all(sha((root/n).read_bytes())==h for n,h in sources.items())
summary=dict(complete=True,results=results,steps=sum(r['steps'] for r in results),adoption=False,
    plan_sha256=sha((output/'plan.json').read_bytes()),finished=datetime.now(timezone.utc).isoformat())
(output/'summary.json').write_bytes(encoded(summary))
(output/'status.json').write_bytes(encoded(dict(state='complete',complete=True,cases_complete=len(results),adoption=False)))
print(json.dumps(dict(complete=True,steps=summary['steps'])),flush=True)

