"""Pin the entire eligible development control bank with original provenance."""
from pathlib import Path
import hashlib,json,zipfile
def sha(data):return hashlib.sha256(data).hexdigest()
def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
local=Path(__file__).resolve().parent;base=local.parents[2]
source=base/'reflex-persona-consistent-reading/evidence/long_horizon/consistent_horizon/completed_local'
receipt=json.loads((local/'reusable_control_eligibility.json').read_bytes())
assert receipt['complete'] and receipt['eligible_control_records']==10 and receipt['all_repeated_exact']
assert not receipt['reuse_performed'] and receipt['new_planning_executions']==0
assert sha((source/'verification.json').read_bytes())==receipt['original_proof_sha256']
proof=json.loads((source/'verification.json').read_bytes())
assert all(sha((source/n).read_bytes())==h for n,h in proof['artifacts'].items())
target=base/'reflex-persona-relative-gain/evidence/relative_gain'
packed_path=target/'development_control_bank.zip'
assert not packed_path.exists()
with zipfile.ZipFile(source/'checkpoints.zip') as original,zipfile.ZipFile(packed_path,'x',zipfile.ZIP_DEFLATED) as output:
    for item in receipt['controls']:
        prefix=item['id']+'/stable/'
        record=next(w for w in proof['workers'] if w['id']==item['id'] and w['arm']=='stable')
        for name,digest in record['hashes'].items():
            raw=original.read(prefix+name);assert sha(raw)==digest
            output.writestr(prefix+name,raw)
    for name in ('verification.json','plan.json','registration.json','source.zip'):
        output.write(source/name,'original_cohort/'+name)
    for script in ('inspect_reusable_controls.py','archive_reusable_controls.py'):
        output.write(local/script,'scripts/'+script)
    output.write(local/'reusable_control_eligibility.json','eligibility.json')
receipt.update(bank_sha256=sha(packed_path.read_bytes()),scope='Ten known development controls only; NOT the reserved forty conditions.',
    rule='Pin all ten original controls before any new world candidate data. Preserve original source, registration, runtime, every actual trace and all outcome criteria. Never claim new independent samples or rewrite old registrations.')
(target/'development_control_bank.json').write_bytes(encoded(receipt))
print(json.dumps(dict(controls=10,steps=1280,bank_sha256=receipt['bank_sha256'],reuse_performed=False)))
