"""Read-only eligibility audit; never relabel old results as fresh executions."""
from pathlib import Path
import ast,gzip,hashlib,json,platform,sys,zipfile
import numpy as np

def sha(data):return hashlib.sha256(data).hexdigest()
def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def function(text,name):
    tree=ast.parse(text)
    return ast.dump(next(n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name),include_attributes=False)

local=Path(__file__).resolve().parent;base=local.parents[2]
archive=base/'reflex-persona-consistent-reading/evidence/long_horizon/consistent_horizon/completed_local'
worker=base/'reflex-persona-relative-gain'
proof=json.loads((archive/'verification.json').read_bytes())
assert proof['complete'] and proof['executions']==20 and proof['actual_steps']==2560
assert all(sha((archive/n).read_bytes())==h for n,h in proof['artifacts'].items())
rows=[json.loads(line) for line in gzip.decompress((archive/'runs.jsonl.gz').read_bytes()).splitlines()]
controls={r['spec']['id']:r for r in rows if r['arm']=='stable'}
assert len(controls)==10
manifest=json.loads((base/'reflex-persona-preview-runtime/results/gain_development_20261031/manifest.json').read_bytes())
specs={j['spec']['id']:j['spec'] for j in manifest['jobs'] if j['arm']=='stable'}
assert {k:r['spec'] for k,r in controls.items()}==specs
runtime=dict(python=sys.version,numpy=np.__version__,system=platform.system(),machine=platform.machine())
receipts=[]
with zipfile.ZipFile(archive/'checkpoints.zip') as checkpoints:
    for identity,row in controls.items():
        prefix=identity+'/stable/'
        packet=json.loads(checkpoints.read(prefix+'checkpoint.json'));saved=packet['payload'];result=row['result']
        status=json.loads(checkpoints.read(prefix+'status.json'))
        assert sha(encoded(saved))==packet['sha256']
        recorded=next(w for w in proof['workers'] if w['id']==identity and w['arm']=='stable')
        assert all(sha(checkpoints.read(prefix+n))==h for n,h in recorded['hashes'].items())
        assert result==json.loads(checkpoints.read(prefix+'result.json'))
        assert result['complete'] and status['complete'] and len(result['trace'])==128
        assert result['trace']==saved['trace'] and result['final']==saved['world']
        assert result['configuration']==saved['contract']['configuration']
        assert saved['contract']['runtime']==result['runtime']==runtime
        cfg=result['configuration']
        assert cfg['arm']=='stable' and cfg['horizon']==32 and cfg['seeds']==[701,702,703] and cfg['recovery_cache']==64
        assert cfg['spec']==specs[identity] and cfg['registration']==proof['registration']
        assert recorded['worker_exact_owner_replay']==128 and recorded['physical_and_rng_replayed'] and recorded['owner_hash_chain']
        receipts.append(dict(id=identity,steps=128,original_registration=cfg['registration'],
            original_source=proof['source_ref'],checkpoint_sha256=recorded['hashes']['checkpoint.json'],
            result_sha256=recorded['hashes']['result.json'],runtime_exact=True))
with zipfile.ZipFile(archive/'source.zip') as source:
    world_equal={n:sha(source.read(n))==sha((worker/n).read_bytes()) for n in
        ('tools/continuing_games.py','tools/preparation_world.py')}
    function_equal={f'{n}:{name}':function(source.read(n).decode('utf-8-sig'),name)==function((worker/n).read_text(encoding='utf-8-sig'),name)
        for n,name in (('tools/run_continuation_portfolio.py','game_for'),('tools/run_owned_value.py','law'),('tools/run_owned_value.py','cumulative_basis'))}
assert all(world_equal.values()) and all(function_equal.values())
fresh=[]
queue=base/'reflex-persona-purpose-tail/results/purpose_development_20261031/purpose/latest'
for identity,row in controls.items():
    paths=[queue/f'adverse-{identity}-{arm}' for arm in ('stable','transfer_purpose')]
    if not all((p/'status.json').exists() and json.loads((p/'status.json').read_bytes()).get('complete') for p in paths):continue
    # Both arms are complete. No live checkpoint or partial pair is inspected.
    current=json.loads((paths[0]/'result.json').read_bytes());old=row['result']
    assert current['complete'] and current['runtime']==old['runtime']==runtime
    fields=('trace','final','final_owner','final_rng','score','conditional_increment','replayed_actual_steps')
    equal={k:current[k]==old[k] for k in fields}
    fresh.append(dict(id=identity,source_result_sha256=sha((paths[0]/'result.json').read_bytes()),exact_fields=equal,exact=all(equal.values())))
receipt=dict(complete=True,eligible_control_records=10,existing_actual_steps=1280,new_planning_executions=0,
    original_proof_sha256=sha((archive/'verification.json').read_bytes()),original_source=proof['source_ref'],
    native_runtime=runtime,world_files_exact=world_equal,world_functions_ast_exact=function_equal,
    controls=receipts,repeated_completed_pairs=fresh,all_repeated_exact=all(r['exact'] for r in fresh),
    current_studies_unchanged=True,reuse_performed=False,adoption=False,
    limits=['Eligibility audit only; original registrations and source hashes must remain attached to any reused control.',
        'No old execution may be relabeled as a fresh candidate-source execution or counted as independent evidence.',
        'A future prospective protocol must pin the entire ten-control bank, preserve every criterion and validate candidate world/runtime contracts.',
        'All currently registered Q/G studies and their diagnostics still finish; no skipped controls or retrospective replacement.'])
target=local/'reusable_control_eligibility.json'
assert not target.exists();target.write_bytes(encoded(receipt))
print(json.dumps({k:receipt[k] for k in ('eligible_control_records','existing_actual_steps','world_files_exact','world_functions_ast_exact','repeated_completed_pairs','all_repeated_exact','reuse_performed')}))
