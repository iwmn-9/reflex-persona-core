"""Archive only a fully checked equivalent response-preparation runtime."""
from pathlib import Path
import hashlib,json,re,subprocess,zipfile
v=Path(__file__).parent;b=v.parents[2];l=b/'reflex-persona-shared-runtime';k=b/'reflex-persona-retry-runtime'
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def encoded(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
matrix=read(v/'prepared_responses_matrix.json')
reference=read(v/'prepared_responses_known_reference.json');candidate=read(v/'prepared_responses_known_candidate.json')
assert matrix['complete'] and matrix['differences']==[] and len(matrix['rows'])==7
assert reference['complete'] and candidate['complete']
assert reference['actual']==candidate['actual'] and reference['runtime']==candidate['runtime']
assert candidate['cpu_seconds']<reference['cpu_seconds']*.95
assert all(sha(l/n)==h for n,h in candidate['sources'].items())
assert all(sha(l/n)==h for n,h in matrix['sources'].items())
assert all(sha(k/n)==h for n,h in reference['sources'].items())
log=(l/'results/prepared_responses_tests.log').read_text(encoding='utf-8')
match=re.search(r'Ran (\d+) tests in ([0-9.]+)s\s+OK\s*$',log)
assert match,'Required affected tests incomplete or failed'
sources={p.relative_to(l).as_posix():sha(p) for folder in ('reflex','tools','tests') for p in sorted((l/folder).glob('*.py'))}
previous=read(k/'evidence/unchanged_retry_runtime/sources.json')
changed=[n for n,h in previous.items() if sources.get(n)!=h];added=sorted(set(sources)-set(previous))
assert changed==['reflex/closed_loop.py'] and added==['tests/test_prepared_responses.py']
assert len(sources)==602
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=l,text=True).strip()
assert commit!='9309ad944d32dcd3c7c3965e698d2d6416fa7657'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=l,text=True).strip()
out=l/'evidence/prepared_response_runtime';out.mkdir(exist_ok=False)
(out/'sources.json').write_bytes(encoded(sources))
with zipfile.ZipFile(out/'source.zip','x',zipfile.ZIP_DEFLATED) as z:
 for n in sources:z.write(l/n,n)
with zipfile.ZipFile(out/'verification_data.zip','x',zipfile.ZIP_DEFLATED) as z:
 for n in ('prepared_responses_matrix.json','prepared_responses_known_reference.json','prepared_responses_known_candidate.json','check_gain_path_reuse.py','measure_gain_known_owner.py','archive_prepared_response_runtime.py'):z.write(v/n,n)
 z.write(l/'results/prepared_responses_tests.log','affected_tests.log')
 z.writestr('additional_tests.json',encoded(dict(first_batch=dict(tests=9,passed=8,errors=1,error='Existing sibling import in tests.test_closed_loop; no source change required'),rerun=dict(method='tests.test_closed_loop.ClosedLoopTests.test_owned_learning_social_and_progress_survive_modeled_and_real_steps',tests=1,passed=1,pythonpath='worker/tests'),unique_methods_passed=9,new_method_subcases=12,scope='Four rule families times frozen/posterior/persistent world model; complete tree/results matched with the optimization explicitly removed.')))
proof=dict(complete=True,adoption=False,scientific_source_commit=commit,
 previous_runtime_source='9309ad944d32dcd3c7c3965e698d2d6416fa7657',
 previous_runtime_qualification=sha(k/'evidence/unchanged_retry_runtime/verification.json'),
 development_source_ref='71bf6b2f3e40724a7bb33be14dc3bd3311ee18f8',
 source_sha256=hashlib.sha256(encoded(sources)).hexdigest(),files_count=len(sources),
 changed_from_previous=changed,added_from_previous=added,exact_matrix_cases=7,
 exact_experienced_h32_owner=True,exact_actual_feedback_and_restore=True,
 experienced_root_normalized_sha256=candidate['normalized_sha256'],
 matrix_cpu_seconds=[matrix['old_cpu'],matrix['new_cpu']],
 experienced_cpu_seconds=[reference['cpu_seconds'],candidate['cpu_seconds']],
 experienced_wall_seconds=[reference['wall_seconds'],candidate['wall_seconds']],
 affected_tests=int(match[1]),additional_unique_methods=9,new_method_subcases=12,
 semantics='Resolve the same node response distribution once on a full detached owner. Every conditional event, flow, choice, learner and actual transition retained; external kernels remain unchanged.',
 artifacts={p.name:sha(p) for p in out.iterdir()},
 limitations=['Same pure-model callback contract; no cross-owner or cross-decision cache.','This is runtime equivalence only, not independent scientific quality or adoption.','Matrix timing did not improve; experienced-root timing improved. No uniform wall-time or all-world speed guarantee.','Affected tests plus exact full-output comparisons, not a fresh full repository regression.','No active registered study source was replaced.'])
(out/'verification.json').write_bytes(encoded(proof))
print(json.dumps({k:proof[k] for k in ('complete','files_count','experienced_cpu_seconds','affected_tests','additional_unique_methods')}))

