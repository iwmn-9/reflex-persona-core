"""Copy ordinary owner/context graphs without scalar dispatch overhead.

Custom object protocols remain delegated to the standard library. Ordinary
objects use its default state-copy semantics; no mutable history is shared.
Explicit caller-supplied memo dictionaries retain the standard implementation.
"""
import copy as _standard
import copyreg
import types

copy = _standard.copy
_ATOMIC = frozenset((type(None),bool,int,float,complex,str,bytes,range,
                    type(Ellipsis),type(NotImplemented)))
_CONTAINERS = frozenset((dict,list,tuple))


def _ordinary_object(kind):
    return (type(kind) is type and kind not in copyreg.dispatch_table and kind.__new__ is object.__new__
        and kind.__reduce_ex__ is object.__reduce_ex__
        and kind.__reduce__ is object.__reduce__
        and kind.__getattribute__ is object.__getattribute__
        and getattr(kind,'__getstate__',None) is getattr(object,'__getstate__',None)
        and not hasattr(kind,'__deepcopy__') and not hasattr(kind,'__setstate__')
        and not hasattr(kind,'__getnewargs__') and not hasattr(kind,'__getnewargs_ex__')
        and all('__dict__' not in base.__dict__ or isinstance(base.__dict__['__dict__'],types.GetSetDescriptorType)
                for base in kind.__mro__)
        and not any('__slots__' in base.__dict__ for base in kind.__mro__))


def _plain(value,memo):
    kind=type(value)
    if kind in _ATOMIC:return value
    identity=id(value)
    if identity in memo:return memo[identity]
    if kind is dict:
        result={};memo[identity]=result
        for key,item in value.items():
            # Match stdlib's RHS-before-subscript evaluation for custom hooks.
            cloned_item=item if type(item) in _ATOMIC else _plain(item,memo)
            cloned_key=key if type(key) in _ATOMIC else _plain(key,memo)
            result[cloned_key]=cloned_item
    elif kind is list:
        result=[];memo[identity]=result
        result.extend(item if type(item) in _ATOMIC else _plain(item,memo) for item in value)
    elif kind is tuple:
        items=[item if type(item) in _ATOMIC else _plain(item,memo) for item in value]
        if identity in memo:return memo[identity]
        if all(a is b for a,b in zip(items,value)):return value
        result=tuple(items);memo[identity]=result
    elif _ordinary_object(kind) and hasattr(value,'__dict__'):
        result=object.__new__(kind);memo[identity]=result
        result.__dict__.update(_plain(value.__dict__,memo))
    else:
        return _standard.deepcopy(value,memo)
    # A copied temporary must remain alive for the lifetime of its id-keyed memo.
    memo.setdefault(id(memo),[]).append(value)
    return result


def deepcopy(value,memo=None):
    if memo is not None:return _standard.deepcopy(value,memo)
    kind=type(value)
    if kind in _ATOMIC:return value
    return _plain(value,{})
