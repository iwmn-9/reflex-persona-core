"""Archive exact execution acceleration separately from NPC-quality adoption."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import re
import zipfile

def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):return json.loads(path.read_bytes())
def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--source',required=True);parser.add_argument('--output',required=True)
    args=parser.parse_args();source=Path(args.source).resolve();root=Path(__file__).resolve().parent;out=Path(args.output).resolve()
    full_root=root/'exact_runtime_full_regression_20261031';repair_root=root/'exact_runtime_fixture_import_repair_20261031'
    full=read(full_root/'validation.json');repair=read(repair_root/'validation.json')
    assert full['complete'] and full['source_unchanged'] and repair['passed'] and repair['source_unchanged']
    broad_sources=read(full_root/'source.json');assert broad_sources==read(repair_root/'source.json')
    rows={r['module']:r for r in full['rows']};repaired={r['module']:r for r in repair['rows']}
    closed_log=root/'exact_runtime_closed_loop_harness_repair.log';raw=closed_log.read_bytes();text=raw.decode('utf-8-sig')
    assert re.search(r'Ran 8 tests in',text) and text.rstrip().endswith('OK')
    repaired['tests.test_closed_loop']=dict(module='tests.test_closed_loop',tests=8,skipped=0,passed=True,
        exit_code=0,log_sha256=sha(raw),repair_log=closed_log.name)
    expected={ 'tests.'+p.stem for p in (source/'tests').glob('test_*.py') }
    assert set(rows)==expected
    repairs=[]
    for module,row in rows.items():
        if row['passed']:continue
        log=(full_root/(module+'.log')).read_text(encoding='utf-8')
        assert module in repaired and re.search(r"ModuleNotFoundError: No module named 'test_[^']+'",log)
        assert 'FAIL:' not in log and 'AssertionError' not in log
        repairs.append(dict(module=module,original=row,corrected=repaired[module],
            cause='Per-module runner omitted tests/ from import path used by unittest discovery. No test assertion or runtime source changed.'))
        rows[module]=repaired[module]
    assert all(r['passed'] and r['tests']>0 for r in rows.values())
    discovery=read(root/'exact_runtime_discovery_20261031.json')
    assert not discovery['loader_errors'] and sum(r['tests'] for r in rows.values())==discovery['expected_test_cases']
    broad_rows=list(rows.values())
    delta_root=root/'exact_runtime_copy_removal_regression_20261031'
    delta=read(delta_root/'validation.json');sources=read(delta_root/'source.json')
    assert delta['passed'] and delta['source_unchanged'] and delta['complete']
    assert set(sources)==set(broad_sources)
    changed={n for n,h in sources.items() if broad_sources[n]!=h}
    assert changed=={'reflex/cloning.py','tests/test_cloning.py'}
    assert all(sha((source/n).read_bytes())==h for n,h in sources.items())
    assert sha((root/'pre_removal_cloning.py').read_bytes())==broad_sources['reflex/cloning.py']
    assert sha((root/'pre_removal_test_cloning.py').read_bytes())==broad_sources['tests/test_cloning.py']
    assert {r['module'] for r in delta['rows']}=={'tests.test_cloning','tests.test_exact_evaluation_runtime',
        'tests.test_decision_loop','tests.test_closed_loop','tests.test_leaf_forecast_runtime','tests.test_purpose_tail_persona'}
    for row in delta['rows']:rows[row['module']]=row
    final_discovery=read(root/'exact_runtime_final_discovery_20261031.json')
    assert not final_discovery['loader_errors'] and sum(r['tests'] for r in rows.values())==final_discovery['expected_test_cases']
    reference_path=root/'exact_runtime_reference_pinned_20261031.json'
    candidate_path=root/'exact_runtime_final_pinned_20261031.json'
    reference=read(reference_path);candidate=read(candidate_path)
    assert reference['exact_forecast'] and candidate['exact_forecast']
    assert reference['runtime']==candidate['runtime']
    assert reference['forecast_sha256']==candidate['forecast_sha256']==candidate['reference_sha256']
    assert sources['reflex/cloning.py']==reference['sources']['reflex/cloning.py'],'custom object copying must be restored byte-for-byte'
    assert all(sources[n]==h for n,h in candidate['sources'].items())
    histories_path=root/'exact_runtime_final_native_histories_20261031.json';histories=read(histories_path)
    assert histories['complete'] and all(r['exact'] for r in histories['rows'])
    assert all(sources[n]==h for n,h in histories['sources'].items())
    if out.exists():raise FileExistsError(out)
    out.mkdir(parents=True)
    payload=dict(version='exact-runtime-qualification-1',at=datetime.now(timezone.utc).isoformat(),
        complete=True,adoption=False,source_sha256=sha(encoded(sources)),
        regression=dict(modules=len(rows),covered_test_cases=sum(r['tests'] for r in rows.values()),
            skipped=sum(r['skipped'] for r in rows.values()),passed=True,source_unchanged=True,repairs=repairs,rows=list(rows.values()),
            broad_run_tests=sum(r['tests'] for r in broad_rows),broad_source_sha256=sha(encoded(broad_sources)),
            changed_since_broad_run=sorted(changed),post_change_tests=delta['tests'],
            coverage_note='All broad-run source is identical except reverting cloning.py exactly to the original frozen implementation and adding its instance-protocol test. Six affected modules were rerun on final source, plus exact H32 forecast and actual-history replay. This is composed regression coverage, not a claim of rerunning all tests on final source.',
            harness_note='The first per-module wrapper omitted sibling test import paths. The archived wrapper is the corrected reproducible runner, not a claimed byte snapshot of that initial wrapper. All scientific and test files were hashed unchanged, and all failed modules were repaired under that same source.'),
        exact_h32_forecast=dict(identical=True,reference_cpu_seconds=reference['cpu_seconds'],candidate_cpu_seconds=candidate['cpu_seconds'],
            cpu_ratio=candidate['cpu_seconds']/reference['cpu_seconds'],speedup=reference['cpu_seconds']/candidate['cpu_seconds'],
            reference_wall_seconds=reference['wall_seconds'],candidate_wall_seconds=candidate['wall_seconds'],
            runtime=candidate['runtime'],forecast_sha256=candidate['forecast_sha256']),
        exact_recorded_history=dict(executions=histories['executions'],actual_steps=histories['actual_history_steps'],
            cpu_seconds=histories['cpu_seconds'],wall_seconds=histories['wall_seconds'],scope=histories['scope']),
        limits=['One paired known H32 root, under concurrent local load; not a general speedup guarantee or new long-play quality.',
            'Native history replay supplies recorded actions; it proves learning/state/RNG fidelity, not new prospective choices.',
            'The original scientific twenty executions keep their original immutable source. Forty-condition confirmation and NPC adoption are separate.',
            'Historic Linux archive did not replay exactly on this Windows runtime even with the original source and pinned arithmetic. It was not substituted for native parity.'])
    files=[reference_path,candidate_path,histories_path,root/'profile_summary_20261031.json',root/'replay_transfer_pinned.log',closed_log,
        root/'replay_transfer_reference_pinned.log',root/'ordinary_clone_instance_hook_failure.json',
        root/'pre_removal_cloning.py',root/'pre_removal_test_cloning.py',
        root/'exact_runtime_discovery_20261031.json',root/'exact_runtime_final_discovery_20261031.json',
        root/'benchmark_exact_runtime.py',root/'replay_runtime_histories.py',root/'validate_exact_runtime.py',Path(__file__)]
    with zipfile.ZipFile(out/'qualification.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in files:z.write(p,p.name)
        for folder in (full_root,repair_root,delta_root):
            for p in sorted(folder.iterdir()):
                if p.is_file():z.write(p,folder.name+'/'+p.name)
    payload['artifacts']={'qualification.zip':sha((out/'qualification.zip').read_bytes())}
    (out/'verification.json').write_bytes(encoded(payload))
    print(json.dumps({k:payload[k] for k in ('complete','adoption','source_sha256','exact_h32_forecast')}))
