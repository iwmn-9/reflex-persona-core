"""Finite, source-bound local regression run; isolated modules, bounded CPUs."""
import argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

def now():return datetime.now(timezone.utc).isoformat()
def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,sort_keys=True,indent=2),encoding='utf-8');tmp.replace(path)
def snapshot(root):
    return {str(p.relative_to(root)).replace('\\','/'):sha(p.read_bytes())
        for folder in ('reflex','tools','tests') for p in (root/folder).rglob('*')
        if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo')}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--source',required=True);parser.add_argument('--output',required=True)
    parser.add_argument('--workers',type=int,default=2);parser.add_argument('--modules',nargs='+');args=parser.parse_args()
    if not 1<=args.workers<=4:raise ValueError('bounded local test workers required')
    source=Path(args.source).resolve();output=Path(args.output).resolve();output.mkdir()
    before=snapshot(source);started=now();start=time.monotonic()
    runner_source=Path(__file__).read_bytes();(output/'runner.py').write_bytes(runner_source)
    modules=sorted('tests.'+p.stem for p in (source/'tests').glob('test_*.py'))
    if args.modules:
        if len(set(args.modules))!=len(args.modules) or not set(args.modules)<=set(modules):raise ValueError('explicit existing modules required')
        modules=sorted(args.modules)
    save(output/'source.json',before)
    env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',
        OPENBLAS_CORETYPE='Haswell',NPY_DISABLE_CPU_FEATURES='AVX512F,AVX512CD,AVX512_SKX,AVX512_CLX,AVX512_CNL,AVX512_ICL')
    env['PYTHONPATH']=str(source/'tests')+os.pathsep+str(source)+os.pathsep+env.get('PYTHONPATH','')
    def run(module):
        wall=time.monotonic()
        with (output/(module+'.log')).open('wb') as log:
            p=subprocess.run([sys.executable,'-m','unittest',module,'-v'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,
                creationflags=getattr(subprocess,'BELOW_NORMAL_PRIORITY_CLASS',0))
        raw=(output/(module+'.log')).read_bytes();text=raw.decode('utf-8',errors='replace')
        count=re.search(r'Ran (\d+) tests? in',text);skips=re.search(r'OK \(skipped=(\d+)\)',text)
        return dict(module=module,exit_code=p.returncode,tests=None if count is None else int(count[1]),
            skipped=0 if skips is None else int(skips[1]),log_sha256=sha(raw),wall_seconds=time.monotonic()-wall,
            passed=p.returncode==0 and count is not None and int(count[1])>0)
    rows=[]
    state=dict(started=started,source=str(source),pid=os.getpid(),complete=False,adoption=False,runner_sha256=sha(runner_source),
        registered_modules=len(modules),workers=args.workers,arithmetic={k:env[k] for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_CORETYPE','NPY_DISABLE_CPU_FEATURES')})
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(run,m) for m in modules]
        for future in as_completed(futures):
            rows.append(future.result());rows.sort(key=lambda r:r['module'])
            save(output/'state.json',dict(state,updated=now(),completed_modules=len(rows),rows=rows))
    unchanged=snapshot(source)==before
    result=dict(state,complete=True,finished=now(),wall_seconds=time.monotonic()-start,source_unchanged=unchanged,
        passed=unchanged and len(rows)==len(modules) and all(r['passed'] for r in rows),rows=rows,
        tests=sum(r['tests'] or 0 for r in rows),skipped=sum(r['skipped'] for r in rows))
    save(output/'validation.json',result);save(output/'state.json',result)
    print(json.dumps({k:result[k] for k in ('complete','passed','source_unchanged','tests','skipped','wall_seconds')}),flush=True)
    if not result['passed']:sys.exit(1)
