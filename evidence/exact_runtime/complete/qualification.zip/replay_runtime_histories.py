"""Cheap exact history equivalence; does not re-evaluate policy choices."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import zipfile

def sha(data):return hashlib.sha256(data).hexdigest()

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--source',required=True);parser.add_argument('--archive');parser.add_argument('--native-root');parser.add_argument('--output',required=True)
    args=parser.parse_args();source=Path(args.source).resolve()
    assert bool(args.archive)!=bool(args.native_root)
    out=Path(args.output)
    if out.exists():raise FileExistsError(out)
    members=[]
    if args.archive:
        root=Path(args.archive).resolve();proof_raw=(root/'verification.json').read_bytes();proof=json.loads(proof_raw)
        archive=(root/'checkpoints.zip').read_bytes()
        assert proof['complete'] and sha(archive)==proof['artifacts']['checkpoints.zip']
        with zipfile.ZipFile(root/'checkpoints.zip') as z:
            for worker in proof['workers']:
                prefix=worker['id']+'/'+worker['arm']+'/'
                checkpoint=z.read(prefix+'checkpoint.json');result=z.read(prefix+'result.json')
                assert sha(checkpoint)==worker['hashes']['checkpoint.json'] and sha(result)==worker['hashes']['result.json']
                members.append((checkpoint,result))
        corpus_scope='all archived histories'
    else:
        root=Path(args.native_root).resolve();proof_raw=(root/'state.json').read_bytes();state=json.loads(proof_raw)
        active=set(state['active'].values())
        for job in state['progress']:
            if not job['complete']:continue
            assert job['pid'] not in active,'never read a running checkpoint'
            folder=root/'purpose'/'latest'/('adverse-'+job['case']+'-'+job['arm'])
            members.append(((folder/'checkpoint.json').read_bytes(),(folder/'result.json').read_bytes()))
        corpus_scope='only executions already complete in native queue; not full study evidence'
    sources={str(p.relative_to(source)).replace('\\','/'):sha(p.read_bytes()) for name in ('reflex','tools') for p in (source/name).rglob('*.py')}
    sys.path.insert(0,str(source))
    from reflex.core import digest
    from tools.run_adverse_recovery import game_for,replay
    wall=time.perf_counter();cpu=time.process_time();rows=[]
    for checkpoint,result_raw in members:
            payload=json.loads(checkpoint)['payload'];result=json.loads(result_raw)
            config=payload['contract']['configuration'];spec=config['spec']
            assert result['complete'] and len(result['trace'])==spec['turns']
            assert payload['trace']==result['trace'] and digest(payload['owner'])==result['final_owner']
            steps=replay(game_for(spec),spec,result['trace'],payload['owner'],payload['rng'],arm=config['arm'])
            rows.append(dict(id=spec['id'],arm=config['arm'],steps=steps,exact=True,checkpoint_sha256=sha(checkpoint),result_sha256=sha(result_raw)))
            print(json.dumps(rows[-1]),flush=True)
    assert all(sha((source/n).read_bytes())==h for n,h in sources.items()),'runtime source changed during replay'
    result=dict(complete=True,executions=len(rows),actual_history_steps=sum(r['steps'] for r in rows),
                wall_seconds=time.perf_counter()-wall,cpu_seconds=time.process_time()-cpu,rows=rows,
                source=str(source),sources=sources,corpus_scope=corpus_scope,
                source_evidence_sha256=sha(proof_raw),
                scope='Every saved observation, learner update, owner hash, personality and world RNG replayed exactly. Recorded actions were supplied: this does not prove unchanged prospective choices or new long-play quality.',adoption=False)
    out.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('complete','executions','actual_history_steps','wall_seconds','cpu_seconds')}),flush=True)
