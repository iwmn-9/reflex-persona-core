import argparse,gzip,json,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--library',required=True);p.add_argument('--output',required=True);args=p.parse_args()
v=Path(__file__).parent;b=v.parents[2];host=b/'reflex-persona-prediction-transfer'
sys.path[:0]=[args.library,str(host)]
from reflex.core import digest
from reflex.decision_loop import DecisionLoop
from reflex.fixed_horizon import FixedHorizonOwner
from reflex.model_observer import resolve_feedback
from tools.run_continuation_portfolio import game_for
from tools.run_owned_value import cumulative_basis
rows=[json.loads(r) for r in gzip.decompress((host/'evidence/long_horizon/adverse_transfer/completed_local/runs.jsonl.gz').read_bytes()).splitlines()]
source=next(r for r in rows if r['spec']['id']=='auction-0-10061201-outside' and r['arm']=='stable')
results=[]
for mode in ('record','controller'):
    game=game_for(source['spec']);world=game.start();actor=game.actor(game.context(world),learning='segmented')
    ctrl=FixedHorizonOwner(actor,observe=game.context,events=game.events,terminal=game.terminal,
        assess=lambda w:game.goal(w).record(),request_for=game.request,feedback=game.feedback,
        model_id=game.model_id,target=game.target,cumulative_preference=cumulative_basis(game,True))
    trace=[]
    for row in source['result']['trace'][:6]:
        context=game.context(world,actor.state)
        result=DecisionLoop.decide_batch([(actor,game.request(context))],False,_counterfactual_roots=(row['action'],))[0]
        after,flow=game.transition(world,row['action'],row['response'])
        resolve_feedback(actor,result['ticket'],game.feedback(world,after,row['action'],context,flow))
        trace.append(dict(tick=row['tick'],expected=row['owner'],actual=digest(actor.record()),owner=actor.record()))
        if mode=='record':actor=DecisionLoop.from_record(context,json.loads(json.dumps(actor.record(),sort_keys=True)),predictor=actor.predictor)
        else:
            ctrl.actor=actor
            ctrl=ctrl.restored(after,json.loads(json.dumps(ctrl.checkpoint(after),sort_keys=True)));actor=ctrl.actor
        world=after
    results.append(dict(mode=mode,trace=trace))
Path(args.output).write_text(json.dumps(results),encoding='utf-8')
print(json.dumps({r['mode']:[t['tick'] for t in r['trace'] if t['actual']!=t['expected']] for r in results}))
