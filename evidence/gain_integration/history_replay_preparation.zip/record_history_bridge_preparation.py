from pathlib import Path
import hashlib,json,zipfile
v=Path(__file__).parent;b=v.parents[2];root=b/'reflex-persona-gain-integration'
read=lambda p:json.loads(p.read_bytes())
a=read(v/'history_bridge_original_prefix.json');c=read(v/'history_bridge_package_prefix.json')
assert len(a)==len(c)==2
for old,new in zip(a,c):
    assert old['mode']==new['mode']
    assert [t['owner'] for t in old['trace']]==[t['owner'] for t in new['trace']]
    assert [t['tick'] for t in old['trace'] if t['actual']!=t['expected']]==[5]
assert not (root/'results/gain_history_bridge_should_refuse').exists()
receipt=dict(prepared=True,complete_history_replay=False,adoption=False,
    negative_runtime_preflight_confirmed=True,original_and_installed_prefix_owners_identical=True,
    rejected_source='adverse_transfer/completed_local: Linux Python3.12.14 NumPy2.3.5',
    current='Windows Python3.12.14 NumPy2.3.5',
    discrepancy='Both original and installed code diverge from the Linux saved hash at auction-0 outside tick5. No tolerance changed.',
    next='Use complete native Windows Q/G audits, then the final reserved40 audit. Do not restart Linux or claim positive long-history replay from the failed rehearsal.',
    script_sha256=hashlib.sha256((v/'verify_installed_factual_histories.py').read_bytes()).hexdigest())
(v/'history_bridge_preparation.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
dest=root/'evidence/gain_integration/history_replay_preparation.zip'
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED) as z:
    for name in ('verify_installed_factual_histories.py','diagnose_history_bridge.py','history_bridge_original_prefix.json',
                 'history_bridge_package_prefix.json','history_bridge_preparation.json','record_history_bridge_preparation.py'):
        z.write(v/name,name)
p=b/'reflex-persona-core/results/long_horizon_resume_status.json';status=read(p)
status['python_integration']['history_replay']=dict(script=str(v/'verify_installed_factual_histories.py'),
    receipt=str(v/'history_bridge_preparation.json'),complete=False,running=False,
    note=receipt['next'])
p.write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
