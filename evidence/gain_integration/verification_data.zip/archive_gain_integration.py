"""Retain complete package/entry equivalence, never a scientific adoption."""
from pathlib import Path
import hashlib,json,re,subprocess,zipfile

v=Path(__file__).parent;b=v.parents[2];root=b/'reflex-persona-gain-integration'
def read(path):return json.loads(path.read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
structural=read(v/'gain_integration_source_audit.json')
known=read(v/'integrated_gain_known_owner_verification.json')
assert structural['complete'] and structural['learner_definition_ast_exact'] and structural['template_definition_ast_exact']
assert known['complete'] and known['known_h32_forecast_exact'] and known['actual_feedback_and_controller_restore_exact']
assert known['normalized_sha256']=='c8bb84020793305a4cb0e7597084390c5ee7fb2ca4ae3dc1432ae9f564ac441a'
assert sha(v/'integrated_gain_known_owner.json')==known['actual_sha256']
assert all(sha(root/name)==h for name,h in structural['compared_sources'].items())
wheel=root/'results/gain_integration_dist/reflex_persona_core-0.1.1.dev0-py3-none-any.whl'
assert sha(wheel)==structural['wheel_sha256']
for name in ('gain_host_package','stable_host_package'):
    proof=read(root/'results'/name/'verification.json')
    assert proof['complete'] and proof['research_imports_blocked'] and proof['host_world_rng_owner_and_trace_exact']
    assert not proof['new_quality_trials']
    assert proof['verifier_sha256']==sha(root/'tools/verify_stable_host.py')
log=(root/'results/gain_integration_tests.log').read_text(encoding='utf-8')
passed=re.search(r'Ran (\d+) tests in ([0-9.]+)s\s+OK\s*$',log)
assert passed,'Affected regressions are incomplete or failed'
assert int(passed[1])==26,'All selected methods, including the existing imported test class, are required'
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert commit!='78a55acb04a5d3e5afe35db4a1d152cec1fd9000'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True).strip()
sources={p.relative_to(root).as_posix():sha(p) for folder in ('reflex','tools','tests')
         for p in sorted((root/folder).glob('*.py'))}
assert len(sources)==606
out=root/'evidence/gain_integration';out.mkdir(exist_ok=False)
(out/'sources.json').write_bytes(encoded(sources))
with zipfile.ZipFile(out/'source.zip','x',zipfile.ZIP_DEFLATED) as packed:
    for name in sources:packed.write(root/name,name)
    for name in ('pyproject.toml','examples/stable_host.py','examples/experimental_gain_host.py',
                 'docs/EXPERIMENTAL_GAIN_INTEGRATION.md'):packed.write(root/name,name)
with zipfile.ZipFile(out/'verification_data.zip','x',zipfile.ZIP_DEFLATED) as packed:
    for name in ('audit_gain_integration_sources.py','gain_integration_source_audit.json',
                 'measure_integrated_gain_owner.py','measure_gain_known_owner.py',
                 'integrated_gain_known_owner.json','integrated_gain_known_owner_verification.json',
                 'archive_gain_integration.py'):packed.write(v/name,name)
    packed.write(root/'results/gain_integration_tests.log','affected_tests.log')
    for name in ('gain_host_package','stable_host_package'):
        for path in (root/'results'/name).glob('*.json'):packed.write(path,name+'/'+path.name)
    packed.write(wheel,wheel.name)
proof=dict(complete=True,adoption=False,source_ref=commit,source_files=606,
    source_sha256=hashlib.sha256(encoded(sources)).hexdigest(),
    previous_runtime_source='78a55acb04a5d3e5afe35db4a1d152cec1fd9000',
    learner_ast_exact=True,template_ast_exact=True,installed_h32_forecast_and_actual_restore_exact=True,
    normalized_h32_sha256=known['normalized_sha256'],affected_tests=int(passed[1]),unique_test_methods=22,
    package=dict(version='0.1.1.dev0',wheel_sha256=sha(wheel),python_files_exact=172,
        isolated_host_full_resumed_terminal_exact=True,research_imports_blocked=True,published_release=False),
    artifacts={p.name:sha(p) for p in out.iterdir()},
    scope='Existing research composition packaged with an explicit owned lifecycle. No changed algorithm, persona, rules or world outcomes.',
    remaining=['Complete registered world development and all loss/persona reviews.',
               'Pass unchanged reserved forty conditions before any adoption.',
               'Replay the completed scientific histories through the final installed package before release.',
               'New learner and planner remain Python; no Rust equivalence is inferred.'],
    limitations=['Known H32 owner and short integration tests do not establish long-world improvement.',
                 'Affected regressions are not a new full repository regression.',
                 'Two host examples test connection only; their scores are not quality comparisons.'])
(out/'verification.json').write_bytes(encoded(proof))
print(json.dumps({k:proof[k] for k in ('complete','adoption','source_ref','source_files','affected_tests')}))
