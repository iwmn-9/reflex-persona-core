"""Check the installed Python entry on the pre-existing experienced H32 owner."""
from pathlib import Path
import hashlib,json,sys

v=Path(__file__).parent;b=v.parents[2];source=b/'reflex-persona-gain-integration'
installed=source/'results/gain_installed'
sys.path[:0]=[str(installed),str(source)]
import reflex
assert Path(reflex.__file__).resolve().is_relative_to(installed)
from reflex.experimental_gain import GainHorizonOwner
from tools import run_adverse_recovery as runtime
from tools.run_owned_value import cumulative_basis
from measure_gain_known_owner import measure
owners=[]
def integrated_decide(actor,game,world,arm,seeds=None):
    assert arm=='transfer_purpose_gain' and seeds==(701,702,703)
    controller=GainHorizonOwner(actor,observe=game.context,events=game.events,terminal=game.terminal,
        assess=lambda w:game.goal(w).record(),request_for=game.request,feedback=game.feedback,
        model_id=game.model_id,target=game.target,cumulative_preference=cumulative_basis(game,True),
        horizon=32,seeds=seeds,recovery_cache=64)
    result=controller.decide(world);owners.append(controller)
    return result,controller.last
runtime.decide=integrated_decide
output=v/'integrated_gain_known_owner.json'
measure(source,b/'reflex-persona-purpose-tail/evidence/long_horizon/adverse_purpose_tail/root_comparison.zip',output)
actual=json.loads(output.read_bytes());reference=json.loads((v/'prepared_responses_known_candidate.json').read_bytes())
assert actual['actual']==reference['actual']
controller=owners[0];world=actual['actual']['one_step']['after']
saved=json.loads(json.dumps(controller.checkpoint(world)))
restored=controller.restored(world,saved)
assert type(restored) is GainHorizonOwner and restored.actor.record()==controller.actor.record()
assert restored.checkpoint(world)==saved
matches=[]
for p in (source/'reflex').glob('*.py'):
    other=installed/'reflex'/p.name
    assert p.read_bytes()==other.read_bytes();matches.append(p.name)
proof=dict(complete=True,adoption=False,installed_entry=True,known_h32_forecast_exact=True,
    actual_feedback_and_controller_restore_exact=True,source_package_files_exact=len(matches),
    normalized_sha256=actual['normalized_sha256'],new_worlds=0,
    source=str(source),installed=str(installed),
    actual_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),
    reference_sha256=hashlib.sha256((v/'prepared_responses_known_candidate.json').read_bytes()).hexdigest(),
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(v/'integrated_gain_known_owner_verification.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof),flush=True)
