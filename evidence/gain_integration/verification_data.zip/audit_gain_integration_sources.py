"""Audit relocation and wheel contents without repeating scientific worlds."""
from pathlib import Path
import ast,hashlib,json,zipfile

v=Path(__file__).parent;b=v.parents[2];source=b/'reflex-persona-gain-integration'
reference=b/'reflex-persona-shared-runtime'
def definitions(path):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_text(encoding='utf-8')).body
            if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
old=definitions(reference/'tools/template_transfer_prediction.py')
new=definitions(source/'reflex/template_transfer.py')
assert old==new
helper=definitions(reference/'tools/symmetric_prediction.py')['complete_templates']
assert helper==definitions(source/'reflex/_response_templates.py')['complete_templates']
wheel=source/'results/gain_integration_dist/reflex_persona_core-0.1.1.dev0-py3-none-any.whl'
with zipfile.ZipFile(wheel) as packed:
    names=packed.namelist()
    assert not any(n.startswith(('tools/','tests/')) for n in names)
    files=[n for n in names if n.startswith('reflex/') and n.endswith('.py')]
    assert set(files)=={p.relative_to(source).as_posix() for p in (source/'reflex').glob('*.py')}
    assert all(packed.read(n)==(source/n).read_bytes() for n in files)
    metadata=next(n for n in names if n.endswith('.dist-info/METADATA'))
    assert 'Version: 0.1.1.dev0' in packed.read(metadata).decode().splitlines()
result=dict(complete=True,adoption=False,learner_definition_ast_exact=True,template_definition_ast_exact=True,
    wheel_python_files_exact=len(files),no_research_tools_in_wheel=True,wheel_sha256=sha(wheel),
    reference_source='78a55acb04a5d3e5afe35db4a1d152cec1fd9000',
    compared_sources={str(p.relative_to(source)):sha(p) for p in (
        source/'reflex/template_transfer.py',source/'reflex/_response_templates.py',
        source/'reflex/experimental_gain.py',source/'reflex/fixed_horizon.py')},
    script_sha256=sha(Path(__file__)),
    limits='Definition relocation and source/package parity only. Runtime entry/restore checks and full scientific gates remain separate.')
(v/'gain_integration_source_audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
