"""Archive bounded native package replay, preserving the whole-cohort gate."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,zipfile

def sha(data):return hashlib.sha256(data).hexdigest()
def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
base=Path(__file__).resolve().parents[3]
local=Path(__file__).resolve().parent
integration=base/'reflex-persona-gain-integration'
output=integration/'results/completed_native_pair_replay'
proof=json.loads((output/'verification.json').read_bytes())
assert proof['complete'] and not proof['cohort_complete'] and not proof['adoption']
assert proof['executions']==4 and proof['actual_steps']==512
assert proof['new_worlds']==proof['recomputed_planning_decisions']==0
assert all(c['exact'] and c['steps']==c['restores']==128 for c in proof['checks'])
script=local/'verify_installed_factual_histories.py'
assert sha(script.read_bytes())==proof['script_sha256']
env=os.environ.copy();env.update(NPY_DISABLE_CPU_FEATURES='AVX512F,AVX512CD,AVX512_SKX,AVX512_CLX,AVX512_CNL,AVX512_ICL',
    OPENBLAS_CORETYPE='Haswell',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
foreign_output=integration/'results/native_bridge_foreign_runtime_refusal'
assert not foreign_output.exists()
command=[sys.executable,str(script),'--archive',str(base/'reflex-persona-prediction-transfer/evidence/long_horizon/adverse_transfer/completed_local'),
    '--host',str(base/'reflex-persona-prediction-transfer'),'--installed',str(integration/'results/gain_installed'),
    '--output',str(foreign_output)]
negative=subprocess.run(command,env=env,capture_output=True,text=True)
assert negative.returncode!=0 and 'exact factual replay requires the original Python/NumPy/platform runtime' in negative.stderr
assert not foreign_output.exists()
receipt=dict(complete=True,cohort_complete=False,adoption=False,executions=4,actual_steps=512,
    every_step_checkpoint_restores=512,planning_decisions_recomputed=0,new_worlds=0,
    exact_installed_history_replay=True,foreign_runtime_rejected_before_output=True,
    proof_sha256=sha((output/'verification.json').read_bytes()),script_sha256=sha(script.read_bytes()),
    limits='Two already complete audited native Windows pairs. Actual actions supplied; this proves learning and controller restoration, not new decisions, cohort passage, runtime handoff or adoption.')
archive=integration/'evidence/gain_integration/native_pair_replay.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as packed:
    packed.write(script,script.name);packed.write(Path(__file__),Path(__file__).name)
    packed.write(output/'verification.json','verification.json')
    packed.writestr('receipt.json',encoded(receipt))
    packed.writestr('foreign_runtime_refusal.txt',negative.stderr)
    for item in proof['input_audits']:
        path=Path(item['path']);packed.write(path/'verification.json','inputs/'+path.name+'/verification.json')
receipt['archive_sha256']=sha(archive.read_bytes())
(integration/'evidence/gain_integration/native_pair_replay.json').write_bytes(encoded(receipt))
print(json.dumps(receipt),flush=True)
