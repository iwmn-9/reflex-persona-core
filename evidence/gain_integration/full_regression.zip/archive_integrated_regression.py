"""Preserve the completed full regression against the already packaged source."""
from pathlib import Path
import hashlib, json, zipfile

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()

local = Path(__file__).resolve().parent
root = local.parents[2] / 'reflex-persona-gain-integration'
run = root / 'results/integrated_full_regression_20261031'
evidence = root / 'evidence/gain_integration'
status = json.loads((run / 'status.json').read_bytes())
sources = json.loads((run / 'sources.json').read_bytes())
package = json.loads((evidence / 'verification.json').read_bytes())
assert status['complete'] and status['passed'] and not status['adoption']
assert not any(status[key] for key in ('failures', 'errors', 'unexpected_successes', 'expected_failures'))
assert status['tests'] == 1374 and len(status['skipped']) == 19
assert sha(encoded(sources)) == status['source_sha256'] == package['source_sha256']
assert all(sha((root / name).read_bytes()) == digest for name, digest in sources.items())
assert sha((run / 'tests.log').read_bytes()) == status['log_sha256']
script = local / 'run_integrated_regression.py'
assert sha(script.read_bytes()) == status['script_sha256']
archive = evidence / 'full_regression.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as packed:
    for name in ('status.json', 'sources.json', 'tests.log'):
        packed.write(run / name, name)
    packed.write(script, script.name)
    packed.write(Path(__file__), Path(__file__).name)
receipt = dict(complete=True, passed=True, adoption=False,
    tests=status['tests'], passed_tests=status['tests'] - len(status['skipped']),
    skipped=len(status['skipped']), failures=0, errors=0,
    source_commit=status['source_commit'], source_files=len(sources),
    source_sha256=status['source_sha256'], packaged_source_identical=True,
    archive_sha256=sha(archive.read_bytes()), status_sha256=sha((run / 'status.json').read_bytes()),
    finished=status['finished'], elapsed_seconds=status['elapsed_seconds'],
    limits='Full local source regression, with 17 optional mahjong and 2 Linux process-group tests skipped. No new long-world quality result, independent confirmation or adoption.')
(evidence / 'full_regression.json').write_bytes(encoded(receipt))
print(json.dumps(receipt))
