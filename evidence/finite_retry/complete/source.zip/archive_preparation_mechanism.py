"""Audit and retain every factual history of F/G; never grants adoption."""
import argparse
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
import platform
from pathlib import Path
import sys
import zipfile


def read(p):return json.loads(Path(p).read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def encoded(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def archive(source,execution,output,kind):
    source,execution,output=map(lambda p:Path(p).resolve(),(source,execution,output))
    if output.exists():raise FileExistsError('retain the existing audit')
    status=read(execution/'status.json');plan=read(execution/'plan.json');summary=read(execution/'summary.json')
    if not status['complete'] or not summary['complete']:raise ValueError('all registered executions must finish')
    expected_arms={'control':[],'finite':[2,4]} if kind=='finite' else {'control':False,'gain':True}
    expected_pairs=6 if kind=='finite' else 10
    if plan['arms']!=expected_arms or len(plan['specs'])!=expected_pairs or status['pairs_complete']!=expected_pairs:
        raise ValueError('original mechanism conditions and both arms required')
    if not all(sha((source/n).read_bytes())==h for n,h in plan['sources'].items()):raise ValueError('frozen runtime changed')
    import os
    os.environ.update(plan['arithmetic'])
    sys.path.insert(0,str(source))
    from tools.run_purpose_tail_preparation import audit
    import numpy as np
    runtime=dict(python=sys.version,numpy=np.__version__,system=platform.system(),machine=platform.machine())
    if 'runtime' in plan and plan['runtime']!=runtime:raise ValueError('registered interpreter/runtime changed')
    runner=source/'tools'/('run_finite_retry_screen.py' if kind=='finite' else 'run_gain_retry_screen.py')
    spec=importlib.util.spec_from_file_location('mechanism_runner',runner)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    if module.specs()!=plan['specs']:raise ValueError('complete registered condition ordering required')
    rows=[];payloads={};executions={};pairs=[]
    for case in plan['specs']:
        arms={}
        for arm,setting in plan['arms'].items():
            folder=execution/case['id']/arm
            result=read(folder/'result.json')
            expected=dict(spec=case,retry=True,horizon=case.get('horizon',8),seeds=[701])
            expected['retry_prefixes' if kind=='finite' else 'retry_until_gain']=setting
            if result['configuration']!=expected:raise ValueError('actual controller does not match registered arm')
            proof=audit(folder,case)
            if proof['source_runtime']!=runtime:raise ValueError('all completed arms require the same frozen interpreter/runtime')
            if proof!=read(folder/'audit.json'):raise ValueError('factual replay audit differs')
            if proof['actual_steps']!=case['turns']:raise ValueError('all128 actual decisions required')
            arms[arm]=proof;executions[(case['id'],arm)]=result
            rows.append(dict(id=case['id'],arm=arm,proof=proof))
            for name in ('checkpoint.json','result.json','audit.json'):
                payloads[f"{case['id']}/{arm}/{name}"]=(folder/name).read_bytes()
        candidate='finite' if kind=='finite' else 'gain'
        pairs.append(dict(id=case['id'],delta=arms[candidate]['score']-arms['control']['score'],arms=arms))
    if pairs!=summary['pairs'] or summary['plan_sha256']!=sha((execution/'plan.json').read_bytes()):
        raise ValueError('aggregate differs from exact audited results')
    total=sum(r['proof']['actual_steps'] for r in rows)
    if total!=summary['actual_steps'] or total!=2*sum(s['turns'] for s in plan['specs']):raise ValueError('actual-step total mismatch')
    prefixes=[]
    for case in plan['specs']:
        if not case['id'].endswith('-loss'):continue
        normal=case['id'].removesuffix('-loss')+'-stable';shock=case['changes'][0][0]
        for arm in plan['arms']:
            left=executions[(normal,arm)]['trace'];right=executions[(case['id'],arm)]['trace']
            # The scheduled event changes after-state at this tick. Decisions
            # preceding that reveal must have no information about its future.
            if not all(all(a[k]==b[k] for k in ('before','before_owner','action'))
                       for a,b in zip(left[:shock],right[:shock])):
                raise ValueError('unrevealed future world change affected an earlier decision')
            prefixes.append(dict(id=case['id'],arm=arm,identical_pre_reveal_decisions=shock))
    nonnegative=all(p['delta']>=-1e-12 for p in pairs);strict=any(p['delta']>1e-12 for p in pairs)
    if summary['nonnegative_every_pair']!=nonnegative or summary['strict_gain']!=strict:raise ValueError('registered mechanism checks differ')
    output.mkdir(parents=True)
    for name in ('plan.json','summary.json'):(output/name).write_bytes((execution/name).read_bytes())
    with zipfile.ZipFile(output/'histories.zip','x',zipfile.ZIP_DEFLATED) as packed:
        for name,raw in payloads.items():packed.writestr(name,raw)
        for name in ('stdout.log','stderr.log','status.json'):
            packed.writestr(name,(execution/name).read_bytes())
    with zipfile.ZipFile(output/'source.zip','x',zipfile.ZIP_DEFLATED) as packed:
        for name in plan['sources']:packed.writestr(name,(source/name).read_bytes())
        packed.writestr('archive_preparation_mechanism.py',Path(__file__).read_bytes())
    details=dict(complete=True,pairs=pairs,prefixes=prefixes,executions=rows,adoption=False)
    (output/'audit.json').write_bytes(encoded(details))
    proof=dict(version='preparation-mechanism-audit-1',at=datetime.now(timezone.utc).isoformat(),
        kind=kind,complete=True,pairs=len(pairs),executions=len(rows),actual_steps=total,
        fixed_personas_and_exact_learners=True,every_step_restored=True,
        source_sha256=sha(encoded(plan['sources'])),mechanism_gate_passed=nonnegative and strict,
        all_individual_results_retained=True,adoption=False,independent_confirmation=False,
        limitations=['Known deterministic preparation mechanisms, not stochastic game-wide quality or independent confirmation.',
            'Every recorded factual update and world replayed; modeled forecasting is not reexecuted by this collector.',
            'Functional persona tests remain necessary; these material-score worlds do not express every intrinsic value.'],
        artifacts={p.name:sha(p.read_bytes()) for p in output.iterdir()})
    (output/'verification.json').write_bytes(encoded(proof))
    print(json.dumps({k:v for k,v in proof.items() if k not in ('artifacts','limitations')}))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ('source','execution','output'):p.add_argument('--'+name,required=True)
    p.add_argument('--kind',choices=('finite','gain'),required=True)
    archive(**vars(p.parse_args()))
