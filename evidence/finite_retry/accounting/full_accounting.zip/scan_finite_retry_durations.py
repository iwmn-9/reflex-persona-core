"""Fixed cross-duration screen: every delay2..7 and both reward signs retained."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    source=Path(a.source).resolve();output=Path(a.output)
    if output.exists():raise FileExistsError(output)
    os.environ.update(NPY_DISABLE_CPU_FEATURES='AVX512F,AVX512CD,AVX512_SKX,AVX512_CLX,AVX512_CNL,AVX512_ICL',
        OPENBLAS_CORETYPE='Haswell',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    sys.path.insert(0,str(source))
    from tools.preparation_world import PreparationChain
    from tests.test_finite_retry import evaluate
    plan=dict(horizon=8,delays=list(range(2,8)),reward_formulas={'good':'2*delay+2','bad':'delay'},
        prefixes=[[],[2,4]],scope='Every registered initial root; known deterministic mechanism, no long-play adoption.')
    output.with_suffix('.plan.json').write_text(json.dumps(plan,indent=2),encoding='utf-8')
    rows=[];started=time.perf_counter()
    for delay in plan['delays']:
        for sign in ('good','bad'):
            payout=2*delay+2 if sign=='good' else delay
            game=PreparationChain(delay,payout=payout,turns=128)
            # Explicit feasible schedule: one completed cycle then x. It is an
            # evaluator-only check, not an action sequence supplied to the NPC.
            before=game.start();after=before
            for key in ['y']*delay+['x']*(8-delay):after,_=game.transition(after,key,'0')
            feasible_cash=after['cash'];cash_if_x=before['cash']+8
            assert (feasible_cash>cash_if_x)==(sign=='good')
            for prefixes in ((),(2,4)):
                result,cap=evaluate(game,prefixes)
                row=dict(delay=delay,sign=sign,payout=payout,prefixes=prefixes,
                    action=result['decision']['action_id'],feasible_cash=feasible_cash,
                    all_immediate_cash=cash_if_x,modeled_best_purpose=max(cap['forecast'].purpose.values()))
                rows.append(row);print(json.dumps(row),flush=True)
    output.write_text(json.dumps(dict(complete=True,rows=rows,adoption=False,plan=plan,
        wall_seconds=time.perf_counter()-started,
        source_sha256=hashlib.sha256((source/'reflex/_continuation_portfolio.py').read_bytes()).hexdigest()),indent=2),encoding='utf-8')
