"""Reuse the established intrinsic tradeoff, without changing frozen F sources."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    source=Path(a.source).resolve();output=Path(a.output)
    if output.exists():raise FileExistsError(output)
    os.environ.update(NPY_DISABLE_CPU_FEATURES='AVX512F,AVX512CD,AVX512_SKX,AVX512_CLX,AVX512_CNL,AVX512_ICL',
        OPENBLAS_CORETYPE='Haswell',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    sys.path.insert(0,str(source))
    from reflex.core import character_key
    from reflex.laboratory import PROFILES
    from tests.test_continuation_persona import IntrinsicTradeoff
    from tests.test_finite_retry import evaluate
    rows=[];started=time.perf_counter()
    for profile,mode,names,expected in [(0,'principle',('x','y'),'x'),(2,'principle',('x','y'),'y'),
        (2,'need',('x','y'),'x'),(2,'principle',('zeta','alpha'),'alpha')]:
        game=IntrinsicTradeoff(PROFILES[profile],names,mode=mode)
        for prefixes in ((),(2,4)):
            result,captured=evaluate(game,prefixes)
            assert result['decision']['action_id']==expected
            assert character_key(result['context'])==character_key(game.context(game.start()))
            rows.append(dict(profile=PROFILES[profile]['id'],mode=mode,names=names,prefixes=prefixes,
                expected=expected,action=result['decision']['action_id']))
    sources={n:hashlib.sha256((source/n).read_bytes()).hexdigest() for n in (
        'reflex/_continuation_portfolio.py','tests/test_finite_retry.py','tests/test_continuation_persona.py')}
    output.write_text(json.dumps(dict(complete=True,passed=True,horizon=8,cases=rows,sources=sources,
        wall_seconds=time.perf_counter()-started,adoption=False,
        scope='Existing intrinsic-personality functional boundary with both control and finite retry; not independent long-play evidence.'),indent=2),encoding='utf-8')
    print(json.dumps(dict(complete=True,cases=len(rows),wall_seconds=time.perf_counter()-started,adoption=False)))
