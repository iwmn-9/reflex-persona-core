"""Retain bounded exact-runtime qualification, never adopt a scientific candidate."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

V=Path(__file__).parent;B=V.parents[2];K=B/'reflex-persona-retry-runtime';H=B/'reflex-persona-preview-runtime'
out=K/'evidence/unchanged_retry_runtime'
def read(p):return json.loads(Path(p).read_bytes())
def encoded(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
matrix=read(V/'retry_runtime_matrix.json')
base=read(V/'gain_known_owner_reference.json');new=read(V/'gain_known_owner_retry_runtime.json')
assert matrix['complete'] and matrix['differences']==[] and len(matrix['rows'])==7
assert matrix['reference_sha256']==sha(V/'prepared_context_matrix_final.json')
assert base['complete'] and new['complete'] and base['runtime']==new['runtime']
assert base['actual']==new['actual']
assert base['normalized_sha256']==new['normalized_sha256']==hashlib.sha256(encoded(new['actual'])).hexdigest()
assert new['exact_96_step_owner'] and new['one_actual_feedback_and_restore']
assert new['script_sha256']==sha(V/'measure_gain_known_owner.py')
assert all(sha(K/n)==h for n,h in new['sources'].items())
assert all(sha(K/n)==h for n,h in matrix['sources'].items())
assert all(sha(H/n)==h for n,h in base['sources'].items())
sources={p.relative_to(K).as_posix():sha(p) for folder in ('reflex','tools','tests') for p in sorted((K/folder).glob('*.py'))}
original=read(H/'evidence/long_horizon/adverse_gain_tail/registration.json')['sources']
changed=sorted(n for n,h in original.items() if sources.get(n)!=h)
added=sorted(set(sources)-set(original))
assert changed==['reflex/_continuation_portfolio.py']
assert added==['tests/test_unchanged_retry_runtime.py'] and len(sources)==601
log=(K/'results/retry_runtime_tests.log').read_text(encoding='utf-8')
match=re.search(r'Ran (\d+) tests in ([0-9.]+)s\s+OK\s*$',log)
assert match and int(match[1])==25
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=K,text=True).strip()
assert commit=='9d67849042891e58b3a1e9146deb5a8b85a242ea'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=K,text=True).strip()
out.mkdir(parents=True,exist_ok=False)
(out/'sources.json').write_bytes(encoded(sources))
with zipfile.ZipFile(out/'source.zip','x',zipfile.ZIP_DEFLATED) as packed:
    for name in sources:packed.write(K/name,name)
with zipfile.ZipFile(out/'verification_data.zip','x',zipfile.ZIP_DEFLATED) as packed:
    for name in ('retry_runtime_matrix.json','prepared_context_matrix_final.json','gain_known_owner_reference.json',
        'gain_known_owner_retry_runtime.json','check_gain_path_reuse.py','measure_gain_known_owner.py',
        'archive_unchanged_retry_runtime.py'):
        packed.write(V/name,name)
    packed.write(K/'results/retry_runtime_tests.log','retry_runtime_tests.log')
proof=dict(complete=True,adoption=False,scientific_source_commit=commit,
    development_source_ref='71bf6b2f3e40724a7bb33be14dc3bd3311ee18f8',
    previous_runtime_qualification='68c72dae536c82e88c308a5276a916deeec76f9d1c1e49dc98b24881ced97f8c',
    source_sha256=hashlib.sha256(encoded(sources)).hexdigest(),files_count=601,changed=changed,added=added,
    exact_matrix_cases=7,exact_experienced_h32_owner=True,exact_actual_feedback_and_restore=True,
    experienced_root_normalized_sha256=new['normalized_sha256'],
    matrix_cpu_seconds=[matrix['old_cpu'],matrix['new_cpu']],
    experienced_cpu_seconds=[base['cpu_seconds'],new['cpu_seconds']],
    experienced_wall_seconds=[base['wall_seconds'],new['wall_seconds']],
    tests=dict(passed=25,failures=0,seconds=float(match[2]),scope='Affected portfolio, gain, persona/actual owner and prepared-context tests; no fresh repository-wide suite.'),
    artifacts={p.name:sha(p) for p in out.iterdir()},
    limitations=['Exact outputs exclude only documented computation/cache counters, never logical steps, paths or learner states.',
        'One known experienced H32 root and seven corresponding cases, not general speed guarantees or independent scientific quality evidence.',
        'Paired elapsed times reflect scheduling on the busy local PC; CPU time is reported separately.',
        'Host callbacks retain the existing pure-model contract. Existing live scientific workers are not replaced.'])
(out/'verification.json').write_bytes(encoded(proof))
print(json.dumps({k:v for k,v in proof.items() if k not in ('artifacts','limitations')}))
