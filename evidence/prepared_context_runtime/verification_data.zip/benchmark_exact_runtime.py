"""Exact long-root replay benchmark, separate from adoption evidence."""
import argparse
import hashlib
import json
import os
import platform
from pathlib import Path
import subprocess
import sys
import time
import zipfile

def sha(data):return hashlib.sha256(data).hexdigest()
def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()

def evaluate(args):
    source=Path(args.source).resolve();output=Path(args.output).resolve()
    if output.exists():raise FileExistsError(output)
    sources={str(p.relative_to(source)).replace('\\','/'):sha(p.read_bytes())
             for folder in ('reflex','tools') for p in (source/folder).rglob('*.py')}
    archive=Path(args.archive).read_bytes()
    if sha(archive)!='363945f33fa9146a4a96bff86e6f92b02bb9d7fd2c62f02b3d384ef5457f6f94':
        raise ValueError('published same-owner reference archive changed')
    with zipfile.ZipFile(args.archive) as z:
        saved=json.loads(z.read('input.json'));golden=json.loads(z.read('transfer_purpose.json'))
    sys.path.insert(0,str(source))
    import numpy as np
    import tools.run_adverse_recovery as runtime
    assert Path(runtime.__file__).resolve().is_relative_to(source)
    from reflex.core import digest,character_key
    from reflex.decision_loop import DecisionLoop
    from reflex.model_observer import resolve_feedback
    from tools.run_owned_value import law,sample
    cfg=saved['configuration'];spec=cfg['spec'];g=runtime.game_for(spec)
    w=g.start();actor=runtime.actor_for(g,g.context(w),cfg['arm'])
    rng=np.random.default_rng(spec['seed']);persona=character_key(g.context(w))
    for row in saved['trace'][:96]:
        assert row['before']==w and digest(actor.record())==row['before_owner']
        context=g.context(w,actor.state)
        result=DecisionLoop.decide_batch([(actor,g.request(context))],False,_counterfactual_roots=(row['action'],))[0]
        truth=law(w['tick'],spec['turns'],spec['regime'])
        assert row['truth']==truth and row['response']==sample(truth,rng.random())
        after,flow=g.transition(w,row['action'],row['response'])
        resolve_feedback(actor,result['ticket'],g.feedback(w,after,row['action'],context,flow))
        assert after==row['after'] and digest(actor.record())==row['owner']
        assert character_key(g.context(after))==persona
        w=after
    owner=digest(actor.record());assert owner==golden['factual_owner']
    wall=time.perf_counter();cpu=time.process_time()
    result,captured=runtime.decide(actor,g,w,'transfer_purpose',seeds=(701,702,703))
    elapsed=time.perf_counter()-wall;cpu=time.process_time()-cpu
    f=captured['forecast']
    actual=dict(arm='transfer_purpose',decision=result['decision'],deliberation=result['deliberation'],
                factual_owner=owner,modeled=captured['modeled'],purpose_by_plan=f.purpose,
                roots={k:list(v) for k,v in f.roots.items()},simulated_steps=captured['simulated_steps'])
    expected={k:v for k,v in golden.items() if k!='seconds'}
    differences=[k for k in expected if encoded(actual.get(k))!=encoded(expected[k])]
    assert all(sha((source/n).read_bytes())==h for n,h in sources.items()),'source changed during measurement'
    payload=dict(source=str(source),source_sha256=sha(encoded(sources)),sources=sources,
                 runtime=dict(python=platform.python_version(),numpy=np.__version__,platform=platform.platform(),
                    arithmetic={k:os.environ.get(k) for k in ('NPY_DISABLE_CPU_FEATURES','OPENBLAS_CORETYPE','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')}),
                 archive_sha256=sha(archive),wall_seconds=elapsed,cpu_seconds=cpu,
                 exact_96_step_factual_owner=True,exact_forecast=not differences,differences=differences,
                 forecast_sha256=sha(encoded(actual)),reference_sha256=sha(encoded(expected)),
                 expected=expected,actual=actual,adoption=False,
                 scope='Known factual root at H32/three samples; exact output and runtime check, not new long-world quality evidence.')
    output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(encoded(payload))
    print(json.dumps({k:payload[k] for k in ('source','wall_seconds','cpu_seconds','exact_forecast','differences')}) ,flush=True)
    if differences:raise AssertionError(differences)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--archive',required=True);p.add_argument('--output',required=True)
    evaluate(p.parse_args())
