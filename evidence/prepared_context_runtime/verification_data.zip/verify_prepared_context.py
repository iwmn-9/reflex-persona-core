"""Repeat the seven-case exact comparison on one immutable final runtime."""
import argparse
import importlib.util
from pathlib import Path

V=Path(__file__).parent
spec=importlib.util.spec_from_file_location('matrix',V/'check_gain_path_reuse.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--output',required=True);p.add_argument('--reference',required=True)
args=p.parse_args();source=Path(args.source)
def files():return {str(p.relative_to(source)):m.sha(p.read_bytes()) for folder in ('reflex','tools') for p in (source/folder).rglob('*.py')}
before=files();m.run(args.source,args.output,args.reference)
proof=m.json.loads(Path(args.output).read_bytes())
assert before==files()==proof['sources']
proof['immutable_source_verified']=True
proof['verifier_sha256']=m.sha(Path(__file__).read_bytes())
proof['comparison_script_sha256']=m.sha((V/'check_gain_path_reuse.py').read_bytes())
Path(args.output).write_bytes(m.encoded(proof))
