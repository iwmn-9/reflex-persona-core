import hashlib
import json
from pathlib import Path
import zipfile

V=Path(__file__).parent;B=V.parents[2];H=B/'reflex-persona-preview-runtime'
out=H/'evidence/prepared_context_runtime';out.mkdir(parents=True,exist_ok=False)
def read(p):return json.loads(p.read_bytes())
def encoded(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(raw):return hashlib.sha256(raw).hexdigest()
root=read(V/'prepared_context_exact_root.json');matrix=read(V/'prepared_context_matrix_final.json')
assert root['exact_forecast'] and root['differences']==[]
assert matrix['immutable_source_verified'] and matrix['differences']==[] and len(matrix['rows'])==7
assert {k.replace('\\','/'):v for k,v in matrix['sources'].items()}==root['sources']
assert all(sha((H/n).read_bytes())==v for n,v in root['sources'].items())
log=(V/'prepared_context_gain_tests.log').read_text()
assert 'Ran 11 tests in 103.380s' in log and log.rstrip().endswith('OK')
tests=dict(complete=True,remaining_failures=0,unique_methods_passed=53,
    first=dict(modules=['tests.test_prepared_context_runtime','tests.test_leaf_forecast_runtime',
        'tests.test_decision_loop','tests.test_closed_loop'],methods=43,passed=42,seconds=78.673,
        error='ModuleNotFoundError: test_progress_social_composition in existing sibling-test import',
        failed_method='tests.test_closed_loop.ClosedLoopTests.test_owned_learning_social_and_progress_survive_modeled_and_real_steps',
        evidence='Tool output retained in conversation; not a saved raw transcript.'),
    recovery=dict(pythonpath='tests',methods=11,passed=11,seconds=103.380,
        scope='Only the import-failed method plus ten gain-retry and actual-owner integration methods.',
        log_sha256=sha((V/'prepared_context_gain_tests.log').read_bytes())),
    limits='Targeted affected tests, not a fresh full repository run. Earlier exact-runtime qualification remains separate.')
test_names=['tests/test_prepared_context_runtime.py','tests/test_leaf_forecast_runtime.py',
    'tests/test_decision_loop.py','tests/test_closed_loop.py','tests/test_gain_retry.py','tests/test_gain_retry_owner.py']
tests['test_sources']={n:sha((H/n).read_bytes()) for n in test_names}
(out/'tests.json').write_bytes(encoded(tests))
with zipfile.ZipFile(out/'verification_data.zip','x',zipfile.ZIP_DEFLATED) as packed:
    for name in ('prepared_context_exact_root.json','prepared_context_matrix_final.json','gain_reuse_after.json',
        'prepared_context_gain_tests.log','benchmark_exact_runtime.py','check_gain_path_reuse.py',
        'verify_prepared_context.py','archive_prepared_context.py'):
        packed.writestr(name,(V/name).read_bytes())
with zipfile.ZipFile(out/'source.zip','x',zipfile.ZIP_DEFLATED) as packed:
    for name in [*root['sources'],*test_names]:packed.writestr(name,(H/name).read_bytes())
proof=dict(complete=True,adoption=False,stable_and_rust_unchanged=True,source_sha256=root['source_sha256'],
    exact_known_h32_forecast=True,exact_known_factual_prefix=96,exact_matrix_cases=7,
    h32_cpu_seconds=dict(original=788.46875,previous_qualified=180.84375,current=root['cpu_seconds']),
    h32_wall_seconds=root['wall_seconds'],matrix_cpu_seconds=dict(previous=matrix['old_cpu'],current=matrix['new_cpu']),
    paired_matrix_semantics='All forecast channels, root choices, modeled actions/flows and final modeled owners exact; only cost counters excluded.',
    tests=tests,independent_quality_confirmation=False,
    files={p.name:sha(p.read_bytes()) for p in out.iterdir()})
(out/'verification.json').write_bytes(encoded(proof))
print(json.dumps(dict(source=proof['source_sha256'],h32_cpu=proof['h32_cpu_seconds'],matrix=proof['matrix_cpu_seconds'],tests=53)))
